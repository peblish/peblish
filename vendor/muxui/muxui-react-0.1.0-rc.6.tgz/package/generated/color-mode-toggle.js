// @generated-from: packages/react/src/supplemental/color-mode-toggle.ts
// @generated-content-sha256: sha256:9d5065db2b3fd07d6e6e9928d4b6735eb1681577c2288bf47a36049c4df1046f
import React from 'react';
import { AriaSwitch } from './substrate.js';
import { h, cx } from './part-utils.js';
/* Color mode */
export const ColorModeToggle = /*#__PURE__*/ React.forwardRef(function ColorModeToggle({ mode, defaultMode, storageKey = 'muxui-color-mode', disabled = false, onModeChange, className, children, ...props }, ref) {
    // Keep the first render deterministic so an SSR light default hydrates
    // cleanly before browser-only storage or OS preference restoration runs.
    const [internalMode, setInternalMode] = React.useState(defaultMode === undefined || defaultMode === null ? 'light' : defaultMode);
    React.useEffect(() => {
        let nextMode = defaultMode;
        try {
            const saved = window.localStorage.getItem(storageKey);
            if (saved === 'light' || saved === 'dark')
                nextMode = saved;
        }
        catch {
            // Storage can be disabled by privacy settings; OS/default mode still works.
        }
        nextMode ??= window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
        setInternalMode((previous) => previous === nextMode ? previous : nextMode);
    }, [defaultMode, storageKey]);
    const currentMode = mode === undefined || mode === null ? internalMode : mode;
    React.useEffect(() => {
        if (typeof document !== 'undefined')
            document.documentElement.setAttribute('data-muxui-color-scheme', currentMode);
        try {
            window.localStorage.setItem(storageKey, currentMode);
        }
        catch { /* best effort */ }
    }, [currentMode, storageKey]);
    const update = (selected) => {
        const next = selected ? 'dark' : 'light';
        if (mode === undefined)
            setInternalMode(next);
        onModeChange?.(next);
    };
    // React Aria's props type the handlers on Element, and these on the label; the rest is the label's native attributes.
    return h(AriaSwitch, { ...props, ref, 'aria-label': props['aria-label'] ?? 'Toggle dark mode', isSelected: currentMode === 'dark', isDisabled: disabled, onChange: update, className: cx('muxui-color-mode-toggle', className), ...{ 'data-muxui-mode': currentMode } }, children);
});

// @generated-from: packages/react/src/supplemental/text-area.ts
// @generated-content-sha256: sha256:e235f50f4fdb1cf7fb7502fa114933fd8a433c54438059a6e3029edf2614d694
import React from 'react';
import { FieldError as AriaFieldError, Label as AriaLabel } from 'react-aria-components';
import { AriaTextArea } from './substrate.js';
import { h, cx } from './part-utils.js';
import { fieldText } from './field-utils.js';
import { renderFieldRoot } from './field-root.js';
const TextAreaRoot = /*#__PURE__*/ React.forwardRef(function TextAreaRoot({ value, defaultValue, onChange, disabled, invalid, required, readOnly, size = 'md', className, children, ...props }, ref) {
    return renderFieldRoot('muxui-text-area', 'TextArea', { disabled, invalid, required, readOnly, size, className, children, value, defaultValue, onChange, ...props }, ref);
});
const TextAreaInput = /*#__PURE__*/ React.forwardRef(function TextAreaInput({ disabled, className, ...props }, ref) { return h(AriaTextArea, { ...props, ref, disabled, className: cx('muxui-text-area__textarea', className) }); });
const TextAreaLabel = /*#__PURE__*/ React.forwardRef(function TextAreaLabel(props, ref) { return h(AriaLabel, { ...props, ref, className: cx('muxui-text-area__label', props.className) }); });
const TextAreaDescription = /*#__PURE__*/ React.forwardRef(function TextAreaDescription(props, ref) { return fieldText('description', 'muxui-text-area__description', props, ref); });
const TextAreaError = /*#__PURE__*/ React.forwardRef(function TextAreaError(props, ref) { return h(AriaFieldError, { ...props, ref, className: cx('muxui-text-area__error', props.className) }); });
export const TextArea = /*#__PURE__*/ Object.freeze({
    Root: TextAreaRoot,
    TextArea: TextAreaInput,
    Label: TextAreaLabel,
    Description: TextAreaDescription,
    Error: TextAreaError,
});

// @generated-from: packages/react/src/supplemental/field-root.ts
// @generated-content-sha256: sha256:d3f69801ac2b96fd6af92cbc40f9553ad2bc3e64b17ca7958c1888039b234031
import React from 'react';
import { AriaTextField } from './substrate.js';
import { normalizeChoiceControlSize } from './choice-context.mjs';
import { h, cx } from './part-utils.js';
import { mappedFieldProps } from './field-utils.js';
/* Input and TextArea */
export const InputAssociationContext = React.createContext(null);
/**
 * Renders the root of Input or TextArea: a text field that provides the input association to its parts. It calls hooks,
 * so a family calls it, unconditionally, from its own render function. The props are written structurally so that no
 * declaration names the upstream package.
 */
export function renderFieldRoot(rootClass, componentName, { disabled, invalid, required, readOnly, size, className, children, ...props }, ref) {
    const resolvedSize = normalizeChoiceControlSize(size, componentName);
    const [descriptionId, setDescriptionId] = React.useState(undefined);
    const [errorId, setErrorId] = React.useState(undefined);
    const association = React.useMemo(() => ({
        setDescriptionId,
        setErrorId,
        descriptionId,
        errorId,
        size: resolvedSize,
    }), [descriptionId, errorId, resolvedSize]);
    const renderChildren = (renderProps) => h(InputAssociationContext.Provider, { value: { ...association, invalid: Boolean(invalid || renderProps?.isInvalid) } }, typeof children === 'function' ? children(renderProps) : children);
    return h(AriaTextField, { ...mappedFieldProps({ disabled, invalid, required, readOnly, ...props }), ref, ...{ 'data-muxui-size': resolvedSize }, className: cx(rootClass, resolvedSize !== 'md' && `${rootClass}--${resolvedSize}`, className), children: renderChildren });
}

// @generated-from: packages/react/src/select.ts
// @generated-content-sha256: sha256:37199655ff0d4ab9a601ed2d40ae595713c663477620b5269747c4ac5c6d8220
import React from 'react';
import ChevronDownIcon from 'lucide-react/dist/esm/icons/chevron-down.mjs';
import { Label as AriaLabel, Text as AriaText, FieldError as AriaFieldError } from 'react-aria-components';
import { AriaListBox, AriaListBoxItem, AriaSelect, AriaSelectValue } from './substrate.js';
import { normalizeChoiceControlSize } from './choice-context.mjs';
import { overlayGeometry, normalizeBoolean } from './overlay-positioning.mjs';
import { PopoverMotion } from './popover-motion.mjs';
import { classNames, accessibleName } from './control-utils.js';
import { textContent, normalizeItems } from './collection-items.js';
import { CollectionTrigger } from './collection-trigger.js';
const SelectContext = React.createContext({ disabled: false });
// The geometry a Select falls back to. A parameter default and the geometry helper's fallback both read this record,
// so the default a block states is the one that runs.
const SELECT_GEOMETRY = Object.freeze({ placement: 'bottom-start', offset: 8, crossOffset: 0, shouldFlip: true, containerPadding: 12 });
function selectChildrenProvideLabel(children) {
    return React.Children.toArray(children).some((child) => React.isValidElement(child)
        && (child.type === Select.Label
            ? Boolean(textContent(child.props.children).trim())
            : selectChildrenProvideLabel(child.props.children)));
}
export const Select = /*#__PURE__*/ (() => {
    const Select = React.forwardRef(function SelectRoot({ label, description, errorMessage, items, value, defaultValue, open, defaultOpen = false, onOpenChange, onChange, disabled = false, readOnly = false, required = false, invalid = false, placeholder = 'Select an option', selectedContent, trigger, placement = SELECT_GEOMETRY.placement, offset = SELECT_GEOMETRY.offset, crossOffset = SELECT_GEOMETRY.crossOffset, shouldFlip = SELECT_GEOMETRY.shouldFlip, containerPadding = SELECT_GEOMETRY.containerPadding, anchorRef, modal = true, size = 'md', name, children, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
        if (!selectChildrenProvideLabel(children))
            accessibleName({ label, ariaLabel, ariaLabelledby }, 'Select');
        if (trigger !== undefined && (!React.isValidElement(trigger) || trigger.type !== 'button'))
            throw new TypeError('Select trigger must be a native button element');
        const resolvedSize = normalizeChoiceControlSize(size, 'Select');
        const geometry = overlayGeometry({ placement, offset, crossOffset, shouldFlip, containerPadding }, SELECT_GEOMETRY, 'Select');
        const isModal = normalizeBoolean(modal, true, 'Select modal');
        // Conditionals, not ?? and || on the owned props: extraction reads a fallback on an owned prop as an executed default.
        const [internalSelectedKey, setInternalSelectedKey] = React.useState(defaultValue === undefined || defaultValue === null ? null : defaultValue);
        const handleSelection = (key) => {
            if (disabled)
                return;
            if (readOnly)
                return;
            const next = key == null ? null : String(key);
            if (value === undefined)
                setInternalSelectedKey(next);
            onChange?.(next ?? undefined);
        };
        const selectContext = { disabled, readOnly, resolvedSize, geometry, anchorRef, modal: isModal };
        const defaultChildren = React.createElement(React.Fragment, null, trigger ? React.createElement(Select.Trigger, { ...trigger.props, disabled: disabled ? disabled : trigger.props.disabled })
            : React.createElement(Select.Trigger, null, 
            // Select.Value hands a function child to React Aria's SelectValue with the selection, which the public type, nodes only, does not name.
            React.createElement(Select.Value, null, (selectedContent === undefined || selectedContent === null ? (({ selectedText }) => selectedText || placeholder) : selectedContent)), React.createElement(ChevronDownIcon, { className: 'muxui-select__arrow', 'aria-hidden': 'true', focusable: 'false', size: 16 })), React.createElement(Select.Popup, null, React.createElement(Select.List, { items })));
        return React.createElement(SelectContext.Provider, { value: selectContext }, React.createElement(AriaSelect, {
            ...props, ref, selectedKey: value !== undefined ? value : internalSelectedKey,
            isOpen: disabled ? false : open, defaultOpen: !disabled && defaultOpen,
            onOpenChange: (next) => { if (!disabled || !next)
                onOpenChange?.(next); },
            onSelectionChange: handleSelection, isDisabled: disabled, isRequired: required,
            isInvalid: invalid ? invalid : undefined, name, placeholder,
            // React Aria's props do not name the data-* hooks the styles read, and TypeScript accepts such a key in a call only from a spread.
            ...{ 'data-muxui-state-read-only': readOnly ? readOnly : undefined },
            className: classNames('muxui-select', className),
            ...{ 'data-muxui-size': resolvedSize },
            'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby,
        }, label !== undefined ? React.createElement(Select.Label, null, label) : null, children === undefined || children === null ? defaultChildren : children, description !== undefined ? React.createElement(Select.Description, null, description) : null, errorMessage !== undefined ? React.createElement(Select.Error, null, errorMessage) : null));
    });
    Select.displayName = 'Select';
    Select.Root = Select;
    Select.Label = React.forwardRef(function SelectLabel({ children, className, ...props }, ref) {
        // React Aria types a Label's ref as a label element's, though elementType makes it the span the public type names.
        return React.createElement(AriaLabel, { ...props, ref: ref, elementType: 'span', className: classNames('muxui-field-label muxui-select__label', className) }, children);
    });
    Select.Trigger = React.forwardRef(function SelectTrigger({ children, disabled = false, className, ...props }, ref) {
        const context = React.useContext(SelectContext);
        const effectiveDisabled = disabled ? disabled : context.disabled;
        return React.createElement(CollectionTrigger, { ...props, ref, disabled: effectiveDisabled, className: classNames('muxui-select__trigger', className) }, children);
    });
    Select.Value = React.forwardRef(function SelectValue({ children, className, ...props }, ref) {
        return React.createElement(AriaSelectValue, { ...props, ref, className: classNames('muxui-select__value', className) }, children);
    });
    Select.Popup = React.forwardRef(function SelectPopup({ children, placement, offset, crossOffset, shouldFlip, containerPadding, anchorRef, modal, className, ...props }, ref) {
        const context = React.useContext(SelectContext);
        const defaults = { ...SELECT_GEOMETRY, ...context.geometry };
        defaults.placement = defaults.placement.replace(' ', '-');
        const geometry = overlayGeometry({ placement, offset, crossOffset, shouldFlip, containerPadding }, defaults, 'Select.Popup');
        return React.createElement(PopoverMotion, { ...props, ...geometry, ref, triggerRef: anchorRef ?? context.anchorRef, isNonModal: !normalizeBoolean(modal, context.modal ?? true, 'Select.Popup modal'), className: classNames('muxui-select__popup', className), ...{ 'data-muxui-size': context.resolvedSize } }, children);
    });
    Select.List = React.forwardRef(function SelectList({ children, items, className, ...props }, ref) {
        const context = React.useContext(SelectContext);
        // normalizeItems takes no items as an empty list, so an omitted list has no default here to state.
        const normalized = normalizeItems(items);
        const hasChildren = children !== undefined && children !== null;
        return React.createElement(AriaListBox, { ...props, ref, items: hasChildren ? undefined : normalized, className: classNames('muxui-select__list', className), ...{ 'data-muxui-size': context.resolvedSize }, children: hasChildren ? children : (item) => React.createElement(Select.Item, { id: item.id, textValue: item.textValue, disabled: item.disabled }, item.label) });
    });
    Select.Item = React.forwardRef(function SelectItem({ children, id, textValue, disabled = false, className, ...props }, ref) {
        const context = React.useContext(SelectContext);
        const effectiveDisabled = disabled ? disabled : context.disabled;
        return React.createElement(AriaListBoxItem, {
            ...props, ref, id,
            // A conditional, not ??: extraction reads a fallback on an owned prop as an executed default, and the item's own text is none.
            textValue: textValue == null ? (textContent(children) || undefined) : textValue,
            isDisabled: effectiveDisabled,
            ...{ 'data-muxui-state-disabled': effectiveDisabled || undefined, 'aria-disabled': effectiveDisabled || undefined },
            className: classNames('muxui-select__option', className),
        }, children);
    });
    Select.Description = React.forwardRef(function SelectDescription({ children, className, ...props }, ref) {
        return React.createElement(AriaText, { ...props, ref, elementType: 'span', slot: 'description', className: classNames('muxui-field-description muxui-select__description', className) }, children);
    });
    Select.Error = React.forwardRef(function SelectError({ children, className, ...props }, ref) {
        return React.createElement(AriaFieldError, { ...props, ref, elementType: 'span', className: classNames('muxui-field-error muxui-select__error', className) }, children);
    });
    return Select;
})();

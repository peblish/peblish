// @generated-from: packages/react/src/supplemental/switch-field.ts
// @generated-content-sha256: sha256:306c40e8b756650b779a062152f1dcd4965f1a0d74fdd5f3d75e28d3f600e146
import React from 'react';
import { FieldError as AriaFieldError } from 'react-aria-components';
import { AriaSwitchField, AriaSwitchButton } from './substrate.js';
import { normalizeChoiceControlSize } from './choice-context.mjs';
import { h, cx, nativePart } from './part-utils.js';
import { fieldText, mappedFieldProps } from './field-utils.js';
function makeSwitchField() {
    const Root = /*#__PURE__*/ React.forwardRef(function SwitchFieldRoot({ checked, defaultChecked, onChange, name, value, disabled, invalid, required, readOnly, size = 'md', className, ...props }, ref) {
        const resolvedSize = normalizeChoiceControlSize(size, 'SwitchField');
        // React Aria's props type the handlers on Element, and these on the div; the rest is the div's native attributes.
        return h(AriaSwitchField, { ...mappedFieldProps({ disabled, invalid, required, readOnly, ...props }), ref, isSelected: checked, defaultSelected: defaultChecked, onChange, name, value, ...{ 'data-muxui-size': resolvedSize }, className: cx('muxui-switch-field', className) });
    });
    const Button = /*#__PURE__*/ React.forwardRef(function SwitchFieldButton({ disabled, className, ...props }, ref) {
        return h(AriaSwitchButton, { ...props, ref, ...{ isDisabled: disabled }, className: cx('muxui-switch-field__button', className) });
    });
    const Thumb = /*#__PURE__*/ React.forwardRef(function SwitchFieldThumb(props, ref) { return nativePart('span', 'muxui-switch-field__thumb', props, ref); });
    const Description = /*#__PURE__*/ React.forwardRef(function SwitchFieldDescription(props, ref) { return fieldText('description', 'muxui-switch-field__description', props, ref); });
    const Error = /*#__PURE__*/ React.forwardRef(function SwitchFieldError(props, ref) { return h(AriaFieldError, { ...props, ref, className: cx('muxui-switch-field__error', props.className) }); });
    return /*#__PURE__*/ Object.freeze({ Root, Button, Thumb, Description, Error });
}
export const SwitchField = /*#__PURE__*/ makeSwitchField();

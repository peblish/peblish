// @generated-from: packages/react/src/tree.ts
// @generated-content-sha256: sha256:f82325159b57d43c6be55a87a4d9863a415d4c741889149b05b556086cf5cf23
import React from 'react';
import { TreeMotion } from './tree-motion.mjs';
import ChevronRightIcon from 'lucide-react/dist/esm/icons/chevron-right.mjs';
import { TreeItemContent as AriaTreeItemContent } from 'react-aria-components';
import { AriaTree, AriaTreeItem } from './substrate.js';
import { IconButton } from './icon-button.js';
import { classNames, accessibleName } from './control-utils.js';
import { textContent, keySet, keyList } from './collection-items.js';
function normalizeTreeItems(items = [], used = new Set(), parentDisabled = false) {
    return items.map((item, index) => {
        const source = typeof item === 'string' ? { label: item, value: item } : (item ?? {});
        const base = String(source.id ?? source.key ?? source.value ?? index);
        let id = base || String(index);
        let suffix = 1;
        while (used.has(id))
            id = `${base}-${suffix++}`;
        used.add(id);
        const nested = normalizeTreeItems(source.children ?? source.items ?? [], used, parentDisabled || Boolean(source.disabled));
        // An item may carry its label as `name`, which the index signature leaves unknown.
        const label = (source.label ?? source.name ?? source.value ?? id);
        return { ...source, id, key: id, label, value: source.value ?? id, textValue: source.textValue ?? (textContent(label) || id), disabled: parentDisabled || Boolean(source.disabled), children: nested };
    });
}
function treeKeys(items, keys = []) {
    for (const item of items) {
        keys.push(item.id);
        treeKeys(item.children ?? [], keys);
    }
    return keys;
}
function findTreeItem(items, key) {
    for (const item of items) {
        if (item.id === String(key))
            return item;
        const nested = findTreeItem(item.children ?? [], key);
        if (nested)
            return nested;
    }
    return undefined;
}
const TREE_EXPANSION_TRIGGERS = new Set(['chevron', 'row']);
function isTreeExpansionTrigger(value) {
    return TREE_EXPANSION_TRIGGERS.has(value);
}
function normalizeTreeExpansionTrigger(value = 'row') {
    if (!isTreeExpansionTrigger(value)) {
        throw new TypeError('Tree expansionTrigger must be one of: chevron, row');
    }
    return value;
}
const TREE_INTERACTIVE_SELECTOR = 'a,button,input,select,textarea,summary,[role="button"],[role="checkbox"],[role="combobox"],[role="link"],[role="menuitem"],[role="option"],[role="radio"],[role="switch"],[tabindex]:not([tabindex="-1"])';
function isTreeInteractiveTarget(target, boundary) {
    if (!(target instanceof Element))
        return false;
    let current = target;
    while (current && current !== boundary) {
        if (current.matches(TREE_INTERACTIVE_SELECTOR))
            return true;
        const contentEditable = current.getAttribute('contenteditable');
        if (contentEditable !== null && contentEditable !== 'false')
            return true;
        current = current.parentElement;
    }
    return false;
}
function treeItem(item, expansionTrigger, treeDisabled) {
    const nested = item.children ?? [];
    const rowExpansionEnabled = expansionTrigger === 'row' && !treeDisabled && !item.disabled && nested.length > 0;
    const rowExpansion = { toggleKey: undefined };
    // React Aria's TreeItemProps wants a props-level `children`. This call supplies the item's content and its nested items as
    // variadic arguments instead, because an unkeyed `children: [content, nested]` array draws React's key warnings. So the props
    // are asserted whole, which also covers onClickCapture, a prop React Aria's types do not name.
    const props = {
        id: item.id,
        textValue: item.textValue,
        hasChildItems: nested.length > 0,
        isDisabled: item.disabled,
        className: 'muxui-tree__item',
        onClickCapture: rowExpansionEnabled ? (event) => {
            if (!event.currentTarget.contains(event.target))
                return;
            if (isTreeInteractiveTarget(event.target, event.currentTarget))
                return;
            rowExpansion.toggleKey?.();
        } : undefined,
    };
    return React.createElement(AriaTreeItem, props, 
    // The render function is a prop of React Aria's item content, which TypeScript accepts here and not as a createElement child.
    React.createElement(AriaTreeItemContent, {
        children: ({ state }) => {
            rowExpansion.toggleKey = rowExpansionEnabled ? () => state.toggleKey(item.id) : undefined;
            return React.createElement('div', { className: 'muxui-tree__item-content' }, nested.length ? React.createElement(IconButton, { slot: 'chevron', 'aria-label': 'Toggle', disabled: item.disabled, className: 'muxui-tree__toggle' }, React.createElement(ChevronRightIcon, { 'aria-hidden': 'true', focusable: 'false', fill: 'currentColor', strokeWidth: 0, size: 16 })) : null, React.createElement('span', { className: 'muxui-tree__item-label' }, item.label));
        },
    }), nested.map((child) => React.cloneElement(treeItem(child, expansionTrigger, treeDisabled), { key: child.id })));
}
export const Tree = /*#__PURE__*/ (() => {
    const component = React.forwardRef(function Tree({ items, selectedIds, defaultSelectedIds, expandedIds, defaultExpandedIds, onSelectionChange, onExpandedChange, onAction, selectionMode = 'single', expansionTrigger = 'row', disabled = false, children: _children, className, ...props }, ref) {
        accessibleName({ ariaLabel: props['aria-label'], ariaLabelledby: props['aria-labelledby'] }, 'Tree');
        const normalizedExpansionTrigger = normalizeTreeExpansionTrigger(expansionTrigger);
        // normalizeTreeItems takes no items as an empty list, so an omitted list has no default here to state.
        const normalized = normalizeTreeItems(items);
        const allKeys = treeKeys(normalized);
        const disabledKeys = new Set(disabled ? allKeys : allKeys.filter((key) => findTreeItem(normalized, key)?.disabled));
        const expanded = expandedIds === 'all' ? new Set(allKeys) : keySet(expandedIds);
        const defaultExpanded = defaultExpandedIds === 'all' ? new Set(allKeys) : keySet(defaultExpandedIds);
        const motionControllerRef = React.useRef(null);
        const handleExpandedChange = React.useCallback((keys) => {
            motionControllerRef.current?.beforeExpandedChange();
            if (!disabled)
                onExpandedChange?.(keyList(keys));
        }, [disabled, onExpandedChange]);
        const tree = React.createElement(AriaTree, {
            ...props,
            selectionMode,
            selectedKeys: keySet(selectedIds),
            defaultSelectedKeys: keySet(defaultSelectedIds),
            expandedKeys: expanded,
            defaultExpandedKeys: defaultExpanded,
            disabledKeys,
            onSelectionChange: (keys) => { if (!disabled)
                onSelectionChange?.(keyList(keys)); },
            onExpandedChange: handleExpandedChange,
            ...(onAction ? {
                onAction: (key) => {
                    const item = findTreeItem(normalized, key);
                    if (!disabled && !item?.disabled)
                        onAction(item);
                },
            } : {}),
            // React Aria's Tree props name no isDisabled, and TypeScript accepts such a key in a call only from a spread.
            ...{ isDisabled: disabled },
            className: classNames('muxui-tree', className),
        }, normalized.map((item) => React.cloneElement(treeItem(item, normalizedExpansionTrigger, disabled), { key: item.id })));
        return React.createElement(TreeMotion, { rootRef: ref, controllerRef: motionControllerRef, children: tree });
    });
    component.displayName = 'Tree';
    return component;
})();

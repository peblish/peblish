// @generated-from: packages/react/src/supplemental/input.ts
// @generated-content-sha256: sha256:f67515fc736f5857835072dfd37d7cc092e9b670645fe24c424ec419e7a3cab4
import React from 'react';
import { Label as AriaLabel } from 'react-aria-components';
import { AriaInput } from './substrate.js';
import { h, cx } from './part-utils.js';
import { fieldText } from './field-utils.js';
import { InputAssociationContext, renderFieldRoot } from './field-root.js';
function associatedFieldText(slot, className, props, ref, register) {
    const association = React.useContext(InputAssociationContext);
    const nodeRef = React.useRef(null);
    const setRef = React.useCallback((node) => {
        nodeRef.current = node;
        if (typeof ref === 'function')
            ref(node);
        else if (ref)
            ref.current = node;
        register?.(node?.id);
    }, [ref, register]);
    React.useLayoutEffect(() => {
        register?.(nodeRef.current?.id);
    }, [props.id, register]);
    React.useEffect(() => {
        return () => register?.(undefined);
    }, [register]);
    return fieldText(slot, className, props, setRef);
}
const InputRoot = /*#__PURE__*/ React.forwardRef(function InputRoot({ value, defaultValue, onChange, disabled, invalid, required, readOnly, size = 'md', className, children, ...props }, ref) {
    return renderFieldRoot('muxui-input__root', 'Input', { disabled, invalid, required, readOnly, size, className, children, value, defaultValue, onChange, ...props }, ref);
});
const InputInput = /*#__PURE__*/ React.forwardRef(function InputInput({ disabled, className, 'aria-describedby': ariaDescribedby, ...props }, ref) {
    const association = React.useContext(InputAssociationContext);
    const visualSize = association?.size ?? 'md';
    const describedby = [ariaDescribedby, association?.descriptionId, association?.errorId]
        .filter(Boolean)
        .join(' ') || undefined;
    const inputProps = { ...props, ref, disabled, className: cx('muxui-input', visualSize !== 'md' && `muxui-input--${visualSize}`, className) };
    if (describedby !== undefined)
        inputProps['aria-describedby'] = describedby;
    return h(AriaInput, inputProps);
});
const InputLabel = /*#__PURE__*/ React.forwardRef(function InputLabel(props, ref) { return h(AriaLabel, { ...props, ref, className: cx('muxui-input__label', props.className) }); });
const InputDescription = /*#__PURE__*/ React.forwardRef(function InputDescription(props, ref) {
    const association = React.useContext(InputAssociationContext);
    return associatedFieldText('description', 'muxui-input__description', props, ref, association?.setDescriptionId);
});
const InputError = /*#__PURE__*/ React.forwardRef(function InputError(props, ref) {
    const association = React.useContext(InputAssociationContext);
    return associatedFieldText('errorMessage', 'muxui-input__error', props, ref, association?.setErrorId);
});
export const Input = /*#__PURE__*/ Object.freeze({
    Root: InputRoot,
    Input: InputInput,
    Label: InputLabel,
    Description: InputDescription,
    Error: InputError,
});

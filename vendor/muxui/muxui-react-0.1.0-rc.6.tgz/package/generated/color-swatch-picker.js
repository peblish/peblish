// @generated-from: packages/react/src/color-swatch-picker.ts
// @generated-content-sha256: sha256:b30b53353eb86fe5e95917a1478ae0cba4b7845fac9fde8b2b119d8a2f8a28f5
import React from 'react';
import { ColorSwatch as AriaColorSwatch, parseColor } from 'react-aria-components';
import { AriaColorSwatchPicker, AriaColorSwatchPickerItem } from './substrate.js';
import { classNames, accessibleName } from './control-utils.js';
import { normalizeItems } from './collection-items.js';
import { READ_ONLY_SELECTION_KEYS, readOnlyKeyGuard, useReadOnlyTargets } from './read-only-guard.js';
import { colorValue, ColorPickerContext } from './color-context.js';
// React Aria keys swatch options by colour, so each item needs a distinct colour.
// An explicit item label or textValue becomes the swatch colour name.
// normalizeItems takes no items as an empty list, so an omitted list has no default of the component's to state.
function colorSwatchItems(items = []) {
    const seen = new Set();
    return normalizeItems(items).map((item, index) => {
        const color = colorValue(item.color ?? item.value, 'ColorSwatchPicker');
        const key = color?.toString('hexa');
        if (seen.has(key))
            throw new TypeError(`ColorSwatchPicker items must have distinct colors: ${item.id}`);
        seen.add(key);
        const source = items[index];
        const named = source && typeof source === 'object' && (source.textValue !== undefined || source.label !== undefined);
        return { ...item, color, colorName: named ? item.textValue : undefined };
    });
}
// React Aria treats a null swatch value as uncontrolled, so a controlled empty
// picker selects a transparent black that no item uses.
function unusedSwatchColor(items) {
    const used = new Set(items.map((item) => item.color?.toString('hexa')));
    for (let alpha = 0; alpha < 256; alpha += 1) {
        const color = parseColor(`#000000${alpha.toString(16).padStart(2, '0')}`);
        if (!used.has(color.toString('hexa')))
            return color;
    }
    throw new TypeError('ColorSwatchPicker cannot represent an empty value for these items');
}
export const ColorSwatchPicker = React.forwardRef(function ColorSwatchPicker({ items, value, defaultValue, onChange, disabled = false, readOnly = false, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby }, ref) {
    const normalized = colorSwatchItems(items);
    const pickerState = React.useContext(ColorPickerContext);
    // Conditionals, not ||: extraction reads a fallback on an owned prop as an executed default.
    const effectiveDisabled = disabled ? disabled : pickerState.disabled;
    const effectiveReadOnly = readOnly ? readOnly : pickerState.readOnly;
    accessibleName({ ariaLabel, ariaLabelledby }, 'ColorSwatchPicker');
    const preventReadOnlyInteraction = (event) => {
        if (effectiveReadOnly) {
            event.preventDefault();
            event.stopPropagation();
        }
    };
    const assignSwatchPickerRef = useReadOnlyTargets(ref, effectiveReadOnly, '[role="listbox"]');
    return React.createElement('div', {
        'aria-disabled': effectiveDisabled || undefined,
        // The styles read these data attributes, which React's props do not name, and TypeScript accepts such a key in a call only from a spread.
        ...{ 'data-muxui-state-disabled': effectiveDisabled || undefined, 'data-muxui-state-read-only': effectiveReadOnly || undefined },
        onPointerDownCapture: preventReadOnlyInteraction,
        onMouseDownCapture: preventReadOnlyInteraction,
        onKeyDownCapture: readOnlyKeyGuard(effectiveReadOnly, READ_ONLY_SELECTION_KEYS),
        onTouchStartCapture: preventReadOnlyInteraction,
        onClickCapture: preventReadOnlyInteraction,
        onChangeCapture: preventReadOnlyInteraction,
    }, React.createElement(AriaColorSwatchPicker, {
        ref: assignSwatchPickerRef,
        value: value === null ? unusedSwatchColor(normalized) : colorValue(value, 'ColorSwatchPicker'),
        defaultValue: colorValue(defaultValue, 'ColorSwatchPicker'),
        onChange: (next) => { if (!effectiveDisabled && !effectiveReadOnly)
            onChange?.(next.toString()); },
        // React Aria's props name neither isDisabled nor the data-muxui-state-read-only hook the styles read.
        ...{ isDisabled: effectiveDisabled, 'data-muxui-state-read-only': effectiveReadOnly || undefined },
        'aria-label': ariaLabel,
        'aria-labelledby': ariaLabelledby,
        className: classNames('muxui-color-swatch-picker', className),
    }, normalized.map((item) => React.createElement(AriaColorSwatchPickerItem, {
        key: item.id,
        // An empty colour string parses to no colour. React Aria's item type requires one, and it is handed over as before.
        color: item.color,
        // React Aria's item props name none of these, and TypeScript accepts such a key in a call only from a spread.
        ...{ id: item.id, isDisabled: effectiveDisabled || item.disabled, 'data-muxui-state-read-only': effectiveReadOnly || undefined },
        className: 'muxui-color-swatch-picker__item',
    }, React.createElement(AriaColorSwatch, {
        color: item.color,
        colorName: item.colorName,
        ...{
            isDisabled: effectiveDisabled || item.disabled,
            'data-muxui-state-disabled': effectiveDisabled || item.disabled || undefined,
            'data-muxui-color-paint': 'sample',
        },
        className: 'muxui-color-swatch',
    })))));
});
ColorSwatchPicker.displayName = 'ColorSwatchPicker';

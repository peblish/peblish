// @generated-from: packages/react/src/components.ts
// @generated-content-sha256: sha256:14c0c2d7f9364e53a759d99edd2acd3fdbe85d80cebf7eee71184699a6ae7ba5
import React from 'react';
import CheckIcon from 'lucide-react/dist/esm/icons/check.mjs';
import MinusIcon from 'lucide-react/dist/esm/icons/minus.mjs';
import ChevronDownIcon from 'lucide-react/dist/esm/icons/chevron-down.mjs';
import { Breadcrumbs as AriaBreadcrumbs, DisclosurePanel as AriaDisclosurePanel, Label as AriaLabel, ProgressBar as AriaProgressBar, Separator as AriaSeparator } from 'react-aria-components';
import { AriaBreadcrumb, AriaCheckbox, AriaDisclosure, AriaDisclosureGroup, AriaGroup, AriaLink, AriaToggleButton, AriaButton } from './substrate.js';
import { normalizeToggleButtonSize, ToggleButtonSizeContext } from './toggle-button-context.mjs';
import { normalizeChoiceControlSize, ChoiceControlSizeContext } from './choice-context.mjs';
import { GridListItemDisabledContext } from './grid-list-item-context.mjs';
import { MotionHeight, useDisclosureIconMotion } from './motion-components.mjs';
function classNames(base, className) {
    return [base, className].filter(Boolean).join(' ');
}
// React Aria hands the attributes its types do not name, such as the data-* hooks the styles read,
// through to the DOM. TypeScript accepts such a key in a call only from a spread, so each
// is spread in as an object.
const DisclosureGroupContext = React.createContext(false);
function activationEvent(event, target) {
    return {
        type: 'activate',
        pointerType: event?.pointerType || event?.nativeEvent?.pointerType || (event?.detail === 0 ? 'keyboard' : undefined),
        target,
    };
}
/** A trail of links to the levels above the current page. */
export const Breadcrumbs = React.forwardRef(function Breadcrumbs({ items = [], className, 'aria-label': ariaLabel, onNavigate, ...props }, ref) {
    const collectionItems = items.map((item, index) => {
        const { current: _current, ...itemWithoutCurrent } = item;
        return { ...itemWithoutCurrent, id: item.id ?? String(index) };
    });
    const resolvedAriaLabel = ariaLabel ?? 'Breadcrumbs';
    const navigate = (key) => {
        const item = collectionItems.find((candidate) => String(candidate.id) === String(key));
        if (item && !item.disabled)
            onNavigate?.(item);
    };
    return React.createElement('nav', {
        ...props,
        ref,
        className: classNames('muxui-breadcrumbs', className),
        'aria-label': resolvedAriaLabel,
    }, React.createElement(AriaBreadcrumbs, {
        items: collectionItems,
        className: 'muxui-breadcrumbs__list',
        'aria-label': resolvedAriaLabel,
        onAction: navigate,
        children: (item) => {
            const current = item.id === collectionItems.at(-1)?.id;
            return React.createElement(AriaBreadcrumb, {
                id: item.id,
                ...{ isDisabled: item.disabled, 'data-muxui-state-current': current || undefined, 'data-muxui-state-disabled': item.disabled || undefined },
                className: 'muxui-breadcrumbs__item',
            }, item.href && !current
                ? React.createElement(AriaLink, { href: item.href, isDisabled: item.disabled, ...{ 'data-muxui-state-disabled': item.disabled || undefined }, className: 'muxui-breadcrumbs__link' }, item.label)
                : React.createElement('span', { className: 'muxui-breadcrumbs__current', 'aria-current': current ? 'page' : undefined, 'aria-disabled': item.disabled || undefined, 'data-muxui-state-disabled': item.disabled || undefined }, item.label));
        },
    }));
});
Breadcrumbs.displayName = 'Breadcrumbs';
/** A labelled control that selects or clears one option. */
export const Checkbox = React.forwardRef(function Checkbox({ children, checked, defaultChecked = false, disabled = false, size, indeterminate = false, invalid = false, name, required, value, className, onChange, ...props }, ref) {
    const inheritedSize = React.useContext(ChoiceControlSizeContext);
    // A conditional, not ??: extraction reads a fallback on an owned prop as an executed default, and an inherited size is none.
    const resolvedSize = normalizeChoiceControlSize(size == null ? inheritedSize : size, 'Checkbox');
    return React.createElement(AriaCheckbox, {
        // React Aria passes the native attributes it does not own through to the <label>; its focus and
        // keyboard handler types name Element where React's name HTMLLabelElement.
        ...props,
        ref,
        className: classNames(`muxui-checkbox${resolvedSize === 'md' ? '' : ` muxui-checkbox--${resolvedSize}`}`, className),
        ...{ 'data-muxui-size': resolvedSize },
        isSelected: checked,
        defaultSelected: defaultChecked,
        isDisabled: disabled,
        isIndeterminate: indeterminate,
        isInvalid: invalid,
        // Undefined lets a checkbox inherit its CheckboxGroup's required state.
        ...(required === undefined ? {} : { isRequired: required }),
        name,
        value,
        onChange,
        children: ({ isSelected, isIndeterminate }) => React.createElement(React.Fragment, null, React.createElement('span', {
            className: 'muxui-checkbox__indicator',
            'aria-hidden': 'true',
            'data-muxui-state-selected': isSelected || undefined,
            'data-muxui-state-indeterminate': isIndeterminate || undefined,
        }, isIndeterminate || isSelected
            ? React.createElement(isIndeterminate ? MinusIcon : CheckIcon, { 'aria-hidden': 'true', focusable: 'false', size: 12 })
            : null), React.createElement('span', { className: 'muxui-checkbox__label' }, children)),
    });
});
Checkbox.displayName = 'Checkbox';
/** A set of related Disclosures whose expansion the group owns. */
export const DisclosureGroup = React.forwardRef(function DisclosureGroup({ children, expandedIds, defaultExpandedIds = [], multiple = true, disabled = false, className, onExpandedChange, ...props }, ref) {
    const mapKeys = (keys) => new Set((keys ?? []).map(String));
    return React.createElement(AriaDisclosureGroup, {
        ...props,
        ref,
        className: classNames('muxui-disclosure-group', className),
        isDisabled: disabled,
        allowsMultipleExpanded: multiple,
        expandedKeys: expandedIds === undefined ? undefined : mapKeys(expandedIds),
        defaultExpandedKeys: mapKeys(defaultExpandedIds),
        onExpandedChange: (keys) => onExpandedChange?.([...keys].map(String)),
    }, React.createElement(DisclosureGroupContext.Provider, { value: true }, children));
});
DisclosureGroup.displayName = 'DisclosureGroup';
function DisclosureChevron({ isOpen, grouped }) {
    const ref = React.useRef(null);
    useDisclosureIconMotion(ref, isOpen, grouped);
    return React.createElement(ChevronDownIcon, { ref, className: 'muxui-disclosure__trigger-icon', 'aria-hidden': 'true', focusable: 'false' });
}
// The pure-annotated wrapper lets a bundle that never uses Disclosure drop it and its motion edge.
/** A section of optional content that a trigger button opens and closes. */
export const Disclosure = /*#__PURE__*/ (() => {
    const component = React.forwardRef(function Disclosure({ title, children, id, expanded, defaultExpanded = false, disabled = false, className, onExpandedChange, ...props }, ref) {
        const grouped = React.useContext(DisclosureGroupContext);
        const triggerRef = React.useRef(null);
        const panelHostRef = React.useRef(null);
        return React.createElement(AriaDisclosure, {
            ...props,
            ref,
            className: classNames('muxui-disclosure', className),
            id,
            isExpanded: expanded,
            defaultExpanded,
            isDisabled: disabled,
            onExpandedChange,
            children: ({ isExpanded }) => {
                const trigger = React.createElement(AriaButton, { ref: triggerRef, slot: 'trigger', className: 'muxui-disclosure__trigger' }, title, grouped
                    ? React.createElement(DisclosureChevron, { isOpen: isExpanded, grouped })
                    : null);
                return React.createElement(React.Fragment, null, grouped ? React.createElement('div', { className: 'muxui-disclosure__header' }, trigger) : trigger, React.createElement(AriaDisclosurePanel, {
                    ref: panelHostRef,
                    role: 'region',
                    className: 'muxui-disclosure__panel-host',
                    children: React.createElement(MotionHeight, { isOpen: isExpanded, triggerRef, hostRef: panelHostRef, className: 'muxui-disclosure__motion-panel', grouped }, children),
                }));
            },
        });
    });
    component.displayName = 'Disclosure';
    return component;
})();
/** Related controls under one named boundary. */
export const Group = React.forwardRef(function Group({ children, disabled = false, invalid = false, readOnly = false, role = 'group', className, ...props }, ref) {
    return React.createElement(AriaGroup, {
        ...props,
        ref,
        role,
        className: classNames('muxui-group', className),
        isDisabled: disabled,
        isInvalid: invalid,
        isReadOnly: readOnly,
        // Conditionals, not ||: extraction reads a fallback on an owned prop as an executed default. Each keeps the prop's own value when it is truthy.
        'aria-disabled': disabled ? disabled : undefined,
        'aria-invalid': invalid ? invalid : undefined,
    }, children);
});
Group.displayName = 'Group';
/** A link to another location. */
export const Link = React.forwardRef(function Link({ children, href, disabled, current = false, target, rel, className, onActivate, ...props }, ref) {
    // Like Button, an undefined disabled inherits a disabled GridList item; an explicit false still
    // wins. A Link without an href is always disabled, and an empty href is not forwarded because
    // React warns about it. The RAC Link always gets an explicit isDisabled.
    const inheritedDisabled = React.useContext(GridListItemDisabledContext);
    return React.createElement(AriaLink, {
        // React Aria passes the native attributes it does not own through to the <a>; its focus and
        // keyboard handler types name Element where React's name HTMLElement.
        ...props,
        // The public ref type is HTMLElement, a supertype of the anchor React Aria attaches it to.
        ref: ref,
        // Conditionals, not || and ??: extraction reads a fallback on an owned prop as an executed default.
        href: href ? href : undefined,
        isDisabled: !href || (disabled == null ? inheritedDisabled : disabled),
        target,
        rel,
        className: classNames('muxui-link', className),
        ...{ 'aria-current': current ? 'page' : undefined },
        onPress: (event) => onActivate?.(activationEvent(event, event.target)),
    }, children);
});
Link.displayName = 'Link';
/** A reading within a known range. */
export const Meter = React.forwardRef(function Meter({ value = 0, minValue = 0, maxValue = 100, label, formatOptions, className, ...props }, ref) {
    const externalLabel = props['aria-label'];
    const externalLabelledby = props['aria-labelledby'];
    const labelId = React.useId();
    const boundedValue = Math.min(maxValue, Math.max(minValue, value));
    const percentage = maxValue === minValue ? 0 : ((boundedValue - minValue) / (maxValue - minValue)) * 100;
    // A conditional, not ??: the percent format is the omitted formatOptions' behaviour, not a default the block states.
    const formatter = new Intl.NumberFormat(undefined, formatOptions == null ? { style: 'percent' } : formatOptions);
    const valueText = formatter.format(!formatOptions || formatOptions.style === 'percent' ? percentage / 100 : boundedValue);
    return React.createElement('div', {
        ...props,
        ref,
        role: 'meter',
        className: classNames('muxui-meter', className),
        'aria-label': externalLabel,
        'aria-labelledby': externalLabelledby ?? (externalLabel ? undefined : labelId),
        'aria-valuenow': boundedValue,
        'aria-valuemin': minValue,
        'aria-valuemax': maxValue,
        'aria-valuetext': valueText,
    }, React.createElement('div', { className: 'muxui-meter__header' }, !externalLabel && !externalLabelledby
        ? React.createElement(AriaLabel, { id: labelId, elementType: 'span', className: 'muxui-value-label' }, label)
        : null, React.createElement('span', { className: 'muxui-value-output' }, valueText)), React.createElement('div', { className: 'muxui-meter__track' }, React.createElement('div', { className: 'muxui-meter__fill', style: { inlineSize: `${percentage}%` } })));
});
Meter.displayName = 'Meter';
/** How far a task has got. */
export const ProgressBar = React.forwardRef(function ProgressBar({ value, minValue = 0, maxValue = 100, label, className, ...props }, ref) {
    const complete = value !== undefined && !Number.isNaN(value) && maxValue > minValue && value >= maxValue;
    return React.createElement(AriaProgressBar, {
        ...props,
        ref,
        // A conditional, not ??: an omitted value is indeterminate, so the 0 is no default of the prop.
        value: value == null ? 0 : value,
        minValue,
        maxValue,
        isIndeterminate: value === undefined,
        ...{ 'data-muxui-state-indeterminate': value === undefined || undefined, 'data-muxui-complete': complete || undefined },
        className: classNames('muxui-progress-bar', className),
        children: ({ percentage }) => React.createElement(React.Fragment, null, React.createElement('div', { className: 'muxui-progress-bar__header' }, React.createElement(AriaLabel, { className: 'muxui-value-label' }, label), React.createElement('span', { className: 'muxui-value-output' }, value === undefined ? 'Loading' : `${percentage}%`)), React.createElement('div', { className: 'muxui-progress-bar__track' }, React.createElement('div', { className: 'muxui-progress-bar__fill', style: percentage === undefined ? undefined : { inlineSize: `${percentage}%` } }))),
    });
});
ProgressBar.displayName = 'ProgressBar';
/** A line that separates content. */
export const Separator = React.forwardRef(function Separator({ orientation = 'horizontal', className, ...props }, ref) {
    return React.createElement(AriaSeparator, {
        ...props,
        ref,
        orientation,
        className: classNames(`muxui-separator muxui-separator--${orientation}`, className),
    });
});
Separator.displayName = 'Separator';
/** A button that turns a persistent mode or option on and off. */
export const ToggleButton = React.forwardRef(function ToggleButton({ children, selected, defaultSelected = false, disabled = false, size, className, onChange, onActivate, ...props }, ref) {
    const inheritedSize = React.useContext(ToggleButtonSizeContext);
    // A conditional, not ??: extraction reads a fallback on an owned prop as an executed default, and an inherited size is none.
    const resolvedSize = normalizeToggleButtonSize(size == null ? inheritedSize : size);
    return React.createElement(AriaToggleButton, {
        // React Aria passes the native attributes it does not own through to the <button>; its pointer
        // handler types name another element where React's name HTMLButtonElement.
        ...props,
        ref,
        isSelected: selected,
        defaultSelected,
        isDisabled: disabled,
        className: classNames(`muxui-toggle-button muxui-toggle-button--${resolvedSize}`, className),
        ...{ 'data-muxui-size': resolvedSize },
        onChange,
        onPress: (event) => onActivate?.(activationEvent(event, event.target)),
    }, children);
});
ToggleButton.displayName = 'ToggleButton';

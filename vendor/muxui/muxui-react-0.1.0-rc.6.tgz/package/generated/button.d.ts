// @generated-from: packages/react/src/button.ts
// @generated-content-sha256: sha256:215c08ba2c64c2645aa1e0a7cdc6a7eb08785a64f91daab6e4c7c91e6c7b2afe
import type { ButtonHTMLAttributes, CSSProperties, ForwardRefExoticComponent, MouseEvent, ReactNode, RefAttributes } from 'react';
export type ButtonPointerType = 'mouse' | 'pen' | 'touch' | 'keyboard' | 'virtual' | undefined;
/** The visual recipes Button and IconButton share. */
export type ButtonVariant = 'primary' | 'neutral' | 'ghost' | 'danger' | 'danger-neutral' | 'danger-ghost' | 'inverse';
/** The control sizes Button and IconButton share. */
export type ButtonSize = 'sm' | 'md' | 'lg';
/** What `onActivate` reports for one activation. */
export interface ButtonActivationEvent {
    readonly type: 'activate';
    readonly pointerType: ButtonPointerType;
    readonly target: HTMLButtonElement;
}
/**
 * The props Mux UI defines for Button; the catalog's web.react API is derived
 * from this interface (Decision 0031).
 */
export interface ButtonOwnProps {
    /** Applies the native disabled attribute: the Button is neither focusable nor activatable. */
    disabled?: boolean;
    /** Marks an action in flight: the Button shows a spinner, stays focusable, and does not activate. */
    pending?: boolean;
    /** Keeps the label visible beside the spinner while pending. */
    showTextWhileLoading?: boolean;
    /** The visual recipe, chosen by the action's emphasis and consequence. */
    variant?: ButtonVariant;
    /** The control size. */
    size?: ButtonSize;
    /** Requests the Button's one immediate action. */
    onActivate?: (event: ButtonActivationEvent) => void;
}
/** Button's props: its own props and the native button attributes it passes through. */
export interface ButtonProps extends ButtonOwnProps, Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children' | 'className' | 'disabled' | 'onClick' | 'style'> {
    children?: ReactNode;
    className?: string;
    style?: CSSProperties;
}
/**
 * DOM button props that keep a pending submit button from submitting its form, or `undefined`
 * when `pending` and `type` do not call for them. Spread them onto the rendered `<button>` of
 * a React Aria Button (Button and Card.Button) after its own DOM props.
 */
export declare function usePendingSubmitProps(pending: boolean | undefined, type: ButtonHTMLAttributes<HTMLButtonElement>['type']): {
    type: 'submit';
    onClick: (event: MouseEvent<HTMLButtonElement>) => void;
    disabled?: boolean | undefined;
} | undefined;
/**
 * Mux UI's Button is an immediate-action control. The React Aria primitive is
 * deliberately kept behind this boundary so the public package can replace
 * its substrate without changing the MuxUI contract.
 */
export declare const Button: ForwardRefExoticComponent<ButtonProps & RefAttributes<HTMLButtonElement>>;

// @generated-from: packages/react/src/dialog-motion.mjs
// @generated-content-sha256: sha256:721ccd64a1822c405fb042feed9dda668f9656c5d081213be8028f5c477e75fe
import React from 'react';
import { animate } from 'motion/react';
import { OverlayTriggerStateContext, PopoverContext } from 'react-aria-components';
import { AriaModal } from './substrate.js';
import { observeReducedMotion, resolvedMotionSpring, resolvedMotionTransition } from './motion.mjs';

const DIALOG_REDUCED_ATTRIBUTE = 'data-muxui-dialog-reduced';
const MODAL_INITIAL_Y = -8;
const MODAL_EXIT_Y = -8;
const MODAL_SETTLED_Y = 0;
const MODAL_INITIAL_SCALE = 0.97;
const MODAL_SETTLED_SCALE = 1;
const MODAL_Y_VARIABLE = '--muxui-modal-y';
const MODAL_SCALE_VARIABLE = '--muxui-modal-scale';
const useIsomorphicLayoutEffect = typeof window === 'undefined' ? React.useEffect : React.useLayoutEffect;

function parseTranslate(value) {
  const match = /^\s*(-?(?:\d+\.?\d*|\.\d+))px(?:\s+(-?(?:\d+\.?\d*|\.\d+))px)?/u.exec(String(value ?? ''));
  return match ? Number(match[2] ?? match[1]) : MODAL_SETTLED_Y;
}

function parseScale(value) {
  const normalized = String(value ?? '').trim();
  if (!normalized || normalized === 'none') return MODAL_SETTLED_SCALE;
  const scale = Number(normalized.split(/\s+/u)[0]);
  return Number.isFinite(scale) && scale > 0 ? scale : MODAL_SETTLED_SCALE;
}

function readModalValues(node) {
  if (typeof window === 'undefined') return { opacity: 1, y: MODAL_SETTLED_Y, scale: MODAL_SETTLED_SCALE };
  const style = window.getComputedStyle(node);
  const opacity = Number(style.opacity);
  return {
    opacity: Number.isFinite(opacity) ? Math.min(1, Math.max(0, opacity)) : 1,
    y: parseTranslate(style.getPropertyValue(MODAL_Y_VARIABLE)),
    scale: parseScale(style.getPropertyValue(MODAL_SCALE_VARIABLE)),
  };
}

function modalHiddenValues(fade = true) {
  return { opacity: fade ? 0 : 1, y: MODAL_EXIT_Y, scale: MODAL_INITIAL_SCALE };
}

function modalTargetValues(isOpen, fade) {
  return isOpen
    ? { opacity: 1, y: MODAL_SETTLED_Y, scale: MODAL_SETTLED_SCALE }
    : modalHiddenValues(fade);
}

// The panel runs the modal spring and exits on the modal-dismiss composite; the
// backdrop reads the same two composites in CSS, so both move in step.
function modalTransition(node, triggerNode, isOpen) {
  if (!isOpen) return resolvedMotionTransition(node, triggerNode, 'exit', 'modal');
  const spring = resolvedMotionSpring(node, triggerNode, 'modal-enter', 'modal');
  return spring && { type: 'spring', visualDuration: spring.visualDuration, bounce: spring.bounce };
}

function styleValues(node, values) {
  node.style.opacity = String(values.opacity);
  node.style.setProperty(MODAL_Y_VARIABLE, `${values.y}px`);
  node.style.setProperty(MODAL_SCALE_VARIABLE, String(values.scale));
}

function originalStyles(node) {
  return {
    opacity: node.style.opacity,
    opacityPriority: node.style.getPropertyPriority('opacity'),
    y: node.style.getPropertyValue(MODAL_Y_VARIABLE),
    yPriority: node.style.getPropertyPriority(MODAL_Y_VARIABLE),
    scale: node.style.getPropertyValue(MODAL_SCALE_VARIABLE),
    scalePriority: node.style.getPropertyPriority(MODAL_SCALE_VARIABLE),
  };
}

function restoreStyles(node, original) {
  if (!original) return;
  if (original.opacity) node.style.setProperty('opacity', original.opacity, original.opacityPriority);
  else node.style.removeProperty('opacity');
  if (original.y) node.style.setProperty(MODAL_Y_VARIABLE, original.y, original.yPriority);
  else node.style.removeProperty(MODAL_Y_VARIABLE);
  if (original.scale) node.style.setProperty(MODAL_SCALE_VARIABLE, original.scale, original.scalePriority);
  else node.style.removeProperty(MODAL_SCALE_VARIABLE);
}

/**
 * Own the pixels of a finite modal open/close cycle while RAC retains portal,
 * focus, dismissal, and inertness ownership. Modal-only CSS variables compose
 * the panel's y/scale motion with each surface's existing centering transform.
 * `fade: false` keeps the panel at full opacity while it slides and scales, for
 * a panel with a backdrop filter: any fade shows the unfiltered page through it.
 */
export function useModalMotion({ node, isOpen, triggerRef, reducedAttribute = 'data-muxui-motion-reduced', fade = true, onExitComplete, onReducedChange }) {
  const isOpenRef = React.useRef(Boolean(isOpen));
  const controlsRef = React.useRef(null);
  const valuesRef = React.useRef(null);
  const originalStylesRef = React.useRef(null);
  const animatedNodeRef = React.useRef(null);
  const phaseRef = React.useRef(null);
  const animationIdRef = React.useRef(0);
  const onExitCompleteRef = React.useRef(onExitComplete);
  const onReducedChangeRef = React.useRef(onReducedChange);
  onExitCompleteRef.current = onExitComplete;
  onReducedChangeRef.current = onReducedChange;
  isOpenRef.current = Boolean(isOpen);

  const finishExit = React.useCallback((animationId) => {
    if (animationId !== animationIdRef.current || isOpenRef.current || phaseRef.current !== 'exit') return;
    phaseRef.current = null;
    controlsRef.current = null;
    onExitCompleteRef.current?.();
  }, []);

  const stopControls = React.useCallback((controls) => {
    controls?.stop();
    controls?.cancel?.();
    if (controlsRef.current === controls) controlsRef.current = null;
  }, []);

  useIsomorphicLayoutEffect(() => {
    if (!node || node.nodeType !== 1 || !node.isConnected) return undefined;
    originalStylesRef.current = originalStyles(node);
    valuesRef.current = null;
    return () => {
      animationIdRef.current += 1;
      stopControls(controlsRef.current);
      valuesRef.current = null;
      originalStylesRef.current = null;
      animatedNodeRef.current = null;
    };
  }, [node, stopControls]);

  useIsomorphicLayoutEffect(() => {
    if (!node || node.nodeType !== 1 || !node.isConnected) return undefined;
    const disconnect = observeReducedMotion(node, triggerRef?.current, (reduced) => {
      node.toggleAttribute(reducedAttribute, reduced);
      onReducedChangeRef.current?.(reduced);
      if (!reduced) return;
      animationIdRef.current += 1;
      stopControls(controlsRef.current);
      if (!node.isConnected) return;
      // A reduced close hides the panel at once, so it takes the faded values whether or not the panel fades.
      const target = modalTargetValues(Boolean(isOpenRef.current));
      styleValues(node, target);
      valuesRef.current = target;
      if (!isOpenRef.current && phaseRef.current === 'exit') finishExit(animationIdRef.current);
    });
    return () => {
      disconnect();
      node.removeAttribute(reducedAttribute);
      onReducedChangeRef.current?.(false);
    };
  }, [finishExit, node, reducedAttribute, stopControls, triggerRef]);

  useIsomorphicLayoutEffect(() => {
    if (!node || node.nodeType !== 1 || !node.isConnected) return undefined;
    const animationId = animationIdRef.current + 1;
    animationIdRef.current = animationId;
    const initialOpen = Boolean(isOpen) && animatedNodeRef.current !== node;
    animatedNodeRef.current = node;
    const from = initialOpen ? modalHiddenValues(fade) : valuesRef.current ?? readModalValues(node);
    const to = modalTargetValues(Boolean(isOpen), fade);
    const transition = modalTransition(node, triggerRef?.current, Boolean(isOpen));
    let controls = null;
    let active = true;
    let completed = false;
    phaseRef.current = isOpen ? 'entry' : 'exit';

    const complete = () => {
      if (completed || !active || animationId !== animationIdRef.current || !node.isConnected) return;
      completed = true;
      if (controlsRef.current === controls) controlsRef.current = null;
      valuesRef.current = to;
      if (isOpen) restoreStyles(node, originalStylesRef.current);
      else styleValues(node, to);
      if (!isOpen) finishExit(animationId);
    };

    if (!transition) {
      complete();
      return () => {
        if (phaseRef.current === (isOpen ? 'entry' : 'exit')) phaseRef.current = null;
      };
    }

    const values = { opacity: from.opacity, y: from.y, scale: from.scale };
    const apply = (progress) => {
      if (!active || animationId !== animationIdRef.current || !node.isConnected) return;
      values.opacity = from.opacity + ((to.opacity - from.opacity) * progress);
      values.y = from.y + ((to.y - from.y) * progress);
      values.scale = from.scale + ((to.scale - from.scale) * progress);
      valuesRef.current = values;
      styleValues(node, values);
    };
    apply(0);
    controls = animate(0, 1, { ...transition, onUpdate: apply, onComplete: complete });
    controlsRef.current = controls;
    controls.then(() => {
      if (!active || animationId !== animationIdRef.current) return;
      complete();
    });
    return () => {
      active = false;
      if (node.isConnected) valuesRef.current = readModalValues(node);
      stopControls(controls);
      if (phaseRef.current === (isOpen ? 'entry' : 'exit')) phaseRef.current = null;
    };
  }, [fade, finishExit, isOpen, node, stopControls, triggerRef]);

  React.useEffect(() => () => {
    animationIdRef.current += 1;
    stopControls(controlsRef.current);
  }, [stopControls]);

  return null;
}

/**
 * Motion owns the panel pixels while RAC owns the modal lifecycle and focus behavior.
 * The parent supplies isExiting so RAC retains the portal until onExitComplete fires.
 */
export function DialogMotion({ children, originRef, onExitComplete, onReducedChange }) {
  const state = React.useContext(OverlayTriggerStateContext);
  const popoverContext = React.useContext(PopoverContext);
  const triggerRef = popoverContext?.triggerRef;
  const isOpen = Boolean(state?.isOpen);
  const [modalNode, setModalNode] = React.useState(null);
  const panel = modalNode?.querySelector('.muxui-dialog') ?? null;
  useModalMotion({
    node: panel,
    isOpen,
    triggerRef: triggerRef ?? originRef,
    reducedAttribute: DIALOG_REDUCED_ATTRIBUTE,
    onExitComplete,
    onReducedChange,
  });

  const assignModalRef = React.useCallback((node) => {
    setModalNode(node);
  }, []);

  return React.createElement(AriaModal, { ref: assignModalRef, className: 'muxui-dialog__modal' }, children);
}

// @generated-from: packages/react/src/generate.mjs
// @generated-content-sha256: sha256:a38133316488550c6113b864ae99e5149d73e9acddb536cdd51f053d2e7cbbdf
export const reactPlatformSafetyFixture = Object.freeze({ componentSupportClaim: 'none', fixture: 'react-breadth', discovery: 'informational' });

// @generated-from: packages/react/src/toolbar.ts
// @generated-content-sha256: sha256:13c5d65f6256662d9b82de8f6bb66679cf3563b81f3a6d082a4d02944dc18225
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUIAriaAccessibleName } from './fields.js';
/**
 * The props Mux UI defines for Toolbar. The controls it groups are its children, and it is named by
 * aria-label or aria-labelledby.
 */
export type ToolbarOwnProps = {
    /** The direction the controls are laid out and the arrow keys move focus along. Vertical stacks them in a column. */
    orientation?: 'horizontal' | 'vertical';
    /** The look of the toolbar itself. `contained` draws a filled, bordered surface around the controls; `plain` draws none, so the controls sit on the surface around them. Keyboard behaviour is the same in both. */
    variant?: 'contained' | 'plain';
};
export type ToolbarProps = ToolbarOwnProps & {
    children?: ReactNode;
    className?: string;
} & MuxUIAriaAccessibleName;
export declare const Toolbar: ForwardRefExoticComponent<ToolbarProps & RefAttributes<HTMLDivElement>>;

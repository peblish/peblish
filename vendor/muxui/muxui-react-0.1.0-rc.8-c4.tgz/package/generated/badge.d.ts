// @generated-from: packages/react/src/supplemental/badge.ts
// @generated-content-sha256: sha256:cbcd3372eea677929518b18aa1cbdd921c51be1717794943283aaa366a03a86e
import type { ForwardRefExoticComponent, HTMLAttributes, ReactNode, RefAttributes } from 'react';
/** The tones of a Badge, the same semantic tones as TagGroup's. */
export type BadgeTone = 'neutral' | 'brand' | 'success' | 'warning' | 'error';
/** How strongly a Badge is filled: a soft tint, or a solid fill for a mark that must stand out, such as a count. */
export type BadgeVariant = 'soft' | 'solid';
/**
 * The props Mux UI defines for Badge; the catalog's web.react API is derived from this type (Decision 0031).
 * A Badge is passive text: it has no role, takes no focus and does nothing when pressed.
 */
type BadgeOwnProps = {
    /** The badge's colour. Its text says what it means; the tone only supports it. */
    tone?: BadgeTone;
    /** A soft tint, or a solid fill. */
    variant?: BadgeVariant;
    /** A decorative icon before the text, hidden from assistive technology. */
    icon?: ReactNode;
    /** What assistive technology reads in place of the visible text, when the text is not enough on its own, such as 12 unread for 12. */
    label?: string;
};
export type BadgeProps = BadgeOwnProps & Omit<HTMLAttributes<HTMLSpanElement>, keyof BadgeOwnProps | 'role' | 'tabIndex' | 'dangerouslySetInnerHTML'>;
/** A small passive label for a role, a flag or a count. */
export declare const Badge: ForwardRefExoticComponent<BadgeProps & RefAttributes<HTMLSpanElement>>;
export {};

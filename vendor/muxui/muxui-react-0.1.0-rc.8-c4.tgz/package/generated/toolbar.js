// @generated-from: packages/react/src/toolbar.ts
// @generated-content-sha256: sha256:e72abba8cdc873dc8696109b0e32b04d4c36ce2cbd4ffd652a89efd097e50cbf
import React from 'react';
import { AriaToolbar } from './substrate.js';
import { classNames, accessibleName } from './control-utils.js';
// The wrapper also takes and drops a `disabled`, which its public type does not offer: a Toolbar does not
// disable the controls it groups, and the attribute must not reach the DOM.
export const Toolbar = React.forwardRef(function Toolbar({ orientation = 'horizontal', variant = 'contained', disabled: _disabled, children, className, ...props }, ref) {
    accessibleName({ ariaLabel: props['aria-label'], ariaLabelledby: props['aria-labelledby'] }, 'Toolbar');
    if (variant !== 'contained' && variant !== 'plain')
        throw new TypeError('Toolbar variant must be contained or plain');
    // React Aria's props do not name the data-* hooks the styles read, and TypeScript accepts such a key in a call only from a spread.
    return React.createElement(AriaToolbar, { ...props, ref, orientation, ...{ 'data-muxui-variant': variant }, className: classNames('muxui-toolbar', className) }, children);
});
Toolbar.displayName = 'Toolbar';

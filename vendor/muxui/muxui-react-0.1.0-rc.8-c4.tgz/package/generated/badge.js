// @generated-from: packages/react/src/supplemental/badge.ts
// @generated-content-sha256: sha256:b11314b93b45993c3534f5fe716150ee63b807e8e431b5ed09ab7e92ad9156b4
import React from 'react';
import { cx, h } from './part-utils.js';
// Keyed by the types, so a value added to one must be added here too.
const TONES = { neutral: true, brand: true, success: true, warning: true, error: true };
const VARIANTS = { soft: true, solid: true };
/** A small passive label for a role, a flag or a count. */
export const Badge = /*#__PURE__*/ React.forwardRef(function Badge({ tone = 'neutral', variant = 'soft', icon, label, className, children, 
// Not Badge props: an untyped caller's role, focus stop and HTML never reach the badge.
role: _role, tabIndex: _tabIndex, dangerouslySetInnerHTML: _html, ...props }, ref) {
    if (typeof tone !== 'string' || !Object.hasOwn(TONES, tone))
        throw new TypeError(`Badge tone must be one of: ${Object.keys(TONES).join(', ')}.`);
    if (typeof variant !== 'string' || !Object.hasOwn(VARIANTS, variant))
        throw new TypeError(`Badge variant must be one of: ${Object.keys(VARIANTS).join(', ')}.`);
    // With a label, the visible text is hidden from assistive technology and the label is read in its place.
    const named = typeof label === 'string' && label.length > 0;
    return h('span', { ...props, ref, className: cx('muxui-badge', className), 'data-muxui-tone': tone, 'data-muxui-variant': variant }, icon != null && icon !== false && h('span', { className: 'muxui-badge__icon', 'aria-hidden': true }, icon), children != null && children !== false && h('span', { className: 'muxui-badge__text', 'aria-hidden': named || undefined }, children), named && h('span', { className: 'muxui-badge__label' }, label));
});

// @generated-from: packages/react/src/supplemental/modal-parts.ts
// @generated-content-sha256: sha256:e120f6d8d17de8ce6c9e6bacc5b77afe35bcab59a1a3a06f15788df5a7e5454e
import type { ForwardRefExoticComponent, HTMLAttributes, RefAttributes, RefObject } from 'react';
export type MotionModalBackdropProps = HTMLAttributes<HTMLDivElement> & {
    isOpen?: boolean;
    onOpenChange?: (isOpen: boolean) => void;
    isDismissable?: boolean;
    triggerRef?: RefObject<Element | null>;
};
export type MotionModalPopupProps = HTMLAttributes<HTMLDivElement> & {
    isExiting?: boolean;
    fade?: boolean;
};
export declare const MotionModalBackdropForwardRef: ForwardRefExoticComponent<MotionModalBackdropProps & RefAttributes<HTMLDivElement>>;
export declare const MotionModalPopupForwardRef: ForwardRefExoticComponent<MotionModalPopupProps & RefAttributes<HTMLDivElement>>;

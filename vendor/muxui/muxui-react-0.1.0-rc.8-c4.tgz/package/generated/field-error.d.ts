// @generated-from: packages/react/src/field-error.ts
// @generated-content-sha256: sha256:7d3b68af7525519176cea53449cee8af3647431dc3c0baca33b2dea86c92e0fe
import type { Context, ForwardRefExoticComponent, ForwardedRef, HTMLAttributes, ReactElement, ReactNode, RefAttributes } from 'react';
/** The native props of an error part: its element's attributes, and a className. */
type FieldErrorProps<E extends HTMLElement> = HTMLAttributes<E> & {
    className?: string;
};
/**
 * The id a field's text part renders with: the caller's, else React Aria's id for its slot, else, when React Aria has
 * none because the part mounted after it resolved the field's ids, a stable one of its own. `late` is true when React
 * Aria will not name the part in the control's aria-describedby by itself.
 */
export declare function useSlotPartId(slot: 'description' | 'errorMessage', callerId: string | undefined): {
    id: string;
    late: boolean;
};
/** `children` in a LateErrorScope for the control that reads `context`. */
export declare function lateErrorScope<V>(context: Context<V>, ...children: ReactNode[]): ReactElement;
/**
 * Keeps the field's LateErrorScope in step with an error part rendered with `id` (from useSlotPartId): while `shown`,
 * a late id is added to the control's aria-describedby, and once the part is gone, React Aria's own id is taken out.
 */
export declare function useErrorLink(id: string, late: boolean, shown: boolean): void;
/**
 * Renders a field's error part as React Aria's FieldError does: in the field's error slot, only while the field is
 * invalid, with the caller's children or else the validation messages, and linked to the control even when it
 * mounts late (see LateErrorScope). Unlike FieldError, which keeps only an id, data-* and a few global attributes,
 * it passes every native attribute through, so a caller can give it a role, aria-live or a title. It calls hooks, so
 * a part calls it unconditionally from its render function.
 */
export declare function fieldError<E extends HTMLElement>(className: string, props: FieldErrorProps<E>, ref: ForwardedRef<E>): ReactElement | null;
/** FieldError's place in a component that is not a compound part: an error part with its className and message. */
export declare const FieldErrorText: ForwardRefExoticComponent<FieldErrorProps<HTMLElement> & RefAttributes<HTMLElement>>;
export {};

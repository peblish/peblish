// @generated-from: packages/react/src/supplemental/input.ts
// @generated-content-sha256: sha256:3b5c4a4ec2f4730b28e83a99aac4073ec637811331c7b8d89a22c7286b53f5fa
import React from 'react';
import { Label as AriaLabel } from 'react-aria-components';
import { AriaInput } from './substrate.js';
import { h, cx, useIsomorphicLayoutEffect } from './part-utils.js';
import { fieldText } from './field-utils.js';
import { useErrorLink, useSlotPartId } from './field-error.js';
import { InputAssociationContext, renderFieldRoot } from './field-root.js';
// The part renders with React Aria's slot id, or with its own when it mounted after React Aria resolved the field's
// ids, and registers the id it renders with, so Input.Input names it from the commit in which it appears. Input.Input
// then falls back to React Aria's aria-describedby, which keeps an error's id once the error is gone; useErrorLink
// takes it out.
function associatedFieldText(slot, className, props, ref, register) {
    const { id, late } = useSlotPartId(slot, props.id);
    useErrorLink(id, late, slot === 'errorMessage');
    useIsomorphicLayoutEffect(() => {
        register?.(id);
        return () => register?.((current) => current === id ? undefined : current);
    }, [id, register]);
    return fieldText(slot, className, { ...props, id }, ref);
}
const InputRoot = /*#__PURE__*/ React.forwardRef(function InputRoot({ value, defaultValue, onChange, disabled, invalid, required, readOnly, size = 'md', className, children, ...props }, ref) {
    return renderFieldRoot('muxui-input__root', 'Input', { disabled, invalid, required, readOnly, size, className, children, value, defaultValue, onChange, ...props }, ref);
});
const InputInput = /*#__PURE__*/ React.forwardRef(function InputInput({ disabled, className, 'aria-describedby': ariaDescribedby, ...props }, ref) {
    const association = React.useContext(InputAssociationContext);
    const visualSize = association?.size ?? 'md';
    const describedby = [ariaDescribedby, association?.descriptionId, association?.errorId]
        .filter(Boolean)
        .join(' ') || undefined;
    const inputProps = { ...props, ref, disabled, className: cx('muxui-input', visualSize !== 'md' && `muxui-input--${visualSize}`, className) };
    if (describedby !== undefined)
        inputProps['aria-describedby'] = describedby;
    return h(AriaInput, inputProps);
});
const InputLabel = /*#__PURE__*/ React.forwardRef(function InputLabel(props, ref) { return h(AriaLabel, { ...props, ref, className: cx('muxui-input__label', props.className) }); });
const InputDescription = /*#__PURE__*/ React.forwardRef(function InputDescription(props, ref) {
    const association = React.useContext(InputAssociationContext);
    return associatedFieldText('description', 'muxui-input__description', props, ref, association?.setDescriptionId);
});
const InputError = /*#__PURE__*/ React.forwardRef(function InputError(props, ref) {
    const association = React.useContext(InputAssociationContext);
    return associatedFieldText('errorMessage', 'muxui-input__error', props, ref, association?.setErrorId);
});
export const Input = /*#__PURE__*/ Object.freeze({
    Root: InputRoot,
    Input: InputInput,
    Label: InputLabel,
    Description: InputDescription,
    Error: InputError,
});

// @generated-from: packages/react/src/control-utils.ts
// @generated-content-sha256: sha256:694ab7ee0d85a775386b9cab82dfe466d3cbbcf1fb846fd0986d6c4b0d1df497
import type { ReactNode } from 'react';
/** The base class followed by the caller's `className`, leaving out whichever is empty. */
export declare function classNames(base: string, className?: string | undefined): string;
/** What names a control: a visible label, `aria-label`, or `aria-labelledby`. */
interface AccessibleNameParts {
    label?: ReactNode;
    ariaLabel?: string | undefined;
    ariaLabelledby?: string | undefined;
}
/** Throws unless the control has a visible label, an `aria-label`, or an `aria-labelledby`; an empty label does not count. */
export declare function accessibleName(props: AccessibleNameParts, componentName: string): void;
/**
 * Lays the caller's host attributes under the DOM props a React Aria component renders. React Aria's DOM filter keeps
 * ids, data-* attributes, its own handlers and a few named attributes, so a title, a tabIndex or most aria-* attributes
 * the component accepts in its types would never reach the element. Whatever React Aria renders still wins, with one
 * exception: the caller's tabIndex replaces React Aria's default one. autoFocus stays React Aria's, which focuses the
 * element itself. React Aria's behaviour props, which an internal caller such as TextEditor's bubble menu passes through
 * an untyped spread, are React Aria's to read and never reach the element.
 */
export declare function withHostAttributes<DomProps extends object>(caller: object, domProps: DomProps): DomProps;
export {};

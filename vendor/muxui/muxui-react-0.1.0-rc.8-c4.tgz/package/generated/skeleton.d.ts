// @generated-from: packages/react/src/supplemental/skeleton.ts
// @generated-content-sha256: sha256:6a21830883f033d05180209b79f518f1ce4f732c33cdc1aedbf2178567897246
import type { ForwardRefExoticComponent, HTMLAttributes, RefAttributes } from 'react';
/** The sizes of a Skeleton.Circle, the same as Avatar's. */
export type SkeletonCircleSize = 'sm' | 'md' | 'lg';
/**
 * The props Mux UI defines for Skeleton.Root, the group; the catalog's web.react API is derived from this type
 * (Decision 0031). The group is the one loading status; the shapes inside it are hidden from assistive technology.
 */
type SkeletonOwnProps = {
    /** The loading status assistive technology reads for the whole group, such as Loading comments. */
    label?: string;
};
/** The props Mux UI defines for Skeleton.Line; its API is the line entry in the catalog's partApis. */
type SkeletonLineOwnProps = {
    /** The line's length: a CSS length or percentage, or a number of pixels. */
    width?: string | number;
};
/** The props Mux UI defines for Skeleton.Circle; its API is the circle entry in the catalog's partApis. */
type SkeletonCircleOwnProps = {
    /** The circle's size, matching an Avatar of the same size. */
    size?: SkeletonCircleSize;
};
/** The props Mux UI defines for Skeleton.Block; its API is the block entry in the catalog's partApis. */
type SkeletonBlockOwnProps = {
    /** The block's width: a CSS length or percentage, or a number of pixels. */
    width?: string | number;
    /** The block's height: a CSS length, or a number of pixels. It takes the place of the aspect ratio. */
    height?: string | number;
    /** The block's width-to-height ratio, such as 16 / 9, used when no height is given. */
    aspectRatio?: string | number;
};
type ShapeProps<Own> = Own & Omit<HTMLAttributes<HTMLSpanElement>, keyof Own | 'children' | 'dangerouslySetInnerHTML'>;
export type SkeletonRootProps = SkeletonOwnProps & Omit<HTMLAttributes<HTMLDivElement>, keyof SkeletonOwnProps | 'role' | 'dangerouslySetInnerHTML'>;
export type SkeletonLineProps = ShapeProps<SkeletonLineOwnProps>;
export type SkeletonCircleProps = ShapeProps<SkeletonCircleOwnProps>;
export type SkeletonBlockProps = ShapeProps<SkeletonBlockOwnProps>;
/**
 * Placeholders that hold the place of content while it loads. Root is the group: one loading status for assistive
 * technology and one sweep over all its shapes. Line, Circle and Block are the shapes, hidden from assistive technology.
 */
export declare const Skeleton: {
    Root: ForwardRefExoticComponent<SkeletonRootProps & RefAttributes<HTMLDivElement>>;
    Line: ForwardRefExoticComponent<SkeletonLineProps & RefAttributes<HTMLSpanElement>>;
    Circle: ForwardRefExoticComponent<SkeletonCircleProps & RefAttributes<HTMLSpanElement>>;
    Block: ForwardRefExoticComponent<SkeletonBlockProps & RefAttributes<HTMLSpanElement>>;
};
export {};

// @generated-from: packages/react/src/combo-box.ts
// @generated-content-sha256: sha256:50eab382b9cf8d2f10f0db26ef710a80e8143abe25916477a93e7943f179f71e
import React from 'react';
import ChevronDownIcon from 'lucide-react/dist/esm/icons/chevron-down.mjs';
import { Label as AriaLabel, Text as AriaText, FieldError as AriaFieldError, ListBoxSection as AriaListBoxSection, Header as AriaHeader, ComboBoxStateContext as AriaComboBoxStateContext } from 'react-aria-components';
import { AriaComboBox, AriaListBox, AriaListBoxItem, AriaGroup, AriaInput } from './substrate.js';
import { normalizeChoiceControlSize } from './choice-context.mjs';
import { PopoverMotion } from './popover-motion.mjs';
import { IconButton } from './icon-button.js';
import { classNames, accessibleName } from './control-utils.js';
import { normalizeItems } from './collection-items.js';
// Normalizes the options of every section as one list, so their ids are unique across sections, then splits them back.
function normalizeSections(sections) {
    const flat = normalizeItems(sections.flatMap((section) => section.items));
    const ids = new Set(flat.map((item) => item.id));
    let start = 0;
    return sections.map((section) => {
        if (typeof section.id !== 'string' || section.id === '' || ids.has(section.id))
            throw new TypeError(`ComboBox section id must be a nonempty string unique among the sections and items: ${String(section.id)}`);
        ids.add(section.id);
        const items = flat.slice(start, (start += section.items.length));
        return { id: section.id, title: section.title, items };
    });
}
// A section is a named group: React Aria labels it by its header, filters its options, and hides it when none match.
// React Aria shows its own section nodes while the list shows every option and filtered copies of them while it
// filters, and React's development build throws when it compares the two as props of one mounted section. So the list
// mounts afresh when it changes between them. The tree React Aria builds its collection from has no combobox state,
// so its key never changes. A section with no options is left out, so no empty group is exposed.
function SectionedList({ sections, size }) {
    const state = React.useContext(AriaComboBoxStateContext);
    const first = state ? [...state.collection][0] : undefined;
    const filtered = first !== undefined && Object.prototype.hasOwnProperty.call(first, 'childNodes');
    return React.createElement(AriaListBox, { key: filtered ? 'filtered' : 'all', className: 'muxui-combo-box__list', ...{ 'data-muxui-size': size } }, sections.filter((section) => section.items.length > 0).map((section) => React.createElement(AriaListBoxSection, { key: section.id, id: section.id, className: 'muxui-combo-box__section' }, React.createElement(AriaHeader, { className: 'muxui-combo-box__header' }, section.title), section.items.map((item) => React.createElement(React.Fragment, { key: item.id }, renderOption(item))))));
}
function renderOption(item) {
    return React.createElement(AriaListBoxItem, { id: item.id, textValue: item.textValue, isDisabled: item.disabled, ...{ 'data-muxui-state-disabled': item.disabled || undefined, 'aria-disabled': item.disabled || undefined }, className: 'muxui-combo-box__option' }, item.label);
}
export const ComboBox = /*#__PURE__*/ (() => {
    const component = React.forwardRef(function ComboBox({ label, description, errorMessage, items, sections, value, defaultValue, selectedId, defaultSelectedId, onChange, onSelect, disabled = false, readOnly = false, required = false, invalid = false, placeholder, size = 'md', name, children: _children, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
        accessibleName({ label, ariaLabel, ariaLabelledby }, 'ComboBox');
        if (selectedId === '')
            throw new TypeError('ComboBox selectedId must be an item id, or null for no selection; an empty string is not an id');
        if (defaultSelectedId === '')
            throw new TypeError('ComboBox defaultSelectedId must be an item id; omit it for no selection');
        const resolvedSize = normalizeChoiceControlSize(size, 'ComboBox');
        if (items !== undefined && sections !== undefined)
            throw new TypeError('ComboBox takes items or sections, not both');
        // normalizeItems takes no items as an empty list, so an omitted list has no default here to state.
        const grouped = sections === undefined ? undefined : normalizeSections(sections);
        const normalized = grouped === undefined ? normalizeItems(items) : grouped.flatMap((section) => section.items);
        const disabledKeys = new Set(normalized.filter((item) => item.disabled).map((item) => item.id));
        // React Aria reports a cleared selection as a null key, except when both the text and
        // the selection are controlled: then the application owns both, so the clear is read from the emptied input.
        const bothControlled = value !== undefined && selectedId !== undefined;
        // Two checks, not ||: extraction reads a fallback on an owned prop as an executed default.
        const handleSelection = (key) => {
            if (disabled)
                return;
            if (readOnly)
                return;
            if (key == null) {
                if (!bothControlled)
                    onSelect?.(undefined);
                return;
            }
            const item = normalized.find((candidate) => candidate.id === String(key));
            if (item && !item.disabled)
                onSelect?.(item);
        };
        const handleInput = (next) => {
            if (disabled)
                return;
            if (readOnly)
                return;
            onChange?.(next);
            if (bothControlled && next === '' && selectedId !== null)
                onSelect?.(undefined);
        };
        // defaultItems lets React Aria filter options by the typed text; items would mean consumer-filtered.
        // The list is at least as wide as the field, so zero container padding keeps a full-width field's list aligned
        // at the viewport edge instead of pushed past it; the position hook still keeps the list on screen.
        return React.createElement(AriaComboBox, { ...props, ref, defaultItems: grouped === undefined ? normalized : grouped, disabledKeys, ...(value === undefined ? {} : { inputValue: value }), defaultInputValue: defaultValue, selectedKey: selectedId, defaultSelectedKey: defaultSelectedId, onInputChange: handleInput, onSelectionChange: handleSelection, isDisabled: disabled, isReadOnly: readOnly, isRequired: required, isInvalid: invalid ? invalid : undefined, name, className: classNames('muxui-combo-box', className), ...{ 'data-muxui-size': resolvedSize }, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby }, label !== undefined ? React.createElement(AriaLabel, { className: 'muxui-field-label' }, label) : null, React.createElement(AriaGroup, { className: 'muxui-combo-box__control' }, React.createElement(AriaInput, { className: 'muxui-field-input', placeholder }), React.createElement(IconButton, { className: 'muxui-combo-box__trigger', 'aria-label': 'Show options' }, React.createElement(ChevronDownIcon, { className: 'muxui-combo-box__arrow', 'aria-hidden': 'true', focusable: 'false', size: 16 }))), description !== undefined ? React.createElement(AriaText, { slot: 'description', className: 'muxui-field-description' }, description) : null, errorMessage !== undefined ? React.createElement(AriaFieldError, { className: 'muxui-field-error' }, errorMessage) : null, React.createElement(PopoverMotion, { containerPadding: 0, className: 'muxui-combo-box__popover', ...{ 'data-muxui-size': resolvedSize } }, grouped === undefined
            ? React.createElement(AriaListBox, { items: normalized, className: 'muxui-combo-box__list', ...{ 'data-muxui-size': resolvedSize }, children: renderOption })
            : React.createElement(SectionedList, { sections: grouped, size: resolvedSize })));
    });
    component.displayName = 'ComboBox';
    return component;
})();

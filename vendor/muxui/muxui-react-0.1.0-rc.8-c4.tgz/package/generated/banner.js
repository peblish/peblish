// @generated-from: packages/react/src/supplemental/banner.ts
// @generated-content-sha256: sha256:a89638faa535d9bdd281906270d7398eceb73eb2140c6b06e82094c58ba3bf57
import React from 'react';
import XIcon from 'lucide-react/dist/esm/icons/x.mjs';
import { Button } from './button.js';
import { Link } from './components.js';
import { IconButton } from './icon-button.js';
import { cx, h } from './part-utils.js';
// Keyed by the types, so a value added to one must be added here too.
const TONES = { neutral: true, brand: true, success: true, warning: true, danger: true };
const EMPHASES = { subtle: true, solid: true };
const ALIGNS = { start: true, center: true };
function oneOf(name, value, values) {
    if (typeof value !== 'string' || !Object.hasOwn(values, value))
        throw new TypeError(`Banner ${name} must be one of: ${Object.keys(values).join(', ')}.`);
    return value;
}
/** An opaque #rgb, #rrggbb, rgb() or rgba() colour as 0 to 255 channels; anything else, or any transparency, is null. */
function parseBannerColor(value) {
    const text = value.trim().toLowerCase();
    const hex = /^#([0-9a-f]{3}|[0-9a-f]{6})$/u.exec(text)?.[1];
    if (hex) {
        const full = hex.length === 3 ? [...hex].map((digit) => digit + digit).join('') : hex;
        return [0, 2, 4].map((at) => Number.parseInt(full.slice(at, at + 2), 16));
    }
    const rgb = /^rgba?\(\s*(\d{1,3})\s*[,\s]\s*(\d{1,3})\s*[,\s]\s*(\d{1,3})\s*(?:[,/]\s*([\d.]+%?)\s*)?\)$/u.exec(text);
    if (!rgb)
        return null;
    const channels = rgb.slice(1, 4).map(Number);
    const alpha = rgb[4] === undefined ? 1 : rgb[4].endsWith('%') ? Number.parseFloat(rgb[4]) / 100 : Number(rgb[4]);
    return channels.every((channel) => channel <= 255) && alpha === 1 ? channels : null;
}
/** WCAG 2 relative luminance. */
function luminance(rgb) {
    const [r, g, b] = rgb.map((channel) => {
        const value = channel / 255;
        return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
    });
    return 0.2126 * r + 0.7152 * g + 0.0722 * b;
}
/**
 * The text colour on a custom fill: white or black, whichever has the higher WCAG 2 contrast ratio. One of them always
 * reaches at least 4.58:1 on an opaque fill, so a custom colour never needs a third colour.
 */
function bannerForeground(rgb) {
    const fill = luminance(rgb);
    return 1.05 / (fill + 0.05) >= (fill + 0.05) / 0.05 ? '#ffffff' : '#000000';
}
/**
 * A page-level notice: a message with an optional title and icon, up to two actions, a link and a dismiss button. It is a
 * named region, or an alert when asked. Its controls draw only the Banner's own two colours, so they keep the message's
 * contrast at rest, hover and press.
 */
export const Banner = /*#__PURE__*/ React.forwardRef(function Banner({ title, icon, tone = 'neutral', emphasis = 'subtle', customColor, align = 'start', actions = [], link, dismissible = false, dismissed, defaultDismissed = false, onDismiss, dismissLabel = 'Dismiss notice', label, alert = false, 
// Untyped callers' HTML and role never reach the section.
className, style, children, dangerouslySetInnerHTML: _html, role: _role, ...props }, ref) {
    const named = oneOf('tone', tone, TONES);
    const shown = oneOf('emphasis', emphasis, EMPHASES);
    const placed = oneOf('align', align, ALIGNS);
    if (actions.length > 2)
        throw new TypeError('Banner takes at most two actions.');
    const [localDismissed, setLocalDismissed] = React.useState(defaultDismissed);
    const titleId = `${React.useId()}-title`;
    // Controlled while dismissed is set. A conditional, not ??: extraction reads a fallback on an owned prop as an executed default.
    const isDismissed = dismissed == null ? localDismissed : dismissed;
    if (isDismissed)
        return null;
    const custom = customColor === undefined ? null : parseBannerColor(customColor);
    const colors = custom ? {
        '--muxui-banner-custom': `rgb(${custom.join(' ')})`,
        '--muxui-banner-custom-foreground': bannerForeground(custom),
    } : undefined;
    const dismiss = () => {
        if (dismissed === undefined)
            setLocalDismissed(true);
        onDismiss?.();
    };
    const name = label ? { 'aria-label': label } : title ? { 'aria-labelledby': titleId } : { 'aria-label': 'Notice' };
    return h('section', {
        ...props,
        ...name,
        ref,
        role: alert ? 'alert' : 'region',
        className: cx('muxui-banner', className),
        style: colors ? { ...style, ...colors } : style,
        'data-muxui-tone': custom ? 'custom' : named,
        'data-muxui-emphasis': shown,
        'data-muxui-align': placed,
    }, h('div', { className: 'muxui-banner__body' }, icon ? h('span', { className: 'muxui-banner__icon', 'aria-hidden': true }, icon) : null, h('div', { className: 'muxui-banner__text' }, title ? h('span', { id: titleId, className: 'muxui-banner__title' }, title) : null, title && children != null ? ' ' : null, children != null ? h('span', { className: 'muxui-banner__message' }, children) : null), actions.length > 0 || link ? h('div', { className: 'muxui-banner__actions' }, 
    // The first action is filled and the second outlined; the stylesheet tells them apart by order.
    actions.map((action) => h(Button, { key: action.id, size: 'sm', variant: 'neutral', className: 'muxui-banner__action', onActivate: () => action.onAction() }, action.label)), link ? h(Link, { className: 'muxui-banner__link', href: link.href }, link.label) : null) : null), dismissible ? h(IconButton, { className: 'muxui-banner__dismiss', size: 'sm', variant: 'ghost', 'aria-label': dismissLabel, onActivate: dismiss }, h(XIcon, { className: 'muxui-banner__dismiss-icon', 'aria-hidden': 'true', focusable: 'false', size: 16 })) : null);
});
Banner.displayName = 'Banner';

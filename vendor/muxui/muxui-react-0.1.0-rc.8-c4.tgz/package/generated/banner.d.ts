// @generated-from: packages/react/src/supplemental/banner.ts
// @generated-content-sha256: sha256:25b8cb7e8521791ea1460fb6d40db25dcec508bac6362f98bd60dc0a2ab8e96b
import type { ForwardRefExoticComponent, HTMLAttributes, ReactNode, RefAttributes } from 'react';
/** The named colours of a Banner. */
export type BannerTone = 'neutral' | 'brand' | 'success' | 'warning' | 'danger';
/** How strongly a Banner is coloured: a tint of its tone over the surface, or the tone's solid fill. */
export type BannerEmphasis = 'subtle' | 'solid';
/** Where a Banner's icon, text and actions sit. */
export type BannerAlign = 'start' | 'center';
/** One action Button on a Banner. The first is filled, the second outlined. */
export type BannerAction = {
    id: string;
    label: string;
    onAction: () => void;
};
/** The Link on a Banner, after its actions. */
export type BannerLink = {
    label: string;
    href: string;
};
/**
 * The props Mux UI defines for Banner; the catalog's web.react API is derived from this type (Decision 0031). The message
 * is the children. It is a type literal, not an interface, so the public props type stays assignable to Record<string, unknown>.
 */
type BannerOwnProps = {
    /** A short lead-in shown before the message in the label weight. It names the region when no label is given. */
    title?: ReactNode;
    /** A decorative icon before the text, hidden from assistive technology. */
    icon?: ReactNode;
    /** The named colour. A valid customColor takes its place. */
    tone?: BannerTone;
    /** A tint of the colour over the surface, or the colour as a solid fill. */
    emphasis?: BannerEmphasis;
    /**
     * An opaque colour, as #rgb, #rrggbb or rgb(), in place of the tone. Text and controls on it are white or black, whichever
     * contrasts more. A colour that cannot be read or is not opaque falls back to the tone.
     */
    customColor?: string;
    /** Where the icon, text and actions sit: at the start, or centred as a group. */
    align?: BannerAlign;
    /** Up to two action Buttons. */
    actions?: readonly BannerAction[];
    /** A Link after the actions. */
    link?: BannerLink;
    /** Shows the dismiss button. */
    dismissible?: boolean;
    /** Whether the Banner is dismissed, when the caller controls it. A dismissed Banner renders nothing. */
    dismissed?: boolean;
    /** Whether the Banner starts dismissed, when Banner controls it. */
    defaultDismissed?: boolean;
    /** Reports the dismiss button being pressed. Banner stores nothing. */
    onDismiss?: () => void;
    /** The dismiss button's accessible name. */
    dismissLabel?: string;
    /** The region's accessible name. Without it the title names the region, and without a title it is Notice. */
    label?: string;
    /** Announces the Banner as an alert instead of a named region, for a notice that needs attention at once. */
    alert?: boolean;
};
export type BannerProps = BannerOwnProps & Omit<HTMLAttributes<HTMLElement>, keyof BannerOwnProps | 'role' | 'dangerouslySetInnerHTML'>;
/**
 * A page-level notice: a message with an optional title and icon, up to two actions, a link and a dismiss button. It is a
 * named region, or an alert when asked. Its controls draw only the Banner's own two colours, so they keep the message's
 * contrast at rest, hover and press.
 */
export declare const Banner: ForwardRefExoticComponent<BannerProps & RefAttributes<HTMLElement>>;
export {};

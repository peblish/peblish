// @generated-from: packages/react/src/list-box.ts
// @generated-content-sha256: sha256:b94fd76513da81ef7e936c67dd36720f3d7bed2828624f1770b87190d4d4c93a
import React from 'react';
import { ListBoxMotion } from './listbox-motion.mjs';
import { ListBoxSection as AriaListBoxSection, Header as AriaHeader } from 'react-aria-components';
import { AriaListBox, AriaListBoxItem } from './substrate.js';
import { classNames, accessibleName } from './control-utils.js';
import { textContent, normalizeItems, keySet, keyList, collectionItem } from './collection-items.js';
const ListBoxContext = React.createContext({ disabled: false });
// Keep component creation and metadata local so unused motion can be removed.
export const ListBox = /*#__PURE__*/ (() => {
    const ListBox = React.forwardRef(function ListBoxRoot({ items, selectedIds, defaultSelectedIds, onSelectionChange, onAction, selectionMode = 'single', disabled = false, children, className, style, layout = 'stack', orientation = 'vertical', ...props }, ref) {
        accessibleName({ ariaLabel: props['aria-label'], ariaLabelledby: props['aria-labelledby'] }, 'ListBox');
        if (layout !== 'stack' && layout !== 'grid')
            throw new TypeError('ListBox layout must be stack or grid');
        if (orientation !== 'vertical' && orientation !== 'horizontal')
            throw new TypeError('ListBox orientation must be vertical or horizontal');
        // normalizeItems takes no items as an empty list, so an omitted list has no default here to state.
        const normalized = normalizeItems(items);
        const hasChildren = children !== undefined && children !== null;
        // Conditionals, not || on the owned disabled: extraction reads a fallback on an owned prop as an executed default.
        const disabledKeys = new Set(normalized.filter((item) => (disabled ? disabled : item.disabled)).map((item) => item.id));
        const actionProps = onAction ? {
            onAction: (key) => {
                const item = normalized.find((candidate) => candidate.id === String(key));
                if (!disabled && !item?.disabled)
                    onAction(item ?? collectionItem(key));
            },
        } : {};
        const listBox = React.createElement(AriaListBox, {
            ...props, items: hasChildren ? undefined : normalized, selectionMode,
            selectedKeys: keySet(selectedIds), defaultSelectedKeys: keySet(defaultSelectedIds), disabledKeys,
            onSelectionChange: (keys) => { if (!disabled)
                onSelectionChange?.(keyList(keys)); },
            ...actionProps,
            // React Aria's props do not name aria-disabled or the data-* hooks the styles read, and TypeScript accepts such a key in a call only from a spread.
            ...{ 'data-muxui-state-disabled': disabled ? disabled : undefined, 'aria-disabled': disabled ? disabled : undefined },
            layout, orientation, style, className: classNames('muxui-list-box', className),
            children: hasChildren ? children : (item) => React.createElement(ListBox.Item, { id: item.id, textValue: item.textValue, disabled: item.disabled }, item.label),
        });
        return React.createElement(ListBoxContext.Provider, { value: { disabled } }, React.createElement(ListBoxMotion, { selectionMode, rootRef: ref, children: listBox }));
    });
    ListBox.displayName = 'ListBox';
    ListBox.Root = ListBox;
    ListBox.Section = React.forwardRef(function ListBoxSection({ children, className, title, ...props }, ref) {
        return React.createElement(AriaListBoxSection, { ...props, ref, className: classNames('muxui-list-box__section', className) }, title !== undefined ? React.createElement(ListBox.Header, null, title) : null, children);
    });
    ListBox.Header = React.forwardRef(function ListBoxHeader({ children, className, ...props }, ref) {
        return React.createElement(AriaHeader, { ...props, ref, className: classNames('muxui-list-box__header', className) }, children);
    });
    ListBox.Item = React.forwardRef(function ListBoxItem({ children, id, textValue, disabled = false, className, ...props }, ref) {
        const context = React.useContext(ListBoxContext);
        const effectiveDisabled = disabled ? disabled : context.disabled;
        return React.createElement(AriaListBoxItem, {
            ...props, ref, id,
            // A conditional, not ??: extraction reads a fallback on an owned prop as an executed default, and the item's own text is none.
            textValue: textValue == null ? (textContent(children) || undefined) : textValue,
            isDisabled: effectiveDisabled,
            ...{ 'data-muxui-state-disabled': effectiveDisabled || undefined, 'aria-disabled': effectiveDisabled || undefined },
            className: classNames('muxui-list-box__item', className),
        }, children);
    });
    return ListBox;
})();

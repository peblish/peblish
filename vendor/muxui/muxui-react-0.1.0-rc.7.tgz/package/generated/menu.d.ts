// @generated-from: packages/react/src/menu.ts
// @generated-content-sha256: sha256:59f13d916111923e198a229b2d877fa36eef1fc1795a6c5f1c3bd7bce2c3f524
import type { ButtonHTMLAttributes, ForwardRefExoticComponent, HTMLAttributes, ReactElement, ReactNode, RefAttributes, RefObject } from 'react';
import type { ButtonActivationEvent } from './button.js';
import type { MuxUICollectionItem, MuxUIItems } from './collection-items.js';
import type { MuxUIAriaAccessibleName } from './fields.js';
import type { MuxUIPlacement } from './overlays.js';
/** The props Mux UI defines for Menu.Root. Every other attribute of a div passes through to the root. */
export type MenuOwnProps = {
    /** Whether the menu is open, when the caller controls it. A disabled menu is closed whatever this says. */
    open?: boolean;
    /** Whether the menu starts open, when it controls itself. */
    defaultOpen?: boolean;
    /** Called with the next open state when the menu opens or closes. It is not called for a request to open a disabled menu. */
    onOpenChange?: (open: boolean) => void;
    /** Disables the trigger and every item. A child's own `disabled={false}` cannot re-enable them under a disabled root. */
    disabled?: boolean;
    /** Whether choosing an item closes the menu. A Menu.List or Menu.Item can set its own, which wins over this. */
    shouldCloseOnSelect?: boolean;
    /** Called when the user activates an item in any list of the menu, after the item's own `onAction` and the list's callbacks. A list built from `items` passes the item record; one built from children passes the identity fields `id`, `key`, and `value`. It is not called for a disabled item or while the menu is disabled. */
    onAction?: (item?: MuxUICollectionItem) => void;
    /** Called with the same item as `onAction`, right after it. */
    onSelect?: (item?: MuxUICollectionItem) => void;
};
export type MenuRootProps = Omit<HTMLAttributes<HTMLDivElement>, 'onSelect'> & MenuOwnProps;
/** The props Mux UI defines for Menu.Trigger. Every other attribute of a button passes through to it. */
export type MenuTriggerOwnProps = {
    /** Disables the trigger: it can be neither focused nor activated. A disabled menu disables it whatever this says. */
    disabled?: boolean | undefined;
    /** Called when the user activates the trigger, before the menu opens or closes. It is not called while the trigger is disabled. */
    onActivate?: (event: ButtonActivationEvent) => void;
};
export type MenuTriggerProps = ButtonHTMLAttributes<HTMLButtonElement> & MenuTriggerOwnProps;
/** The props Mux UI defines for Menu.Popup. Every other attribute of a div passes through to the popup. */
export type MenuPopupOwnProps = {
    /** Where the popup opens against its trigger or anchorRef. start and end follow the locale direction. Without one, a top-level popup opens at `bottom-start`, and a popup inside a Menu.Submenu opens beside its item at `end-top`. */
    placement?: MuxUIPlacement;
    /** The distance in pixels between the popup and its trigger, along the placement's side. Must be finite. */
    offset?: number;
    /** The shift in pixels along the side the popup is placed against. Must be finite. */
    crossOffset?: number;
    /** Whether the popup moves to the opposite side when the placed side has no room. */
    shouldFlip?: boolean;
    /** The least distance in pixels between the popup and the edge of the viewport. Must be finite and not negative. */
    containerPadding?: number;
    /** Whether the rest of the page is made inaccessible while the popup is open. When false, outside content stays accessible. */
    modal?: boolean;
};
export type MenuPopupProps = HTMLAttributes<HTMLDivElement> & MenuPopupOwnProps & {
    anchorRef?: RefObject<Element | null>;
};
/** The props Mux UI defines for Menu.List, and for the standalone Menu, which is the same list. */
export type MenuListOwnProps = {
    /** The options as data: strings, or items with an `id`, a `label`, a `textValue`, and `disabled`. Children take precedence: when both are supplied, the items are not rendered. */
    items?: MuxUIItems;
    /** Disables every item and stops the action callbacks. An item's own `disabled={false}` cannot re-enable it under a disabled list. */
    disabled?: boolean;
    /** Whether choosing an item closes the menu, in place of the root's setting. A Menu.Item can still set its own. */
    shouldCloseOnSelect?: boolean;
    /** Called when the user activates an item. A list built from `items` passes the item record; one built from children passes the identity fields `id`, `key`, and `value`. It is not called for a disabled item or while the list is disabled. */
    onAction?: (item?: MuxUICollectionItem) => void;
    /** Called with the same item as `onAction`, right after it. */
    onSelect?: (item?: MuxUICollectionItem) => void;
};
export type MenuProps = MenuListOwnProps & {
    children?: ReactNode;
    className?: string;
} & MuxUIAriaAccessibleName;
export type MenuListProps = MenuListOwnProps & {
    children?: ReactNode;
    className?: string;
} & {
    'aria-label'?: string;
    'aria-labelledby'?: string;
};
/** The props Mux UI defines for Menu.Item. Every other attribute of a div passes through to the item. */
export type MenuItemOwnProps = {
    /** The stable string id the action callbacks report. */
    id: string;
    /** The text typeahead matches. Without one it is the text of the item's children, which is unambiguous only for plain text, so give rich children a `textValue`. */
    textValue?: string;
    /** Disables the item. A disabled list or menu disables every item whatever this says. */
    disabled?: boolean;
    /** Called when the user activates the item, before the list's and the root's callbacks. It is not called while the item is disabled. */
    onAction?: () => void;
    /** Whether choosing this item closes the menu, in place of the list's and the root's setting. Left unset, the item follows them. */
    shouldCloseOnSelect?: boolean;
};
export type MenuItemProps = Omit<HTMLAttributes<HTMLDivElement>, 'id'> & MenuItemOwnProps;
/** The props Mux UI defines for Menu.Section. Every other attribute of a section passes through to it. */
export type MenuSectionOwnProps = {
    /** The visible heading of the section, rendered in a Menu.Header. Without one, name the section with `aria-label`. */
    title?: ReactNode;
};
export type MenuSectionProps = Omit<HTMLAttributes<HTMLElement>, 'title'> & MenuSectionOwnProps;
/** The props Mux UI defines for Menu.Submenu, which renders no element of its own. */
export type MenuSubmenuOwnProps = {
    /** How long in milliseconds the pointer rests on the submenu's item before the submenu opens. Must be finite and not negative. */
    delay?: number;
};
export type MenuSubmenuProps = MenuSubmenuOwnProps & {
    children: ReactNode;
};
type MenuComponent = ForwardRefExoticComponent<MenuProps & RefAttributes<HTMLDivElement>> & {
    Root: ForwardRefExoticComponent<MenuRootProps & RefAttributes<HTMLDivElement>>;
    Trigger: ForwardRefExoticComponent<MenuTriggerProps & RefAttributes<HTMLButtonElement>>;
    Popup: ForwardRefExoticComponent<MenuPopupProps & RefAttributes<HTMLDivElement>>;
    List: ForwardRefExoticComponent<MenuListProps & RefAttributes<HTMLDivElement>>;
    Item: ForwardRefExoticComponent<MenuItemProps & RefAttributes<HTMLDivElement>>;
    Submenu: (props: MenuSubmenuProps) => ReactElement;
    Section: ForwardRefExoticComponent<MenuSectionProps & RefAttributes<HTMLElement>>;
    Header: ForwardRefExoticComponent<HTMLAttributes<HTMLElement> & RefAttributes<HTMLElement>>;
    Separator: ForwardRefExoticComponent<HTMLAttributes<HTMLHRElement> & RefAttributes<HTMLHRElement>>;
};
export declare const Menu: MenuComponent;
export {};

// @generated-from: packages/react/src/supplemental/text-area.ts
// @generated-content-sha256: sha256:dd5d17920dde687cf137505b51843b9bdba2267efff87cee1b59089aa4ef8eb9
import type { ForwardRefExoticComponent, HTMLAttributes, RefAttributes, TextareaHTMLAttributes } from 'react';
import type { PartProps } from './part-utils.js';
/**
 * The props Mux UI defines for TextArea.Root, the compound's root; the catalog's web.react API is
 * derived from this type (Decision 0031). The members every field shares are written out, because
 * the catalog's grammar reads only the members a type lists itself. The textarea's native attributes,
 * such as rows, maxLength and placeholder, belong to TextArea.TextArea.
 */
type TextAreaOwnProps = {
    /** The text, when the caller controls it. */
    value?: string;
    /** The starting text, when the field controls itself. */
    defaultValue?: string;
    /** Called with the new text each time it changes. */
    onChange?: (value: string) => void;
    /** Marks the field disabled. */
    disabled?: boolean;
    /** Marks the field invalid. */
    invalid?: boolean;
    /** Marks the field required. */
    required?: boolean;
    /** Marks the field read-only. */
    readOnly?: boolean;
    /** The field's size. */
    size?: 'sm' | 'md' | 'lg';
};
export type TextAreaRootProps = Omit<HTMLAttributes<HTMLDivElement>, 'onChange' | 'defaultValue'> & TextAreaOwnProps;
export type TextAreaProps = TextareaHTMLAttributes<HTMLTextAreaElement>;
export type TextAreaLabelProps = PartProps<HTMLLabelElement>;
export type TextAreaDescriptionProps = PartProps<HTMLElement>;
export type TextAreaErrorProps = PartProps<HTMLElement>;
export declare const TextArea: {
    Root: ForwardRefExoticComponent<TextAreaRootProps & RefAttributes<HTMLDivElement>>;
    TextArea: ForwardRefExoticComponent<TextAreaProps & RefAttributes<HTMLTextAreaElement>>;
    Label: ForwardRefExoticComponent<TextAreaLabelProps & RefAttributes<HTMLLabelElement>>;
    Description: ForwardRefExoticComponent<TextAreaDescriptionProps & RefAttributes<HTMLElement>>;
    Error: ForwardRefExoticComponent<TextAreaErrorProps & RefAttributes<HTMLElement>>;
};
export {};

// @generated-from: packages/react/src/supplemental/card.ts
// @generated-content-sha256: sha256:774bd15088511e0c2e1740680c53a184367a4090afc06793157fa1ca97cf0f37
import React from 'react';
import { AriaButton } from './substrate.js';
import { usePendingSubmitProps } from './button.js';
import { h, cx, dataState, nativePart, pressHandler } from './part-utils.js';
/* Card */
// A value outside the sets falls back to the default look, whatever the types say.
function cardProps({ variant, padding, className, ...props }) {
    const safeVariant = ['elevated', 'outlined', 'filled'].includes(variant) ? variant : 'outlined';
    const safePadding = ['sm', 'md', 'lg'].includes(padding) ? padding : 'md';
    return { ...props, className: cx('muxui-card', `muxui-card--${safeVariant}`, `muxui-card--${safePadding}`, className) };
}
const CardRoot = /*#__PURE__*/ React.forwardRef(function CardRoot({ variant = 'outlined', padding = 'md', ...props }, ref) {
    return h('div', { ...cardProps({ ...props, variant, padding }), ref });
});
const CardButton = /*#__PURE__*/ React.forwardRef(function CardButton({ variant = 'outlined', padding = 'md', selected, disabled = false, pending = false, onActivate, ...props }, ref) {
    const pendingSubmitProps = usePendingSubmitProps(pending, props.type);
    // The native button attributes reach React Aria's Button, whose props type names only its own.
    return h(AriaButton, {
        ...cardProps({ ...props, variant, padding, className: cx('muxui-card--button', props.className) }),
        ref,
        isDisabled: disabled,
        isPending: pending,
        'aria-pressed': selected,
        ...{ 'data-muxui-state-selected': dataState(selected), 'data-muxui-state-pending': dataState(pending) },
        onPress: pressHandler(onActivate),
        render: (domProps) => h('button', { ...domProps, ...pendingSubmitProps }),
    });
});
const CardHeader = /*#__PURE__*/ React.forwardRef(function CardHeader(props, ref) { return nativePart('div', 'muxui-card__header', props, ref); });
const CardBody = /*#__PURE__*/ React.forwardRef(function CardBody(props, ref) { return nativePart('div', 'muxui-card__body', props, ref); });
const CardFooter = /*#__PURE__*/ React.forwardRef(function CardFooter(props, ref) { return nativePart('div', 'muxui-card__footer', props, ref); });
export const Card = /*#__PURE__*/ Object.freeze({
    Root: CardRoot,
    Button: CardButton,
    Header: CardHeader,
    Body: CardBody,
    Footer: CardFooter,
});

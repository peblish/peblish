// @generated-from: packages/react/src/radio-group.ts
// @generated-content-sha256: sha256:4b050acad1ac68aafd9ab683cc24e11eae9cc55b4637efcdd771d9f5d4226d2b
import React from 'react';
import { FieldError as AriaFieldError } from 'react-aria-components';
import { AriaRadio, AriaRadioGroup } from './substrate.js';
import { normalizeChoiceControlSize, ChoiceControlSizeContext } from './choice-context.mjs';
import { RadioGroupMotion, RadioMotionIndicator } from './radio-motion.mjs';
import { classNames, accessibleName } from './control-utils.js';
export const RadioGroup = /*#__PURE__*/ (() => {
    const component = React.forwardRef(function RadioGroup({ label, errorMessage, options: suppliedOptions, children, value, defaultValue, onChange, disabled = false, readOnly = false, required = false, invalid = false, orientation = 'vertical', size = 'md', name, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby }, ref) {
        accessibleName({ label, ariaLabel, ariaLabelledby }, 'RadioGroup');
        // An omitted options is an empty list. The local keeps the name `options`, so a value that is not an array
        // fails with the message `options.map is not a function`, as it did when the empty list was a parameter default.
        const options = suppliedOptions === undefined ? [] : suppliedOptions;
        const labelId = React.useId();
        // The visible label text labels the group, so the two cannot drift apart.
        const generatedLabelledby = ariaLabel === undefined && ariaLabelledby === undefined && label !== undefined && label !== null
            ? labelId
            : undefined;
        if (orientation !== 'horizontal' && orientation !== 'vertical') {
            throw new TypeError('RadioGroup orientation must be horizontal or vertical');
        }
        if (options.length > 0 && children !== undefined && children !== null) {
            throw new TypeError('RadioGroup options and children are mutually exclusive');
        }
        const resolvedSize = normalizeChoiceControlSize(size, 'RadioGroup');
        const radioContent = options.length > 0
            ? options.map((option) => React.createElement(AriaRadio, {
                key: String(option.id ?? option.value),
                value: String(option.value ?? option.id),
                isDisabled: disabled ? disabled : option.disabled,
                className: classNames('muxui-radio-group__radio', resolvedSize === undefined || resolvedSize === 'md' ? undefined : `muxui-radio-group__radio--${resolvedSize}`),
                // React Aria's overloads take a render function as the children prop, not as a third argument.
                children: (renderProps) => React.createElement(React.Fragment, null, React.createElement(RadioMotionIndicator, { renderProps }), option.label ?? option.value),
            }))
            : children;
        const group = React.createElement(AriaRadioGroup, {
            ref,
            name,
            value,
            defaultValue,
            onChange: (next) => { if (!disabled && !readOnly)
                onChange?.(next); },
            isDisabled: disabled,
            isReadOnly: readOnly,
            isRequired: required,
            isInvalid: invalid ? invalid : undefined,
            orientation,
            'aria-label': ariaLabel,
            'aria-labelledby': ariaLabelledby ?? generatedLabelledby,
            // The data-* hooks the styles read are not props React Aria types, and TypeScript accepts such a key in a call only from a spread.
            ...{ 'data-muxui-state-orientation': orientation, 'data-muxui-size': resolvedSize },
            className: classNames('muxui-radio-group', className),
        }, radioContent, 
        // Inside the group, so RAC wires it into the group's aria-describedby and shows it only while the group is invalid.
        // It is always mounted: without errorMessage it shows the server or browser validation message, as CheckboxGroup does.
        React.createElement(AriaFieldError, { className: 'muxui-field-error muxui-radio-group__error' }, errorMessage));
        const motionGroup = React.createElement(RadioGroupMotion, { rootRef: ref, children: group });
        const content = label === undefined
            ? motionGroup
            : React.createElement('div', { className: 'muxui-radio-group__field', ...{ 'data-muxui-state-disabled': disabled ? disabled : undefined, 'data-muxui-state-invalid': invalid ? invalid : undefined } }, React.createElement('span', { id: generatedLabelledby, className: 'muxui-field-label' }, label), motionGroup);
        return React.createElement(ChoiceControlSizeContext.Provider, { value: resolvedSize }, content);
    });
    component.displayName = 'RadioGroup';
    return component;
})();

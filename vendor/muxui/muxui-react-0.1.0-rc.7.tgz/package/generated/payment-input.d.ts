// @generated-from: packages/react/src/supplemental/payment-input.ts
// @generated-content-sha256: sha256:530dd4f4410de435901f82d446ab1d0b8447d16f523a6d95d080d98e1aa2cbe9
import type { ForwardRefExoticComponent, HTMLAttributes, InputHTMLAttributes, RefAttributes } from 'react';
import type { PartProps } from './part-utils.js';
/**
 * The props Mux UI defines for PaymentInput.Root, the compound's root; the catalog's web.react
 * API is derived from this type (Decision 0031). The members every field shares are written out,
 * because the catalog's grammar reads only the members a type lists itself.
 */
type PaymentInputOwnProps = {
    /** The card number, when the caller controls it. */
    value?: string;
    /** The starting card number, when the field controls itself. */
    defaultValue?: string;
    /** Called with the formatted card number each time it changes. */
    onChange?: (value: string) => void;
    /** Marks the field disabled. */
    disabled?: boolean;
    /** Marks the field invalid. */
    invalid?: boolean;
    /** Marks the field required. */
    required?: boolean;
    /** Marks the field read-only. */
    readOnly?: boolean;
    /** The field's size. */
    size?: 'sm' | 'md' | 'lg';
};
/** The props Mux UI defines for PaymentInput.CardIcon; its API is the card-icon entry in the catalog's partApis. */
type PaymentInputCardIconOwnProps = {
    /** The card type the icon records as its `data-muxui-card-type`, in place of the one detected from the leading digits of the number typed into the field. The glyph is the same for every type. */
    cardType?: 'visa' | 'mastercard' | 'amex' | 'discover' | 'unknown';
};
export type PaymentInputProps = Omit<HTMLAttributes<HTMLDivElement>, 'onChange' | 'defaultValue'> & PaymentInputOwnProps;
export type PaymentInputRootProps = PaymentInputProps;
export type PaymentInputGroupProps = PartProps<HTMLDivElement>;
export type PaymentInputInputProps = InputHTMLAttributes<HTMLInputElement>;
export type PaymentInputLabelProps = PartProps<HTMLLabelElement>;
export type PaymentInputDescriptionProps = PartProps<HTMLElement>;
export type PaymentInputErrorProps = PartProps<HTMLElement>;
export type PaymentInputCardIconProps = Omit<PartProps<HTMLSpanElement>, 'aria-label' | 'children'> & PaymentInputCardIconOwnProps;
export declare const PaymentInput: {
    Root: ForwardRefExoticComponent<PaymentInputProps & RefAttributes<HTMLDivElement>>;
    Group: ForwardRefExoticComponent<PaymentInputGroupProps & RefAttributes<HTMLDivElement>>;
    Input: ForwardRefExoticComponent<PaymentInputInputProps & RefAttributes<HTMLInputElement>>;
    Label: ForwardRefExoticComponent<PaymentInputLabelProps & RefAttributes<HTMLLabelElement>>;
    Description: ForwardRefExoticComponent<PaymentInputDescriptionProps & RefAttributes<HTMLElement>>;
    Error: ForwardRefExoticComponent<PaymentInputErrorProps & RefAttributes<HTMLElement>>;
    CardIcon: ForwardRefExoticComponent<PaymentInputCardIconProps & RefAttributes<HTMLSpanElement>>;
};
export {};

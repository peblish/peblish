// @generated-from: packages/react/src/fields.ts
// @generated-content-sha256: sha256:b4ad30724d17bcf7b5410725e4c2f62325a21fcf4e00c6fc4e7a61824e196f31
import React from 'react';
import { CalendarHeightMotion } from './calendar-height-motion.mjs';
import { Autocomplete as AriaAutocomplete, CalendarGrid as AriaCalendarGrid, CalendarGridBody as AriaCalendarGridBody, CalendarGridHeader as AriaCalendarGridHeader, CalendarHeaderCell as AriaCalendarHeaderCell, CalendarHeading as AriaCalendarHeading, Dialog as AriaDialog, Form as AriaForm, InputContext as AriaInputContext, Label as AriaLabel, Text as AriaText } from 'react-aria-components';
import { AriaCalendar, AriaCalendarCell, AriaCheckboxGroup, AriaDateField, AriaDateInput, AriaDatePicker, AriaDateRangePicker, AriaDateSegment, AriaGroup, AriaInput, AriaListBox, AriaListBoxItem, AriaNumberField, AriaRangeCalendar, AriaSearchField, AriaSwitchButton, AriaSwitchField, AriaTextField, AriaTimeField } from './substrate.js';
import { parseDate, parseTime } from '@internationalized/date';
import ChevronLeftIcon from 'lucide-react/dist/esm/icons/chevron-left.mjs';
import ChevronRightIcon from 'lucide-react/dist/esm/icons/chevron-right.mjs';
import MinusIcon from 'lucide-react/dist/esm/icons/minus.mjs';
import PlusIcon from 'lucide-react/dist/esm/icons/plus.mjs';
import XIcon from 'lucide-react/dist/esm/icons/x.mjs';
import { normalizeChoiceControlSize, ChoiceControlSizeContext } from './choice-context.mjs';
import { DatePopoverMotion } from './date-popover-motion.mjs';
import { PopoverMotion } from './popover-motion.mjs';
import { RangeSelectionMotion } from './range-selection-motion.mjs';
import { SwitchMotionIndicator } from './switch-motion.js';
import { IconButton } from './icon-button.js';
import { FieldErrorText, lateErrorScope } from './field-error.js';
const ISO_DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/u;
const ISO_TIME_PATTERN = /^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d(?:\.\d+)?)?$/u;
const TIME_PLACEHOLDER = /*#__PURE__*/ parseTime('00:00');
const MUX_RUNTIME_SCOPE_SELECTOR = /*#__PURE__*/ [
    '[data-muxui-color-scheme]',
    '[data-muxui-contrast]',
    '[data-muxui-motion]',
    '[data-muxui-density]',
    '[data-muxui-direction]',
].join(', ');
function autocompletePortalContainer(input) {
    if (typeof document === 'undefined' || !input)
        return undefined;
    const scope = input.closest(MUX_RUNTIME_SCOPE_SELECTOR);
    if (!scope || scope === document.documentElement || scope === document.body)
        return undefined;
    return scope;
}
function classNames(base, className) {
    return [base, className].filter(Boolean).join(' ');
}
// TextField and SearchField own the field semantics and their serialized value.
// Keep those props on the RAC field context while allowing native behavior on
// the inner input through the bounded inputProps escape hatch.
// FieldInputProps omits these, less ref: the grammar cannot read its Omit's keys, so a test ties the two.
const FIELD_INPUT_PROTECTED_PROPS = new Set([
    'ref',
    'children',
    'dangerouslySetInnerHTML',
    'slot',
    'type',
    'id',
    'name',
    'value',
    'defaultValue',
    'checked',
    'defaultChecked',
    'disabled',
    'readOnly',
    'required',
    'onChange',
    'onInput',
    'aria-label',
    'aria-labelledby',
    'aria-describedby',
    'aria-errormessage',
    'aria-invalid',
    'aria-required',
    'aria-disabled',
    'aria-readonly',
]);
function fieldInputProps(inputProps, ownedProps) {
    const nativeProps = inputProps && typeof inputProps === 'object' ? { ...inputProps } : {};
    for (const prop of FIELD_INPUT_PROTECTED_PROPS)
        delete nativeProps[prop];
    const { className, ...rest } = nativeProps;
    return {
        ...rest,
        ...ownedProps,
        className: classNames('muxui-field-input', className),
    };
}
function optionalInputProps(entries) {
    return Object.fromEntries(Object.entries(entries).filter(([, value]) => value !== undefined));
}
const FieldInput = React.forwardRef(function FieldInput({ onKeyDown, ...props }, ref) {
    // RAC's field components provide a plain props object here, not a slotted one.
    const { onKeyDown: handleFieldKeyDown, ...inputContext } = React.useContext(AriaInputContext);
    // Let native input handlers cancel field shortcuts before they submit or clear.
    return React.createElement(AriaInputContext.Provider, { value: inputContext }, React.createElement(AriaInput, {
        ...props,
        ref,
        onKeyDown(event) {
            onKeyDown?.(event);
            if (!event.defaultPrevented)
                handleFieldKeyDown?.(event);
        },
    }));
});
// NumberField's steppers take their accessible names from React Aria's button context, by slot, which
// IconButton reads there; its types ask for a name on the element itself.
const StepperButton = IconButton;
function fieldLabel(label) {
    return label === undefined || label === null ? null : React.createElement(AriaLabel, { className: 'muxui-field-label' }, label);
}
function assertAccessibleName({ label, ariaLabel, ariaLabelledby }, componentName) {
    if ((label === undefined || label === null || label === false || label === '') && !ariaLabel && !ariaLabelledby) {
        throw new TypeError(`${componentName} requires label, aria-label, or aria-labelledby`);
    }
}
function fieldDescription(description) {
    return description === undefined ? null : React.createElement(AriaText, { slot: 'description', className: 'muxui-field-description' }, description);
}
function fieldError(errorMessage) {
    return React.createElement(FieldErrorText, { className: 'muxui-field-error' }, errorMessage);
}
// Keep the calendar geometry Mux UI-owned instead of importing a newer glyph.
function calendarGlyph() {
    return React.createElement('svg', {
        className: 'muxui-icon muxui-icon--sm',
        'aria-hidden': 'true',
        focusable: 'false',
        xmlns: 'http://www.w3.org/2000/svg',
        viewBox: '0 0 24 24',
        width: 24,
        height: 24,
        fill: 'none',
        stroke: 'currentColor',
        strokeWidth: 2,
        strokeLinecap: 'round',
        strokeLinejoin: 'round',
    }, React.createElement('path', { d: 'M8 2v4' }), React.createElement('path', { d: 'M16 2v4' }), React.createElement('rect', { width: 18, height: 18, x: 3, y: 4, rx: 2 }), React.createElement('path', { d: 'M3 10h18' }));
}
// The scope adds an error that appears after the field mounted to the aria-describedby React Aria gives the input.
function fieldChildren({ label, description, errorMessage, children, input }) {
    return lateErrorScope(AriaInputContext, fieldLabel(label), input, children, fieldDescription(description), fieldError(errorMessage));
}
// RAC's named validation context covers its own field serialization. These
// wrappers keep their Mux-owned hidden inputs, so they need the same external
// errors without forwarding names into RAC and creating duplicate values.
const MuxFormValidationContext = React.createContext(null);
function normalizeValidationMessages(value) {
    if (value === undefined || value === null)
        return [];
    return (Array.isArray(value) ? value : [value])
        .filter((message) => message !== undefined && message !== null)
        .map(String);
}
// Like RAC's server errors, an edit or reset dismisses the current errors
// until the Form receives a new validationErrors object.
function useMuxFormValidation(names) {
    const validationErrors = React.useContext(MuxFormValidationContext);
    const [dismissedErrors, setDismissedErrors] = React.useState(null);
    const messages = dismissedErrors === validationErrors ? [] : (Array.isArray(names) ? names : [names]).flatMap((name) => {
        if (!name || !validationErrors || !Object.prototype.hasOwnProperty.call(validationErrors, name))
            return [];
        return normalizeValidationMessages(validationErrors[name]);
    });
    return { isInvalid: messages.length > 0, message: messages.join(' '), dismiss: () => setDismissedErrors(validationErrors) };
}
// errorMessage only customizes the message RAC's FieldError shows while the
// field is invalid; it never makes the field invalid on its own.
function validationProps({ disabled, readOnly, required, invalid }) {
    return {
        isDisabled: disabled,
        isReadOnly: readOnly,
        isRequired: required,
        // Leave invalid uncontrolled unless forced so native, custom, and Form's
        // name-keyed server validation can flow through RAC's context.
        isInvalid: invalid ? true : undefined,
    };
}
function parseDateValue(value) {
    const message = 'Mux UI date values must use YYYY-MM-DD ISO format';
    if (typeof value !== 'string' || !ISO_DATE_PATTERN.test(value))
        throw new TypeError(message);
    try {
        return parseDate(value);
    }
    catch {
        throw new TypeError(message);
    }
}
function dateOrUndefined(value) {
    if (value === undefined || value === null || value === '')
        return undefined;
    return parseDateValue(value);
}
// TimeField works at minute precision: HH:mm:ss input is accepted (as
// database time columns produce) and its seconds are dropped, so values,
// bounds, display, and submission all compare at the same precision.
function timeOrUndefined(value) {
    if (value === undefined || value === null || value === '')
        return undefined;
    const message = 'Mux UI time values must use HH:mm[:ss[.fraction]] ISO format';
    if (typeof value !== 'string' || !ISO_TIME_PATTERN.test(value))
        throw new TypeError(message);
    let time;
    try {
        time = parseTime(value);
    }
    catch {
        throw new TypeError(message);
    }
    return time.set({ second: 0, millisecond: 0 });
}
function dateRangeOrUndefined(value) {
    if (value === undefined || value === null)
        return undefined;
    const message = 'Mux UI date ranges must include start and end ISO dates';
    if (typeof value !== 'object' || Array.isArray(value) || value.start === undefined || value.start === null || value.start === '' || value.end === undefined || value.end === null || value.end === '') {
        throw new TypeError(message);
    }
    return { start: parseDateValue(value.start), end: parseDateValue(value.end) };
}
// RAC treats an undefined value as uncontrolled, so a cleared controlled
// field (null or '') must reach it as null to stay controlled and empty.
function controlledTemporal(value, parse) {
    return value === undefined ? undefined : parse(value) ?? null;
}
function assertTemporalBounds(minValue, maxValue, valueName) {
    if (minValue && maxValue && minValue.compare(maxValue) > 0) {
        throw new TypeError(`Mux UI ${valueName} minValue must be less than or equal to maxValue`);
    }
}
function dateBounds(minValue, maxValue) {
    const parsedMinValue = dateOrUndefined(minValue);
    const parsedMaxValue = dateOrUndefined(maxValue);
    assertTemporalBounds(parsedMinValue, parsedMaxValue, 'date');
    return { minValue: parsedMinValue, maxValue: parsedMaxValue };
}
function timeBounds(minValue, maxValue) {
    const parsedMinValue = timeOrUndefined(minValue);
    const parsedMaxValue = timeOrUndefined(maxValue);
    assertTemporalBounds(parsedMinValue, parsedMaxValue, 'time');
    return { minValue: parsedMinValue, maxValue: parsedMaxValue };
}
function unavailableDateCallback(callback) {
    if (callback === undefined)
        return undefined;
    if (typeof callback !== 'function')
        throw new TypeError('unavailableDateMatcher must be a function');
    return (date) => callback(String(date));
}
function unavailableDateRangeCallback(callback) {
    if (callback === undefined)
        return undefined;
    if (typeof callback !== 'function')
        throw new TypeError('unavailableDateMatcher must be a function');
    return (date, anchorDate) => callback(String(date), anchorDate ? String(anchorDate) : null);
}
function serializeDateValue(value) {
    return value ? String(value) : null;
}
// Submit and emit times at TimeField's minute precision as HH:mm.
function serializeTimeValue(value) {
    return value ? String(value).slice(0, 5) : null;
}
// React Aria's types make the children of some components a required prop. createElement sets that
// prop from the children it takes after the props, so the props carry only this placeholder.
const CHILDREN_FOLLOW = undefined;
// RAC's collection children are render functions its types do not take as extra createElement
// arguments, so they go in the children prop; a React element's children are the same either way.
function calendarChildren(cellClass = 'muxui-calendar__cell') {
    const grid = React.createElement(CalendarHeightMotion, null, React.createElement(AriaCalendarGrid, { className: 'muxui-calendar__grid' }, React.createElement(AriaCalendarGridHeader, {
        className: 'muxui-calendar__grid-header',
        children: (day) => React.createElement(AriaCalendarHeaderCell, { className: 'muxui-calendar__header-cell' }, day),
    }), React.createElement(AriaCalendarGridBody, {
        className: 'muxui-calendar__grid-body',
        children: (date) => React.createElement(AriaCalendarCell, { date, className: cellClass, ...{ 'data-muxui-date': cellClass === 'muxui-range-calendar__cell' ? String(date) : undefined } }),
    })));
    return cellClass === 'muxui-range-calendar__cell' ? React.createElement(RangeSelectionMotion, null, grid) : grid;
}
function calendarHeader() {
    return React.createElement('div', { className: 'muxui-calendar__header' }, React.createElement(IconButton, { slot: 'previous', 'aria-label': 'Previous month', className: 'muxui-calendar__previous' }, React.createElement(ChevronLeftIcon, { className: 'muxui-icon muxui-icon--sm', 'aria-hidden': 'true', focusable: 'false' })), React.createElement(AriaCalendarHeading, { className: 'muxui-calendar__heading' }), React.createElement(IconButton, { slot: 'next', 'aria-label': 'Next month', className: 'muxui-calendar__next' }, React.createElement(ChevronRightIcon, { className: 'muxui-icon muxui-icon--sm', 'aria-hidden': 'true', focusable: 'false' })));
}
function datePopover() {
    return React.createElement(DatePopoverMotion, { ownerClassName: 'muxui-date-picker__popover' }, React.createElement(AriaDialog, { className: 'muxui-date-dialog' }, React.createElement(AriaCalendar, { className: 'muxui-calendar' }, calendarHeader(), calendarChildren())));
}
function rangeDatePopover(triggerRef) {
    return React.createElement(DatePopoverMotion, { placement: 'bottom end', triggerRef, ownerClassName: 'muxui-date-range-picker__popover' }, React.createElement(AriaDialog, { className: 'muxui-date-dialog' }, React.createElement(AriaRangeCalendar, { className: 'muxui-calendar' }, calendarHeader(), calendarChildren('muxui-range-calendar__cell'))));
}
function dateInput() {
    return React.createElement(AriaDateInput, {
        className: 'muxui-date-input',
        children: (segment) => React.createElement(AriaDateSegment, { segment, className: 'muxui-date-segment' }),
    });
}
// RAC 1.20 owns form reset for most fields, but not TimeField and the
// range serialization below. Attach one listener to the component's owning
// form so multiple forms/components remain isolated and teardown is exact.
// Capture blocks intermediate RAC changes; the callback waits for consumer
// onReset handlers to finish before checking cancellation.
function useOwningFormReset(onReset, onResetStart, onResetEnd) {
    const callbackRef = React.useRef(onReset);
    const resetStartRef = React.useRef(onResetStart);
    const resetEndRef = React.useRef(onResetEnd);
    const formRef = React.useRef(null);
    const listenerRef = React.useRef(null);
    const resetTokenRef = React.useRef(0);
    callbackRef.current = onReset;
    resetStartRef.current = onResetStart;
    resetEndRef.current = onResetEnd;
    return React.useCallback((node) => {
        const nextForm = node?.form ?? null;
        if (nextForm === formRef.current)
            return;
        if (formRef.current && listenerRef.current) {
            formRef.current.removeEventListener('reset', listenerRef.current, true);
        }
        formRef.current = nextForm;
        listenerRef.current = null;
        if (nextForm) {
            const listener = (event) => {
                const resetToken = ++resetTokenRef.current;
                resetStartRef.current?.();
                Promise.resolve().then(() => {
                    if (resetTokenRef.current !== resetToken)
                        return;
                    resetEndRef.current?.();
                    if (!event.defaultPrevented && formRef.current === nextForm && listenerRef.current === listener)
                        callbackRef.current();
                });
            };
            listenerRef.current = listener;
            nextForm.addEventListener('reset', listener, true);
        }
    }, []);
}
function formResetAnchor(ref) {
    return React.createElement('input', {
        ref,
        type: 'hidden',
        disabled: true,
        tabIndex: -1,
        className: 'muxui-form__reset-anchor',
        'aria-hidden': 'true',
    });
}
export const TextField = React.forwardRef(function TextField({ label, description, errorMessage, value, defaultValue, onChange, disabled = false, readOnly = false, required = false, invalid = false, size = 'md', validationBehavior: _validationBehavior, name, placeholder, type = 'text', className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, autoComplete, autoFocus, inputMode, maxLength, minLength, pattern, spellCheck, inputRef, inputProps, ...props }, ref) {
    assertAccessibleName({ label, ariaLabel, ariaLabelledby }, 'TextField');
    const resolvedSize = normalizeChoiceControlSize(size, 'TextField');
    return React.createElement(AriaTextField, {
        ...props,
        ref,
        ...validationProps({ disabled, readOnly, required, invalid }),
        value,
        defaultValue,
        onChange,
        name,
        className: classNames('muxui-text-field', className),
        ...{ 'data-muxui-size': resolvedSize },
        'aria-label': ariaLabel,
        'aria-labelledby': ariaLabelledby,
    }, fieldChildren({
        label,
        description,
        errorMessage,
        input: React.createElement(FieldInput, {
            ...fieldInputProps(inputProps, {
                ...optionalInputProps({ placeholder, autoComplete, autoFocus, inputMode, maxLength, minLength, pattern, spellCheck }),
                type,
                ref: inputRef,
            }),
        }),
    }));
});
TextField.displayName = 'TextField';
export const SearchField = React.forwardRef(function SearchField({ label, description, errorMessage, value, defaultValue, onChange, onSubmit, onClear, disabled = false, readOnly = false, required = false, invalid = false, size = 'md', validationBehavior: _validationBehavior, name, placeholder, inputRef, inputProps, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
    assertAccessibleName({ label, ariaLabel, ariaLabelledby }, 'SearchField');
    const resolvedSize = normalizeChoiceControlSize(size, 'SearchField');
    return React.createElement(AriaSearchField, {
        ...props,
        ref,
        ...validationProps({ disabled, readOnly, required, invalid }),
        value,
        defaultValue,
        onChange,
        onSubmit,
        // RAC fires onClear for both Escape and the clear button.
        onClear,
        name,
        className: classNames('muxui-search-field', className),
        ...{ 'data-muxui-size': resolvedSize },
        'aria-label': ariaLabel,
        'aria-labelledby': ariaLabelledby,
    }, fieldChildren({
        label,
        description,
        errorMessage,
        input: React.createElement('div', { className: 'muxui-search-field__control' }, React.createElement(FieldInput, {
            ...fieldInputProps(inputProps, {
                ...optionalInputProps({ placeholder }),
                ref: inputRef,
            }),
        }), React.createElement(IconButton, { slot: 'clear', type: 'button', className: 'muxui-search-field__clear', 'aria-label': 'Clear search' }, React.createElement(XIcon, { className: 'muxui-search-field__clear-icon', 'aria-hidden': 'true', focusable: 'false', size: 14 }))),
    }));
});
SearchField.displayName = 'SearchField';
export const NumberField = React.forwardRef(function NumberField({ label, description, errorMessage, value, defaultValue, onChange, disabled = false, readOnly = false, required = false, invalid = false, size = 'md', validationBehavior: _validationBehavior, name, minValue, maxValue, step = 1, formatOptions, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
    assertAccessibleName({ label, ariaLabel, ariaLabelledby }, 'NumberField');
    const resolvedSize = normalizeChoiceControlSize(size, 'NumberField');
    return React.createElement(AriaNumberField, {
        ...props,
        ref,
        ...validationProps({ disabled, readOnly, required, invalid }),
        value,
        defaultValue,
        onChange,
        name,
        minValue,
        maxValue,
        step,
        formatOptions,
        className: classNames('muxui-number-field', className),
        ...{ 'data-muxui-size': resolvedSize },
        'aria-label': ariaLabel,
        'aria-labelledby': ariaLabelledby,
    }, fieldChildren({
        label,
        description,
        errorMessage,
        input: React.createElement(AriaGroup, { className: 'muxui-number-field__control' }, React.createElement(StepperButton, { slot: 'decrement', type: 'button', className: 'muxui-number-field__stepper muxui-number-field__decrement' }, React.createElement(MinusIcon, { className: 'muxui-number-field__stepper-icon', 'aria-hidden': 'true', focusable: 'false', size: 16 })), React.createElement(AriaInput, { className: 'muxui-field-input' }), React.createElement(StepperButton, { slot: 'increment', type: 'button', className: 'muxui-number-field__stepper muxui-number-field__increment' }, React.createElement(PlusIcon, { className: 'muxui-number-field__stepper-icon', 'aria-hidden': 'true', focusable: 'false', size: 16 }))),
    }));
});
NumberField.displayName = 'NumberField';
export const CheckboxGroup = React.forwardRef(function CheckboxGroup({ label, description, errorMessage, value, defaultValue, onChange, disabled = false, orientation = 'vertical', size = 'md', readOnly = false, required = false, invalid = false, validationBehavior: _validationBehavior, name, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, children, ...props }, ref) {
    assertAccessibleName({ label, ariaLabel, ariaLabelledby }, 'CheckboxGroup');
    if (orientation !== 'horizontal' && orientation !== 'vertical') {
        throw new TypeError('CheckboxGroup orientation must be horizontal or vertical');
    }
    const resolvedSize = normalizeChoiceControlSize(size, 'CheckboxGroup');
    const labelId = React.useId();
    const hasLabel = label !== undefined && label !== null;
    const group = React.createElement(AriaCheckboxGroup, {
        ...props,
        ref,
        ...validationProps({ disabled, readOnly, required, invalid }),
        value,
        defaultValue,
        onChange,
        // RAC carries this through CheckboxGroupStateContext to every descendant
        // checkbox, including fragments and wrapper components.
        name,
        className: classNames('muxui-checkbox-group', className),
        ...{ 'data-muxui-state-orientation': orientation, 'data-muxui-size': resolvedSize },
        'aria-label': ariaLabel,
        // The visible label sits outside the options' flex layout, so name the
        // group by id rather than through RAC's label slot.
        'aria-labelledby': ariaLabelledby ?? (hasLabel ? labelId : undefined),
    }, children, fieldDescription(description), fieldError(errorMessage));
    const field = React.createElement('div', { className: 'muxui-checkbox-group__field' }, hasLabel ? React.createElement(AriaLabel, { id: labelId, elementType: 'span', className: 'muxui-field-label' }, label) : null, group);
    return React.createElement(ChoiceControlSizeContext.Provider, { value: resolvedSize }, field);
});
CheckboxGroup.displayName = 'CheckboxGroup';
// Pure wrapping lets root-barrel consumers drop Switch's private motion edge.
export const Switch = /*#__PURE__*/ (() => {
    const component = React.forwardRef(function Switch({ label, children, selected, defaultSelected = false, onChange, disabled = false, readOnly = false, description, errorMessage, required = false, invalid = false, size = 'md', validationBehavior: _validationBehavior, name, value, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
        assertAccessibleName({ label, ariaLabel, ariaLabelledby }, 'Switch');
        const resolvedSize = normalizeChoiceControlSize(size, 'Switch');
        const visibleLabel = label === undefined || label === null ? children : label;
        return React.createElement(AriaSwitchField, {
            ...props,
            ref,
            ...validationProps({ disabled, readOnly, required, invalid }),
            isSelected: selected,
            defaultSelected,
            name,
            value,
            className: classNames('muxui-switch-field', className),
            ...{ 'data-muxui-size': resolvedSize },
            'aria-label': ariaLabel,
            'aria-labelledby': ariaLabelledby,
            onChange,
        }, React.createElement(AriaSwitchButton, {
            className: 'muxui-switch',
            children: ({ isSelected, isPressed, isDisabled, isReadOnly }) => React.createElement(React.Fragment, null, React.createElement(SwitchMotionIndicator, { isSelected, isPressed, isDisabled, isReadOnly }), visibleLabel !== undefined && visibleLabel !== null
                ? React.createElement('span', { className: 'muxui-switch__label' }, visibleLabel)
                : null),
        }), fieldDescription(description), fieldError(errorMessage));
    });
    component.displayName = 'Switch';
    return component;
})();
// React Aria narrows some of a form's native attributes (encType and method to the values the DOM
// accepts), which Form takes from React's form attributes unchanged.
const FormElement = AriaForm;
export const Form = React.forwardRef(function Form({ children, className, validationBehavior = 'native', validationErrors, onSubmit, onReset, ...props }, ref) {
    return React.createElement(FormElement, {
        ...props,
        ref,
        className: classNames('muxui-form', className),
        validationBehavior,
        validationErrors,
        onSubmit,
        onReset,
    }, React.createElement(MuxFormValidationContext.Provider, { value: validationErrors === undefined || validationErrors === null ? {} : validationErrors }, children));
});
Form.displayName = 'Form';
export const DateField = React.forwardRef(function DateField({ label, description, errorMessage, value, defaultValue, minValue, maxValue, unavailableDateMatcher, isDateUnavailable: _upstreamDateUnavailable, onChange, disabled = false, readOnly = false, required = false, invalid = false, size = 'md', validationBehavior: _validationBehavior, name, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
    assertAccessibleName({ label, ariaLabel, ariaLabelledby }, 'DateField');
    const resolvedSize = normalizeChoiceControlSize(size, 'DateField');
    const parsedValue = React.useMemo(() => controlledTemporal(value, dateOrUndefined), [value]);
    const parsedDefaultValue = React.useMemo(() => dateOrUndefined(defaultValue), [defaultValue]);
    const { minValue: parsedMinValue, maxValue: parsedMaxValue } = dateBounds(minValue, maxValue);
    return React.createElement(AriaDateField, {
        ...props,
        ref,
        ...validationProps({ disabled, readOnly, required, invalid }),
        value: parsedValue,
        defaultValue: parsedDefaultValue,
        minValue: parsedMinValue,
        maxValue: parsedMaxValue,
        isDateUnavailable: unavailableDateCallback(unavailableDateMatcher),
        onChange: (next) => onChange?.(serializeDateValue(next)),
        name,
        className: classNames('muxui-date-field', className),
        ...{ 'data-muxui-size': resolvedSize },
        'aria-label': ariaLabel,
        'aria-labelledby': ariaLabelledby,
    }, fieldChildren({ label, description, errorMessage, input: dateInput() }));
});
DateField.displayName = 'DateField';
export const TimeField = React.forwardRef(function TimeField({ label, description, errorMessage, value, defaultValue, minValue, maxValue, onChange, disabled = false, readOnly = false, required = false, invalid = false, size = 'md', validationBehavior: _validationBehavior, name, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
    assertAccessibleName({ label, ariaLabel, ariaLabelledby }, 'TimeField');
    const resolvedSize = normalizeChoiceControlSize(size, 'TimeField');
    const externalValidation = useMuxFormValidation(name);
    const effectiveErrorMessage = errorMessage !== undefined ? errorMessage : externalValidation.message || undefined;
    const parsedValue = React.useMemo(() => controlledTemporal(value, timeOrUndefined), [value]);
    const parsedDefaultValue = React.useMemo(() => timeOrUndefined(defaultValue), [defaultValue]);
    const { minValue: parsedMinValue, maxValue: parsedMaxValue } = timeBounds(minValue, maxValue);
    const [formValue, setFormValue] = React.useState(() => serializeTimeValue(parsedValue ?? parsedDefaultValue));
    const resettingRef = React.useRef(false);
    const handleChange = (next) => {
        if (resettingRef.current)
            return;
        const nextValue = serializeTimeValue(next);
        externalValidation.dismiss();
        if (value === undefined)
            setFormValue(nextValue);
        onChange?.(nextValue);
    };
    const handleReset = () => {
        externalValidation.dismiss();
        if (value === undefined)
            setFormValue(serializeTimeValue(parsedDefaultValue));
    };
    const resetInputRef = useOwningFormReset(handleReset, () => { resettingRef.current = true; }, () => { resettingRef.current = false; });
    // Mux owns TimeField state, so RAC always receives a controlled value.
    const submittedValue = value !== undefined ? serializeTimeValue(parsedValue) : formValue;
    const effectiveParsedValue = React.useMemo(() => timeOrUndefined(submittedValue) ?? null, [submittedValue]);
    return React.createElement(AriaTimeField, {
        ...props,
        ref,
        ...validationProps({ disabled, readOnly, required, invalid: invalid ? invalid : externalValidation.isInvalid }),
        value: effectiveParsedValue,
        minValue: parsedMinValue,
        maxValue: parsedMaxValue,
        placeholderValue: TIME_PLACEHOLDER,
        onChange: handleChange,
        // Keep RAC's name private: Mux owns one normalized hidden value so FormData
        // stays stable and cannot duplicate an upstream field input.
        name: undefined,
        className: classNames('muxui-time-field', className),
        ...{ 'data-muxui-size': resolvedSize },
        'aria-label': ariaLabel,
        'aria-labelledby': ariaLabelledby,
    }, fieldChildren({
        label,
        description,
        errorMessage: effectiveErrorMessage,
        input: dateInput(),
        children: React.createElement(React.Fragment, null, formResetAnchor(resetInputRef), name ? React.createElement('input', { className: 'muxui-form__value', type: 'hidden', name, value: submittedValue ?? '', disabled, readOnly: true, 'aria-hidden': 'true' }) : null),
    }));
});
TimeField.displayName = 'TimeField';
// Pure wrappers let unused date-picker imports omit motion code.
export const DatePicker = /*#__PURE__*/ (() => {
    const component = React.forwardRef(function DatePicker({ label, description, errorMessage, value, defaultValue, minValue, maxValue, unavailableDateMatcher, isDateUnavailable: _upstreamDateUnavailable, onChange, onOpenChange, open, defaultOpen, disabled = false, readOnly = false, required = false, invalid = false, size = 'md', validationBehavior: _validationBehavior, name, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
        assertAccessibleName({ label, ariaLabel, ariaLabelledby }, 'DatePicker');
        const resolvedSize = normalizeChoiceControlSize(size, 'DatePicker');
        const parsedValue = React.useMemo(() => controlledTemporal(value, dateOrUndefined), [value]);
        const parsedDefaultValue = React.useMemo(() => dateOrUndefined(defaultValue), [defaultValue]);
        const { minValue: parsedMinValue, maxValue: parsedMaxValue } = dateBounds(minValue, maxValue);
        return React.createElement(AriaDatePicker, {
            ...props,
            ref,
            ...validationProps({ disabled, readOnly, required, invalid }),
            value: parsedValue,
            defaultValue: parsedDefaultValue,
            minValue: parsedMinValue,
            maxValue: parsedMaxValue,
            isDateUnavailable: unavailableDateCallback(unavailableDateMatcher),
            onChange: (next) => onChange?.(serializeDateValue(next)),
            isOpen: open,
            defaultOpen,
            onOpenChange,
            name,
            className: classNames('muxui-date-picker', className),
            ...{ 'data-muxui-size': resolvedSize },
            'aria-label': ariaLabel,
            'aria-labelledby': ariaLabelledby,
        }, fieldChildren({
            label,
            description,
            errorMessage,
            input: React.createElement(AriaGroup, { className: 'muxui-date-picker__control' }, dateInput(), React.createElement(IconButton, { slot: 'button', type: 'button', 'aria-label': 'Open calendar', className: 'muxui-date-trigger' }, calendarGlyph())),
            children: datePopover(),
        }));
    });
    component.displayName = 'DatePicker';
    return component;
})();
export const DateRangePicker = /*#__PURE__*/ (() => {
    const component = React.forwardRef(function DateRangePicker({ label, description, errorMessage, value, defaultValue, minValue, maxValue, unavailableDateMatcher, isDateUnavailable: _upstreamDateUnavailable, onChange, onOpenChange, open, defaultOpen, disabled = false, readOnly = false, required = false, invalid = false, size = 'md', validationBehavior: _validationBehavior, allowsNonContiguousRanges: _allowsNonContiguousRanges, closeOnSelect: _closeOnSelect, shouldCloseOnSelect: _shouldCloseOnSelect, startName, endName, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
        assertAccessibleName({ label, ariaLabel, ariaLabelledby }, 'DateRangePicker');
        const resolvedSize = normalizeChoiceControlSize(size, 'DateRangePicker');
        const triggerRef = React.useRef(null);
        const externalValidation = useMuxFormValidation([startName, endName]);
        const effectiveErrorMessage = errorMessage !== undefined ? errorMessage : externalValidation.message || undefined;
        const parsedValue = React.useMemo(() => controlledTemporal(value, dateRangeOrUndefined), [value === null, value?.start, value?.end]);
        const { minValue: parsedMinValue, maxValue: parsedMaxValue } = dateBounds(minValue, maxValue);
        const [formValue, setFormValue] = React.useState(() => (value === undefined || value === null ? defaultValue : value) ?? null);
        const resettingRef = React.useRef(false);
        const handleChange = (next) => {
            if (resettingRef.current)
                return;
            const nextValue = next ? { start: serializeDateValue(next.start), end: serializeDateValue(next.end) } : null;
            externalValidation.dismiss();
            if (value === undefined)
                setFormValue(nextValue);
            onChange?.(nextValue);
        };
        const handleReset = () => {
            externalValidation.dismiss();
            if (value === undefined)
                setFormValue(defaultValue === undefined || defaultValue === null ? null : defaultValue);
        };
        const resetInputRef = useOwningFormReset(handleReset, () => { resettingRef.current = true; }, () => { resettingRef.current = false; });
        const submittedValue = value !== undefined ? value : formValue;
        const parsedFormValue = React.useMemo(() => dateRangeOrUndefined(formValue) ?? null, [formValue?.start, formValue?.end]);
        // Mux owns range state, so RAC always receives a controlled value.
        const effectiveValueObject = value !== undefined ? parsedValue : parsedFormValue;
        return React.createElement(AriaDateRangePicker, {
            ...props,
            ref,
            ...validationProps({ disabled, readOnly, required, invalid: invalid ? invalid : externalValidation.isInvalid }),
            value: effectiveValueObject,
            minValue: parsedMinValue,
            maxValue: parsedMaxValue,
            isDateUnavailable: unavailableDateRangeCallback(unavailableDateMatcher),
            onChange: handleChange,
            isOpen: open,
            defaultOpen,
            onOpenChange,
            // React Aria's range picker takes startName and endName, not a name.
            ...{ name: undefined },
            className: classNames('muxui-date-range-picker', className),
            ...{ 'data-muxui-size': resolvedSize },
            'aria-label': ariaLabel,
            'aria-labelledby': ariaLabelledby,
        }, fieldChildren({
            label,
            description,
            errorMessage: effectiveErrorMessage,
            input: React.createElement(AriaGroup, { className: 'muxui-date-range-picker__control' }, React.createElement(AriaDateInput, {
                slot: 'start',
                className: 'muxui-date-input muxui-date-range-picker__start',
                children: (segment) => React.createElement(AriaDateSegment, { segment, className: 'muxui-date-segment' }),
            }), React.createElement('span', { className: 'muxui-date-range-picker__separator', 'aria-hidden': 'true' }, '–'), React.createElement(AriaDateInput, {
                slot: 'end',
                className: 'muxui-date-input muxui-date-range-picker__end',
                children: (segment) => React.createElement(AriaDateSegment, { segment, className: 'muxui-date-segment' }),
            }), React.createElement(IconButton, { ref: triggerRef, slot: 'button', type: 'button', 'aria-label': 'Open calendar', className: 'muxui-date-trigger' }, calendarGlyph())),
            children: React.createElement(React.Fragment, null, rangeDatePopover(triggerRef), formResetAnchor(resetInputRef), startName ? React.createElement('input', { className: 'muxui-form__value', type: 'hidden', name: startName, value: submittedValue?.start ?? '', disabled, readOnly: true, 'aria-hidden': 'true' }) : null, endName ? React.createElement('input', { className: 'muxui-form__value', type: 'hidden', name: endName, value: submittedValue?.end ?? '', disabled, readOnly: true, 'aria-hidden': 'true' }) : null),
        }));
    });
    component.displayName = 'DateRangePicker';
    return component;
})();
function normalizeAutocompleteItems(items) {
    const usedIds = new Set();
    return (items ?? []).map((item, index) => {
        const source = typeof item === 'string'
            ? { label: item, value: item }
            : item;
        const baseId = String(source.id ?? source.value ?? index) || String(index);
        let id = baseId;
        let suffix = 1;
        while (usedIds.has(id))
            id = `${baseId}-${suffix++}`;
        usedIds.add(id);
        // A label-only item submits its text rather than its generated index id.
        const value = source.value ?? (source.id === undefined ? autocompleteNodeText(source.label) || id : id);
        return { ...source, id, label: source.label ?? source.value ?? id, value };
    });
}
function autocompleteNodeText(value) {
    if (typeof value === 'string' || typeof value === 'number' || typeof value === 'bigint')
        return String(value);
    if (Array.isArray(value))
        return value.map(autocompleteNodeText).join('');
    if (React.isValidElement(value))
        return autocompleteNodeText(value.props.children);
    return '';
}
function autocompleteItemText(item) {
    const fallback = String(item.value ?? item.id);
    return autocompleteNodeText(item.label) || fallback;
}
const AUTOCOMPLETE_SIZES = new Set(['sm', 'md', 'lg']);
function normalizeAutocompleteSize(size) {
    const resolved = size ?? 'md';
    if (!AUTOCOMPLETE_SIZES.has(resolved)) {
        throw new TypeError(`Autocomplete size must be one of: ${[...AUTOCOMPLETE_SIZES].join(', ')}`);
    }
    return resolved;
}
export const Autocomplete = /*#__PURE__*/ (() => {
    const component = React.forwardRef(function Autocomplete({ label, description, errorMessage, items, value, defaultValue = '', onChange, onSelect, disabled = false, readOnly = false, required = false, invalid = false, size = 'md', validationBehavior: _validationBehavior, name, placeholder, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
        assertAccessibleName({ label, ariaLabel, ariaLabelledby }, 'Autocomplete');
        const resolvedSize = normalizeAutocompleteSize(size);
        const normalizedItems = React.useMemo(() => normalizeAutocompleteItems(items), [items]);
        // The input shows a selected item's label while the form and onChange
        // carry its value; typed text is both the shown and the submitted value.
        const entryForValue = (nextValue) => {
            const item = normalizedItems.find((candidate) => String(candidate.value) === nextValue);
            return item ? { text: autocompleteItemText(item), selected: nextValue } : { text: nextValue, selected: null };
        };
        // Prop-sourced entries resolve their label on every render, so items that
        // load after the value still show its label. Typed and selected entries
        // keep their own text.
        const [storedEntry, setEntry] = React.useState(() => ({ fromProp: (value === undefined || value === null ? defaultValue : value) ?? '' }));
        const storedValue = storedEntry.fromProp ?? storedEntry.selected ?? storedEntry.text;
        // A controlled value that differs from the last edit came from outside.
        const entry = value !== undefined && value !== storedValue
            ? entryForValue(value)
            : storedEntry.fromProp !== undefined ? entryForValue(storedEntry.fromProp) : storedEntry;
        const submittedValue = entry.selected ?? entry.text;
        const effectiveInputValue = entry.text;
        const externalValidation = useMuxFormValidation(name);
        const effectiveErrorMessage = errorMessage !== undefined ? errorMessage : externalValidation.message || undefined;
        const resettingRef = React.useRef(false);
        const resetInputRef = useOwningFormReset(() => {
            externalValidation.dismiss();
            if (value === undefined)
                setEntry({ fromProp: defaultValue ?? '' });
        }, () => { resettingRef.current = true; }, () => { resettingRef.current = false; });
        const filteredItems = React.useMemo(() => {
            const query = effectiveInputValue.toLocaleLowerCase();
            return normalizedItems.filter((item) => autocompleteItemText(item).toLocaleLowerCase().includes(query));
        }, [effectiveInputValue, normalizedItems]);
        const [isOpen, setIsOpen] = React.useState(false);
        const inputRef = React.useRef(null);
        // The visible input finds the owning form, so no extra reset anchor input is needed.
        const setInputRef = React.useCallback((node) => {
            inputRef.current = node;
            resetInputRef(node);
        }, [resetInputRef]);
        const popoverRef = React.useRef(null);
        // Outside dismissal lets RAC restore this trigger; consume that focus without reopening.
        const pendingFocusRestoreRef = React.useRef(false);
        const pendingFocusRestoreCleanupRef = React.useRef(null);
        // The guard's one pending frame: the post-blur focus check or the expiry.
        const pendingFocusRestoreFrameRef = React.useRef(0);
        const clearPendingFocusRestore = () => {
            pendingFocusRestoreRef.current = false;
            if (pendingFocusRestoreFrameRef.current)
                cancelAnimationFrame(pendingFocusRestoreFrameRef.current);
            pendingFocusRestoreFrameRef.current = 0;
            pendingFocusRestoreCleanupRef.current?.();
            pendingFocusRestoreCleanupRef.current = null;
        };
        // RAC restores trigger focus one frame after the popover's FocusScope
        // unmounts, and only when the list was its active scope. Expire the guard
        // two frames after the list is gone so an unused guard cannot swallow a
        // later legitimate focus. After a virtual (screen reader) interaction RAC
        // defers its restore until page transitions end, which can outlast this.
        const expirePendingFocusRestore = () => {
            if (!pendingFocusRestoreRef.current)
                return;
            cancelAnimationFrame(pendingFocusRestoreFrameRef.current);
            pendingFocusRestoreFrameRef.current = requestAnimationFrame(() => {
                pendingFocusRestoreFrameRef.current = requestAnimationFrame(() => {
                    if (!popoverRef.current?.isConnected)
                        clearPendingFocusRestore();
                });
            });
        };
        const armPendingFocusRestore = () => {
            clearPendingFocusRestore();
            pendingFocusRestoreRef.current = true;
            if (!popoverRef.current?.isConnected)
                expirePendingFocusRestore();
            const handleFocusIn = (event) => {
                const target = event.target;
                const externalFocus = target
                    && target !== document.body
                    && target !== document.documentElement
                    && target !== inputRef.current
                    && !inputRef.current?.contains(target)
                    && !popoverRef.current?.contains(target);
                if (externalFocus)
                    clearPendingFocusRestore();
            };
            const handleKeyDown = (event) => {
                if (event.key === 'Tab')
                    clearPendingFocusRestore();
            };
            document.addEventListener('focusin', handleFocusIn, true);
            document.addEventListener('keydown', handleKeyDown, true);
            pendingFocusRestoreCleanupRef.current = () => {
                document.removeEventListener('focusin', handleFocusIn, true);
                document.removeEventListener('keydown', handleKeyDown, true);
            };
        };
        React.useEffect(() => () => clearPendingFocusRestore(), []);
        // Stable so PopoverMotion only sees null when the list actually detaches;
        // the guard helpers read refs alone, so the first-render closures suffice.
        const setPopoverRef = React.useCallback((node) => {
            popoverRef.current = node;
            if (!node)
                expirePendingFocusRestore();
        }, []);
        const suggestionsOpen = isOpen && filteredItems.length > 0;
        const portalContainer = autocompletePortalContainer(inputRef.current);
        React.useEffect(() => {
            if (!suggestionsOpen)
                return undefined;
            const handlePointerDown = (event) => {
                const target = event.target;
                if (inputRef.current?.contains(target) || popoverRef.current?.contains(target))
                    return;
                if (document.activeElement === inputRef.current)
                    armPendingFocusRestore();
                setIsOpen(false);
            };
            document.addEventListener('pointerdown', handlePointerDown, true);
            return () => document.removeEventListener('pointerdown', handlePointerDown, true);
        }, [suggestionsOpen]);
        const filter = (textValue, inputValue) => textValue.toLocaleLowerCase().includes(inputValue.toLocaleLowerCase());
        const handleSelect = (key) => {
            if (disabled)
                return;
            if (readOnly)
                return;
            const keyText = String(key);
            const item = filteredItems.find((candidate) => String(candidate.id) === keyText);
            if (item) {
                if (item.disabled)
                    return;
                const nextValue = String(item.value);
                externalValidation.dismiss();
                setEntry({ text: autocompleteItemText(item), selected: nextValue });
                onChange?.(nextValue);
            }
            onSelect?.(item);
            setIsOpen(false);
        };
        const handleInputChange = (next) => {
            clearPendingFocusRestore();
            if (disabled)
                return;
            if (readOnly)
                return;
            if (resettingRef.current)
                return;
            externalValidation.dismiss();
            setEntry({ text: next, selected: null });
            onChange?.(next);
            setIsOpen(!disabled);
        };
        return React.createElement('div', {
            ref,
            className: classNames('muxui-autocomplete', className),
            'data-muxui-size': resolvedSize,
            'data-muxui-part': 'root',
            onBlurCapture: (event) => {
                const relatedTarget = event.relatedTarget;
                const outside = !relatedTarget || (!event.currentTarget.contains(relatedTarget) && !popoverRef.current?.contains(relatedTarget));
                if (outside) {
                    if (relatedTarget && relatedTarget !== document.body && relatedTarget !== document.documentElement) {
                        clearPendingFocusRestore();
                    }
                    else if (event.target === inputRef.current && popoverRef.current?.isConnected && !pendingFocusRestoreRef.current) {
                        // Focus left for no element while the list is mounted (open or
                        // exiting). If it settles on the body, RAC may restore it to this
                        // input on unmount, so arm the guard. This also covers closes the
                        // pointerdown guard never saw, such as RAC's close on scroll.
                        // Engines disagree on the active element during blur (Firefox
                        // reports a focused iframe, Chromium and WebKit the body), so decide
                        // one frame later. RAC requests its restore frame at unmount, after
                        // this blur, so this check runs first. Window and tab switches keep
                        // the input active, and an iframe or a same-task refocus never
                        // leaves the body active, so none of them arm the guard.
                        cancelAnimationFrame(pendingFocusRestoreFrameRef.current);
                        pendingFocusRestoreFrameRef.current = requestAnimationFrame(() => {
                            pendingFocusRestoreFrameRef.current = 0;
                            if (document.activeElement === document.body)
                                armPendingFocusRestore();
                        });
                    }
                    setIsOpen(false);
                }
            },
        }, React.createElement(AriaAutocomplete, {
            ...props,
            filter,
            disableAutoFocusFirst: false,
            inputValue: effectiveInputValue,
            onInputChange: handleInputChange,
            children: CHILDREN_FOLLOW,
        }, React.createElement(AriaSearchField, {
            ...validationProps({ disabled, readOnly, required, invalid: invalid ? invalid : externalValidation.isInvalid }),
            // Keep RAC's name private: the hidden input below submits the value.
            name: undefined,
            className: 'muxui-autocomplete__search',
            ...{ 'data-muxui-part': 'search-field' },
            'aria-label': ariaLabel,
            'aria-labelledby': ariaLabelledby,
        }, fieldChildren({
            label,
            description,
            errorMessage: effectiveErrorMessage,
            input: React.createElement(FieldInput, {
                ref: setInputRef,
                className: 'muxui-field-input',
                ...{ 'data-muxui-part': 'input' },
                // WAI-ARIA combobox: RAC supplies aria-autocomplete, aria-controls,
                // and aria-activedescendant; the popup state is Mux-owned.
                role: 'combobox',
                'aria-expanded': suggestionsOpen,
                placeholder,
                onPointerDown: () => {
                    clearPendingFocusRestore();
                    if (document.activeElement === inputRef.current)
                        setIsOpen(!disabled);
                },
                onFocus: () => {
                    if (pendingFocusRestoreRef.current) {
                        clearPendingFocusRestore();
                        return;
                    }
                    setIsOpen(!disabled);
                },
                onKeyDown: (event) => {
                    clearPendingFocusRestore();
                    if (event.key === 'Escape' && suggestionsOpen) {
                        // Close the open list without the SearchField shortcut clearing
                        // the text; Escape on a closed list still clears.
                        event.preventDefault();
                        event.stopPropagation();
                    }
                    if (event.key === 'Enter' && suggestionsOpen && popoverRef.current?.querySelector('[role="option"][data-muxui-state-focused]')) {
                        // RAC selects the active option but leaves the browser's implicit
                        // form submission. Cancel only the native default so the synthetic
                        // event still reaches RAC's selection handler through FieldInput.
                        // The option's data-muxui-state-focused leads aria-activedescendant, which RAC
                        // delays while the user types.
                        event.nativeEvent.preventDefault();
                    }
                    if (event.key === 'Escape')
                        setIsOpen(false);
                    if (event.key === 'ArrowDown')
                        setIsOpen(!disabled);
                },
            }),
            children: name ? React.createElement('input', { className: 'muxui-form__value', type: 'hidden', name, value: submittedValue, disabled, readOnly: true, 'aria-hidden': 'true' }) : null,
        })), React.createElement(PopoverMotion, {
            ref: setPopoverRef,
            isOpen: suggestionsOpen,
            onOpenChange: setIsOpen,
            isNonModal: true,
            triggerRef: inputRef,
            placement: 'bottom',
            offset: 0,
            // Zero padding keeps a full-width field's overlay aligned at the viewport
            // edge; the position hook still performs collision-aware placement.
            containerPadding: 0,
            // Keep portals inside subtree-scoped Mux runtime profiles so their tokens,
            // direction, and other inherited custom properties remain available.
            UNSTABLE_portalContainer: portalContainer,
            className: 'muxui-autocomplete__popover',
            ...{ 'data-muxui-part': 'popover' },
        }, React.createElement(AriaListBox, {
            items: filteredItems,
            className: classNames('muxui-autocomplete__list', resolvedSize === 'md' ? undefined : `muxui-autocomplete__list--${resolvedSize}`),
            ...{ 'data-muxui-part': 'list', 'data-muxui-size': resolvedSize },
            selectionMode: readOnly ? 'none' : 'single',
            onAction: handleSelect,
            children: (item) => React.createElement(AriaListBoxItem, { id: item.id, textValue: autocompleteItemText(item), isDisabled: item.disabled, ...{ 'data-muxui-state-disabled': item.disabled || undefined, 'data-muxui-part': 'option' }, className: 'muxui-autocomplete__option' }, item.label),
        }))));
    });
    component.displayName = 'Autocomplete';
    return component;
})();

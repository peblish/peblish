// @generated-from: packages/react/src/supplemental/button-group.ts
// @generated-content-sha256: sha256:24dcd9eaf8587da2e9aa9da346b1beb88f8209c3767b8f3c24c7cd7d923687e4
import type { ForwardRefExoticComponent, HTMLAttributes, ReactNode, RefAttributes } from 'react';
/**
 * The props Mux UI defines for ButtonGroup; the catalog's web.react API is derived from
 * this type (Decision 0031). The group's accessible name is aria-label or aria-labelledby.
 */
type ButtonGroupOwnProps = {
    /** The direction the buttons lay out in. */
    orientation?: 'horizontal' | 'vertical';
    /** Joins the buttons, rounding only the group's outer corners. */
    attached?: boolean;
    /** Marks the group disabled. Its buttons keep their own disabled state. */
    disabled?: boolean;
    /** `presentation` names nothing; a group or region needs an accessible name, and without one the group is presentation. */
    role?: 'group' | 'region' | 'presentation';
};
export type ButtonGroupProps = ButtonGroupOwnProps & HTMLAttributes<HTMLDivElement> & {
    children?: ReactNode;
};
export declare const ButtonGroup: ForwardRefExoticComponent<ButtonGroupProps & RefAttributes<HTMLDivElement>>;
export {};

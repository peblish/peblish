// @generated-from: packages/react/src/supplemental/multi-select.ts
// @generated-content-sha256: sha256:9d50518c914439bb67815a4fa66e17dab87dd92f0b3c36ce13d2d055b208a0cd
import type { ForwardRefExoticComponent, HTMLAttributes, Key, ReactElement, ReactNode, RefAttributes } from 'react';
/** An item MultiSelect lists: a key, and whatever else the caller keeps on it. */
export type MultiSelectItem = {
    id: Key;
    [key: string]: unknown;
};
/**
 * The props Mux UI defines for MultiSelect.Root, the compound's root; the catalog's web.react API is derived from
 * this type (Decision 0031). It is generic over the item the caller lists, as the public type is, and the catalog
 * records the item at its constraint. The members every field shares are written out, because the catalog's grammar
 * reads only the members a type lists itself.
 */
type MultiSelectOwnProps<T extends MultiSelectItem = MultiSelectItem> = {
    /** The control size. */
    size?: 'sm' | 'md' | 'lg';
    /** The visible label, which also names the list. */
    label?: ReactNode;
    /** The text shown while nothing is selected. */
    placeholder?: string;
    /** Supporting text shown below the control. */
    description?: ReactNode;
    /** The message shown, in place of the description, while the control is invalid. */
    errorMessage?: ReactNode;
    /** Marks the control disabled. */
    disabled?: boolean;
    /** Marks a selection as required. */
    required?: boolean;
    /** Marks the control invalid. */
    invalid?: boolean;
    /** Text shown beside the count of selected items. */
    supportingText?: ReactNode;
    /** The title shown when no item matches the search. */
    emptyStateTitle?: string;
    /** The message shown when no item matches the search. */
    emptyStateDescription?: string;
    /** The items to choose from. */
    items?: Iterable<T>;
    /** The selected keys, when the caller controls them; `'all'` selects every item that is not disabled. */
    selectedKeys?: Set<Key> | 'all';
    /** The keys selected at first, when the control keeps its own selection. */
    defaultSelectedKeys?: Set<Key>;
    /** Called with the new selection each time it changes. */
    onSelectionChange?: (keys: Set<Key> | 'all') => void;
    /** Shows the search field in the list. */
    showSearch?: boolean;
    /** Shows the Reset and Select all buttons below the list. */
    showFooter?: boolean;
    /** Called after Reset clears the selection. */
    onReset?: () => void;
    /** Called after Select all selects every item. */
    onSelectAll?: () => void;
    /** Formats the count of selected items shown in the trigger. */
    selectedCountFormatter?: (count: number) => ReactNode;
};
export type MultiSelectProps<T extends MultiSelectItem = MultiSelectItem> = Omit<HTMLAttributes<HTMLDivElement>, 'children'> & MultiSelectOwnProps<T> & {
    children?: ReactNode | ((item: T) => ReactNode);
    readOnly?: boolean;
};
export type MultiSelectRootProps<T extends MultiSelectItem = MultiSelectItem> = MultiSelectProps<T>;
/** The props Mux UI defines for MultiSelect.Item; its API is the item entry in the catalog's partApis. */
type MultiSelectItemOwnProps = {
    /** Marks the item disabled: it cannot be selected, and Select all skips it. */
    disabled?: boolean;
    /** The text that search and typeahead match, when the item's content is not plain text. */
    textValue?: string;
};
export type MultiSelectItemProps = HTMLAttributes<HTMLDivElement> & MultiSelectItemOwnProps;
export interface MultiSelectRootComponent {
    <T extends MultiSelectItem = MultiSelectItem>(props: MultiSelectRootProps<T> & RefAttributes<HTMLDivElement>): ReactElement | null;
}
export declare const MultiSelect: {
    Root: MultiSelectRootComponent;
    Item: ForwardRefExoticComponent<MultiSelectItemProps & RefAttributes<HTMLDivElement>>;
};
export {};

// @generated-from: packages/react/src/components.ts
// @generated-content-sha256: sha256:e3f63c02a7415a4e2d045abd7ef8a2c78513e538b978062035bacc4a07f0e93b
import type { AnchorHTMLAttributes, ButtonHTMLAttributes, ForwardRefExoticComponent, HTMLAttributes, LabelHTMLAttributes, ReactNode, RefAttributes } from 'react';
import type { ButtonPointerType } from './button.js';
/** One level of a Breadcrumbs path. */
export interface BreadcrumbItem {
    /** Identifies the item. An item without one is identified by its position. */
    id?: string;
    /** What the level is called, such as the name of its page. */
    label: ReactNode;
    /** Where the level leads. An item without one, and the last item, render as text. */
    href?: string;
    /** Makes the level text that cannot be navigated to. */
    disabled?: boolean;
}
/**
 * The props Mux UI defines for Breadcrumbs; the catalog's web.react API is derived
 * from this interface (Decision 0031). The accessible name stays in the host part of
 * the props: a native attribute Breadcrumbs requires, not a prop it defines.
 */
export interface BreadcrumbsOwnProps {
    /** The levels of the path, from the top of the hierarchy down to the current page. The last item is the current page. */
    items?: BreadcrumbItem[];
    /** Reports the item a person navigates to, unless it is disabled. */
    onNavigate?: (item: BreadcrumbItem) => void;
}
export interface BreadcrumbsProps extends BreadcrumbsOwnProps, Omit<HTMLAttributes<HTMLElement>, keyof BreadcrumbsOwnProps | 'children' | 'className' | 'aria-label'> {
    className?: string;
    'aria-label': string;
}
/** A trail of links to the levels above the current page. */
export declare const Breadcrumbs: ForwardRefExoticComponent<BreadcrumbsProps & RefAttributes<HTMLElement>>;
/**
 * The props Mux UI defines for Checkbox; the catalog's web.react API is derived from
 * this interface (Decision 0031). The children are the visible label.
 */
export interface CheckboxOwnProps {
    /** Whether the Checkbox is checked, when the caller controls it. */
    checked?: boolean;
    /** Whether the Checkbox starts checked, when it controls itself. */
    defaultChecked?: boolean;
    /** Disables the Checkbox: it can be neither focused nor changed. */
    disabled?: boolean;
    /** The control size. Without one, a Checkbox in a CheckboxGroup takes the group's size, and any other takes md. */
    size?: 'sm' | 'md' | 'lg';
    /** Shows the mixed state. It is separate from checked, and toggling the Checkbox does not clear it. */
    indeterminate?: boolean;
    /** The name a checked Checkbox submits its value under. */
    name?: string;
    /** Marks the Checkbox required. Left unset, a Checkbox in a CheckboxGroup takes the group's required state. */
    required?: boolean;
    /** The value a checked Checkbox submits. */
    value?: string;
    /** Marks the Checkbox invalid. It shows no error text. */
    invalid?: boolean;
    /** Reports the new checked state. */
    onChange?: (checked: boolean) => void;
}
export interface CheckboxProps extends CheckboxOwnProps, Omit<LabelHTMLAttributes<HTMLLabelElement>, keyof CheckboxOwnProps | 'children' | 'className'> {
    children?: ReactNode;
    className?: string;
}
/** A labelled control that selects or clears one option. */
export declare const Checkbox: ForwardRefExoticComponent<CheckboxProps & RefAttributes<HTMLLabelElement>>;
/**
 * The props Mux UI defines for DisclosureGroup; the catalog's web.react API is derived
 * from this interface (Decision 0031). The children are the Disclosures it groups.
 */
export interface DisclosureGroupOwnProps {
    /** The ids of the open Disclosures, when the caller controls them. */
    expandedIds?: string[];
    /** The ids of the Disclosures that start open, when the group controls itself. */
    defaultExpandedIds?: string[];
    /** Lets several Disclosures stay open at once. Turn it off to keep at most one open. */
    multiple?: boolean;
    /** Disables every Disclosure in the group. */
    disabled?: boolean;
    /** Reports the ids of the open Disclosures, as an array of strings. */
    onExpandedChange?: (expandedIds: string[]) => void;
}
export interface DisclosureGroupProps extends DisclosureGroupOwnProps, Omit<HTMLAttributes<HTMLDivElement>, keyof DisclosureGroupOwnProps | 'children' | 'className'> {
    children?: ReactNode;
    className?: string;
}
/** A set of related Disclosures whose expansion the group owns. */
export declare const DisclosureGroup: ForwardRefExoticComponent<DisclosureGroupProps & RefAttributes<HTMLDivElement>>;
/**
 * The props Mux UI defines for Disclosure; the catalog's web.react API is derived
 * from this interface (Decision 0031). The children fill the panel.
 */
export interface DisclosureOwnProps {
    /** The content of the trigger button, which names the section. */
    title: ReactNode;
    /** Whether the Disclosure is open, when the caller controls it. Inside a DisclosureGroup the group owns expansion and this is ignored. */
    expanded?: boolean;
    /** Whether the Disclosure starts open, when it controls itself. */
    defaultExpanded?: boolean;
    /** Disables the Disclosure: it can be neither opened nor closed. */
    disabled?: boolean;
    /** Identifies the Disclosure. A DisclosureGroup's expanded ids refer to it. */
    id?: string;
    /** Reports the Disclosure opening or closing. */
    onExpandedChange?: (expanded: boolean) => void;
}
export interface DisclosureProps extends DisclosureOwnProps, Omit<HTMLAttributes<HTMLDivElement>, keyof DisclosureOwnProps | 'children' | 'className'> {
    children?: ReactNode;
    className?: string;
}
/** A section of optional content that a trigger button opens and closes. */
export declare const Disclosure: ForwardRefExoticComponent<DisclosureProps & RefAttributes<HTMLDivElement>>;
/**
 * The props Mux UI defines for Group; the catalog's web.react API is derived from this
 * interface (Decision 0031). The accessible name is the native aria-label or
 * aria-labelledby.
 */
export interface GroupOwnProps {
    /** Marks the group disabled. It does not disable the controls inside it. */
    disabled?: boolean;
    /** Marks the group invalid. It does not mark the controls inside it. */
    invalid?: boolean;
    /** Marks the group read-only with a data attribute on its root. It does not lock the controls inside it. */
    readOnly?: boolean;
    /** The role of the group's root. Use presentation when the Group only lays controls out and needs no name. */
    role?: 'group' | 'region' | 'presentation';
}
export interface GroupProps extends GroupOwnProps, Omit<HTMLAttributes<HTMLDivElement>, keyof GroupOwnProps | 'children' | 'className'> {
    children?: ReactNode;
    className?: string;
}
/** Related controls under one named boundary. */
export declare const Group: ForwardRefExoticComponent<GroupProps & RefAttributes<HTMLDivElement>>;
/** What a Link's `onActivate` reports for one activation. */
export interface LinkActivationEvent {
    readonly type: 'activate';
    readonly pointerType: ButtonPointerType;
    readonly target: HTMLAnchorElement;
}
/**
 * The props Mux UI defines for Link; the catalog's web.react API is derived from this
 * interface (Decision 0031). The children are the link text.
 */
export interface LinkOwnProps {
    /** Where the Link leads. A Link without a non-empty href is disabled. */
    href?: string;
    /** Disables the Link. Left unset, a Link inside a disabled GridList item is disabled too. */
    disabled?: boolean;
    /** Marks the Link as the current page. */
    current?: boolean;
    /** Where to open the destination, as the native target attribute. */
    target?: string;
    /** How the destination relates to this page, as the native rel attribute. */
    rel?: string;
    /** Reports an activation of the Link, in addition to following its href. */
    onActivate?: (event: LinkActivationEvent) => void;
}
export interface LinkProps extends LinkOwnProps, Omit<HTMLAttributes<HTMLElement>, keyof LinkOwnProps | 'children' | 'className'>, Pick<AnchorHTMLAttributes<HTMLAnchorElement>, 'hrefLang' | 'ping' | 'referrerPolicy' | 'type'> {
    children?: ReactNode;
    className?: string;
    /** The native download attribute: true downloads the destination, a string also names the saved file. React types it any. */
    download?: boolean | string;
}
/** A link to another location. */
export declare const Link: ForwardRefExoticComponent<LinkProps & RefAttributes<HTMLElement>>;
/**
 * The props Mux UI defines for Meter; the catalog's web.react API is derived from this
 * interface (Decision 0031). The accessible name is the label, or the native aria-label
 * or aria-labelledby.
 */
export interface MeterOwnProps {
    /** The reading, clamped to the range. */
    value?: number;
    /** The bottom of the range. */
    minValue?: number;
    /** The top of the range. */
    maxValue?: number;
    /** The visible name of what is measured. Meter renders it unless aria-label or aria-labelledby names the Meter. */
    label: ReactNode;
    /** How the value text is formatted. Omitted, it formats the position in the range as a percentage. */
    formatOptions?: Intl.NumberFormatOptions;
}
export interface MeterProps extends MeterOwnProps, Omit<HTMLAttributes<HTMLDivElement>, keyof MeterOwnProps | 'children' | 'className'> {
    className?: string;
}
/** A reading within a known range. */
export declare const Meter: ForwardRefExoticComponent<MeterProps & RefAttributes<HTMLDivElement>>;
/**
 * The props Mux UI defines for ProgressBar; the catalog's web.react API is derived from
 * this interface (Decision 0031).
 */
export interface ProgressBarOwnProps {
    /** How far the task has got, within the range. Omitted, the bar is indeterminate and shows the text Loading. */
    value?: number;
    /** The bottom of the range. */
    minValue?: number;
    /** The top of the range. */
    maxValue?: number;
    /** The visible name of the task. */
    label: ReactNode;
}
export interface ProgressBarProps extends ProgressBarOwnProps, Omit<HTMLAttributes<HTMLDivElement>, keyof ProgressBarOwnProps | 'children' | 'className'> {
    className?: string;
}
/** How far a task has got. */
export declare const ProgressBar: ForwardRefExoticComponent<ProgressBarProps & RefAttributes<HTMLDivElement>>;
/**
 * The props Mux UI defines for Separator; the catalog's web.react API is derived from
 * this interface (Decision 0031).
 */
export interface SeparatorOwnProps {
    /** Whether the line runs horizontally or vertically. */
    orientation?: 'horizontal' | 'vertical';
}
export interface SeparatorProps extends SeparatorOwnProps, Omit<HTMLAttributes<HTMLElement>, keyof SeparatorOwnProps | 'children' | 'className'> {
    className?: string;
}
/** A line that separates content. */
export declare const Separator: ForwardRefExoticComponent<SeparatorProps & RefAttributes<HTMLElement>>;
/** What a ToggleButton's `onActivate` reports for one activation. */
export interface ToggleButtonActivationEvent {
    readonly type: 'activate';
    readonly pointerType: ButtonPointerType;
    readonly target: HTMLButtonElement;
}
/**
 * The props Mux UI defines for ToggleButton; the catalog's web.react API is derived
 * from this interface (Decision 0031). The children are the label.
 */
export interface ToggleButtonOwnProps {
    /** Whether the ToggleButton is on, when the caller controls it. */
    selected?: boolean;
    /** Whether the ToggleButton starts on, when it controls itself. */
    defaultSelected?: boolean;
    /** Disables the ToggleButton: it can be neither focused nor toggled. */
    disabled?: boolean;
    /** The control size. Without one, a ToggleButton in a ToggleButtonGroup takes the group's size, and any other takes md. */
    size?: 'sm' | 'md' | 'lg';
    /** Reports the new selected state. */
    onChange?: (selected: boolean) => void;
    /** Reports an activation of the ToggleButton. */
    onActivate?: (event: ToggleButtonActivationEvent) => void;
}
export interface ToggleButtonProps extends ToggleButtonOwnProps, Omit<ButtonHTMLAttributes<HTMLButtonElement>, keyof ToggleButtonOwnProps | 'children' | 'className' | 'onClick'> {
    children?: ReactNode;
    className?: string;
}
/** A button that turns a persistent mode or option on and off. */
export declare const ToggleButton: ForwardRefExoticComponent<ToggleButtonProps & RefAttributes<HTMLButtonElement>>;

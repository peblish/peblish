// @generated-from: packages/react/src/color-area.ts
// @generated-content-sha256: sha256:1ec47e06d495870280ab20536baa644ed6e5fbeadfb2087e4367dae16df9e300
import React from 'react';
import { ColorAreaContext, ColorPickerStateContext } from 'react-aria-components';
import { AriaColorArea, AriaColorThumb } from './substrate.js';
import { classNames, accessibleName } from './control-utils.js';
import { readOnlyKeyGuard, useReadOnlyTargets } from './read-only-guard.js';
import { colorValue, ColorPickerContext, useRememberedEdit } from './color-context.js';
// Colour controls forward no untyped props; upstream props such as onChangeEnd,
// xChannel, or colorSpace would bypass the Mux UI guards and string values.
// The area always edits saturation (x) and brightness (y) in HSB and converts each edit back to the
// colour space of its value, or of the enclosing ColorPicker, so it emits the same CSS string
// as ColorSlider: rgba() for hex and rgb values, hsla() for hsl and hsb values.
export const ColorArea = React.forwardRef(function ColorArea({ label, value, defaultValue, onChange, disabled = false, readOnly = false, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby }, ref) {
    accessibleName({ label, ariaLabel, ariaLabelledby }, 'ColorArea');
    const pickerState = React.useContext(ColorPickerContext);
    const pickerColorState = React.useContext(ColorPickerStateContext);
    // Conditionals rather than `disabled || ...`: extraction reads `||` on an owned prop as replacing its default.
    const effectiveDisabled = disabled ? disabled : pickerState.disabled;
    const effectiveReadOnly = readOnly ? readOnly : pickerState.readOnly;
    const valueColor = colorValue(value, 'ColorArea');
    const defaultColor = colorValue(defaultValue, 'ColorArea');
    // A value or the picker's colour drives the area; otherwise React Aria keeps the HSB colour itself.
    // A controlled area remembers its edits in HSB, which keeps the hue and saturation that hex, rgb, and hsl
    // lose at black and grays; a picker remembers the edit for the areas inside it.
    const [valueShown, rememberEdit] = useRememberedEdit(valueColor);
    const driven = valueShown ?? pickerColorState?.color;
    const space = valueColor?.getColorSpace() ?? pickerState.space ?? defaultColor?.getColorSpace() ?? 'rgb';
    const labelId = React.useId();
    const labelledby = ariaLabelledby ?? (label !== undefined ? labelId : undefined);
    const assignAreaRef = useReadOnlyTargets(ref, effectiveReadOnly, '[role="slider"], input[type="range"]');
    const preventReadOnlyInteraction = (event) => {
        if (effectiveReadOnly) {
            event.preventDefault();
            event.stopPropagation();
        }
    };
    return React.createElement('div', { className: 'muxui-color-area__field', ...{ 'data-muxui-state-disabled': effectiveDisabled || undefined, 'data-muxui-state-read-only': effectiveReadOnly || undefined }, 'aria-disabled': effectiveDisabled || undefined, onTouchStartCapture: preventReadOnlyInteraction, onClickCapture: preventReadOnlyInteraction, onChangeCapture: preventReadOnlyInteraction }, label !== undefined ? React.createElement('span', { id: labelId, className: 'muxui-field-label' }, label) : null, 
    // The area writes its edit to the picker itself, so it clears the context.
    React.createElement(ColorAreaContext.Provider, { value: null }, React.createElement(AriaColorArea, {
        ref: assignAreaRef,
        value: driven,
        defaultValue: driven ? undefined : defaultColor,
        colorSpace: 'hsb',
        xChannel: 'saturation',
        yChannel: 'brightness',
        onChange: (next) => {
            if (effectiveDisabled || effectiveReadOnly)
                return;
            rememberEdit(next);
            pickerColorState?.setColor(next);
            onChange?.(next.toFormat(space).toString());
        },
        isDisabled: effectiveDisabled,
        'aria-label': ariaLabel,
        'aria-labelledby': labelledby,
        // React Aria's props do not name the data-* hooks the styles read or every capture handler, and TypeScript accepts such a key in a call only from a spread.
        ...{
            'data-muxui-state-read-only': effectiveReadOnly || undefined,
            'data-muxui-color-paint': 'area',
            onPointerDownCapture: preventReadOnlyInteraction,
            onMouseDownCapture: preventReadOnlyInteraction,
            onKeyDownCapture: readOnlyKeyGuard(effectiveReadOnly),
            onTouchStartCapture: preventReadOnlyInteraction,
            onClickCapture: preventReadOnlyInteraction,
            onChangeCapture: preventReadOnlyInteraction,
        },
        className: classNames('muxui-color-area', className),
    }, React.createElement(AriaColorThumb, {
        className: 'muxui-color-area__thumb',
        ...{
            'data-muxui-color-paint': 'sample',
            'data-muxui-state-read-only': effectiveReadOnly || undefined,
        },
    }))));
});
ColorArea.displayName = 'ColorArea';

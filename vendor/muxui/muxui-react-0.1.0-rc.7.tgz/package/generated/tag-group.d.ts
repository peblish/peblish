// @generated-from: packages/react/src/tag-group.ts
// @generated-content-sha256: sha256:2a5cb2f316448c625668625ba286c676cb7ff05d36575fb55fa2348830c8998f
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUICollectionItem } from './collection-items.js';
import type { MuxUIAccessibleName } from './fields.js';
/** A TagGroup colour: neutral, the theme's brand, a status, or a fixed hue family. */
export type TagGroupColor = 'neutral' | 'brand' | 'success' | 'warning' | 'error' | 'red' | 'orange' | 'amber' | 'yellow' | 'lime' | 'green' | 'emerald' | 'teal' | 'bluegreen' | 'cyan' | 'sky' | 'indigo' | 'violet' | 'purple' | 'fuchsia' | 'pink' | 'rose';
export type TagGroupVariant = 'soft' | 'outline' | 'dot' | 'strong';
export type TagGroupItem = MuxUICollectionItem & {
    /** Overrides the group's color for this tag. */
    color?: TagGroupColor;
};
/** The props Mux UI defines for TagGroup. The group is named by label, aria-label, or aria-labelledby. */
export type TagGroupOwnProps = {
    /** The visible label, which also names the group. Without one, the group needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** The tags as data: strings, or items with an `id`, a `label`, a `textValue`, `disabled`, and a `color` that overrides the group's. */
    items?: (TagGroupItem | string)[];
    /** The treatment of every tag: soft, outline, dot, or strong. */
    variant?: TagGroupVariant;
    /** The default color of every tag; an item's own color wins. */
    color?: TagGroupColor;
    /** Whether tags can be selected: `single` or `multiple` makes them selectable. */
    selectionMode?: 'none' | 'single' | 'multiple';
    /** The selected item ids, when the caller controls the selection. Without it the group keeps the selection and drops the ids of removed items without calling onSelectionChange, so a caller controlling the selection removes those ids itself. */
    selectedKeys?: Set<string>;
    /** The item ids selected at first, when the group keeps its own selection. */
    defaultSelectedKeys?: Set<string>;
    /** Called with a new Set of the selected item ids when the selection changes; selecting everything passes the ids of the enabled items. It is not called while the group is disabled. */
    onSelectionChange?: (keys: Set<string>) => void;
    /** Disables every tag and its remove button, and stops the selection, removal, and action callbacks. A tag's own `disabled` disables just that tag. */
    disabled?: boolean;
    /** Called with the removed item records, not ids. Each tag shows a remove button only when this is supplied, and Backspace or Delete on a focused tag also removes it. A disabled tag cannot be removed, and a disabled group removes nothing. */
    onRemove?: (items: TagGroupItem[]) => void;
    /** Called with the item record when the user activates a tag. It is not called for a disabled tag or while the group is disabled. */
    onAction?: (item?: TagGroupItem) => void;
};
export type TagGroupProps = Omit<TagGroupOwnProps, 'label'> & {
    className?: string;
} & MuxUIAccessibleName;
export declare const TagGroup: ForwardRefExoticComponent<TagGroupProps & RefAttributes<HTMLDivElement>>;

// @generated-from: packages/react/src/supplemental/activity.ts
// @generated-content-sha256: sha256:57037b0a973055cd78798e4fb35794c7e0387a5508325cc5d43907b15ddeb871
import React from 'react';
import ChevronDown from 'lucide-react/dist/esm/icons/chevron-down.mjs';
import Clock from 'lucide-react/dist/esm/icons/clock.mjs';
import CircleDot from 'lucide-react/dist/esm/icons/circle-dot.mjs';
import CircleCheck from 'lucide-react/dist/esm/icons/circle-check.mjs';
import CircleAlert from 'lucide-react/dist/esm/icons/circle-alert.mjs';
import CircleMinus from 'lucide-react/dist/esm/icons/circle-minus.mjs';
import { useCandidateMotion } from './candidate-motion.mjs';
import { MotionHeight, useDisclosureIconMotion } from './motion-components.mjs';
const e = React.createElement;
const statuses = ['queued', 'running', 'completed', 'failed', 'cancelled'];
const labels = { queued: 'Queued', running: 'Running', completed: 'Completed', failed: 'Failed', cancelled: 'Cancelled' };
const marks = { queued: Clock, running: CircleDot, completed: CircleCheck, failed: CircleAlert, cancelled: CircleMinus };
function statusOf(items) {
    return ['failed', 'running', 'queued', 'cancelled'].find((status) => items.some((item) => item.status === status)) ?? (items.length ? 'completed' : undefined);
}
function actionsOf(actions, key) {
    return actions != null && actions.length > 0 && e('div', { className: 'muxui-activity__actions', key, role: 'group', 'aria-label': 'Activity actions' }, actions.map((action) => e('button', { key: action.id, 'data-muxui-size': 'sm', 'data-muxui-variant': 'neutral', className: 'muxui-button', type: 'button', disabled: action.disabled, 'data-muxui-state-disabled': action.disabled || undefined, onClick: action.onAction }, action.label)));
}
// Retain native details during exit; the requested state owns accessibility. defaultExpanded seeds both states at mount only.
function ActivityDetails({ item, summary }) {
    const [detailsOpen, setDetailsOpen] = React.useState(item.defaultExpanded ?? false);
    const [physicalOpen, setPhysicalOpen] = React.useState(detailsOpen);
    const chevron = React.useRef(null);
    const summaryRef = React.useRef(null);
    const detailsHost = React.useRef(null);
    const detailsId = React.useId();
    useDisclosureIconMotion(chevron, detailsOpen, true);
    function toggle(event) {
        if (event.defaultPrevented)
            return;
        // The target may be a node without closest, such as text.
        const interactive = event.target.closest?.('a[href], button, input, select, textarea, label, summary, [contenteditable]:not([contenteditable="false"]), [role="button"], [role="link"], [tabindex]');
        if (interactive && interactive !== event.currentTarget && event.currentTarget.contains(interactive))
            return;
        event.preventDefault();
        const next = !detailsOpen;
        if (next)
            setPhysicalOpen(true);
        setDetailsOpen(next);
    }
    function syncNative(event) {
        const nativeOpen = event.currentTarget.open;
        if (nativeOpen === physicalOpen)
            return;
        if (nativeOpen)
            setPhysicalOpen(true);
        else
            event.currentTarget.open = true;
        setDetailsOpen(nativeOpen);
    }
    return e('details', { className: 'muxui-activity__item-details', open: physicalOpen, onToggle: syncNative }, e('summary', { ref: summaryRef, className: 'muxui-activity__item-summary', onClick: toggle, 'aria-expanded': detailsOpen, 'aria-controls': detailsId }, ...summary, e(ChevronDown, { ref: chevron, className: 'muxui-activity__item-chevron', size: 16, 'aria-hidden': true, focusable: 'false' })), e('div', { ref: detailsHost, className: 'muxui-activity__details-host', hidden: !detailsOpen ? 'until-found' : undefined }, e(MotionHeight, { isOpen: detailsOpen, triggerRef: summaryRef, hostRef: detailsHost, id: detailsId, className: 'muxui-activity__motion-panel', contentClassName: 'muxui-activity__motion-content', grouped: true, onCloseComplete: () => setPhysicalOpen(false) }, e('div', { className: 'muxui-activity__details' }, item.context && e('div', { className: 'muxui-activity__context' }, item.context), item.details && e('div', { className: 'muxui-activity__details-content' }, item.details), actionsOf(item.actions, 'item')))));
}
// Named for the item it renders; the binding differs only from the exported ActivityItem type.
const ActivityItemRow = function ActivityItem({ item, visible }) {
    const mark = React.useRef(null);
    const statusLabel = React.useRef(null);
    useCandidateMotion(mark, item.status, { active: visible });
    useCandidateMotion(statusLabel, item.status, { active: visible });
    const summary = [e('span', { key: 'mark', ref: mark, className: 'muxui-activity__mark', 'aria-hidden': true }, e(marks[item.status], { className: 'muxui-activity__mark-icon', size: 20, 'aria-hidden': true, focusable: 'false' })), e('span', { key: 'label', className: 'muxui-activity__item-label' }, item.label),
        e('span', { key: 'metadata', className: 'muxui-activity__item-metadata' }, item.meta && e('span', { className: 'muxui-activity__meta' }, item.meta), e('span', { className: 'muxui-activity__status-time' }, e('span', { ref: statusLabel, className: 'muxui-activity__status' }, labels[item.status]), item.time && e('span', { className: 'muxui-activity__time' }, ' in ', item.time)))];
    const hasDetails = item.details || item.context || item.actions?.length;
    return e('li', { className: 'muxui-activity__item', 'data-muxui-status': item.status }, hasDetails
        ? e(ActivityDetails, { item, summary })
        : e('div', { className: 'muxui-activity__row' }, ...summary));
};
/** Caller-supplied status, metadata and time; this component never starts or simulates tasks. */
export const Activity = React.forwardRef(function Activity({ label, items, status, variant: _variant, expanded, defaultExpanded = true, onExpandedChange, 
// Not Activity props: an untyped caller's variant, children, and HTML never reach the root.
actions, className, children: _children, dangerouslySetInnerHTML: _html, ...props }, ref) {
    // Without a status the group follows its items. A conditional, not ??: extraction reads a fallback
    // on an owned prop as an executed default, and this one is computed from the items, not static.
    const groupStatus = status === undefined ? statusOf(items) : status;
    if (groupStatus !== undefined && !statuses.includes(groupStatus) || items.some((item) => !statuses.includes(item.status)))
        throw new TypeError('Activity status must be queued, running, completed, failed or cancelled.');
    if (new Set(items.map((item) => item.id)).size !== items.length || items.some((item) => !item.id))
        throw new TypeError('Activity items require unique nonempty IDs.');
    const [localExpanded, setLocalExpanded] = React.useState(defaultExpanded);
    // Controlled while expanded is set, with the same conditional in place of ??.
    const open = expanded == null ? localExpanded : expanded;
    const id = React.useId();
    const chevron = React.useRef(null);
    const triggerRef = React.useRef(null);
    const itemsHost = React.useRef(null);
    const statusLabel = React.useRef(null);
    useDisclosureIconMotion(chevron, open, true);
    useCandidateMotion(statusLabel, groupStatus);
    function toggle() { const next = !open; if (expanded === undefined)
        setLocalExpanded(next); onExpandedChange?.(next); }
    return e('div', { ...props, ref, className: ['muxui-activity', className].filter(Boolean).join(' '), 'data-muxui-status': groupStatus }, e('div', { className: 'muxui-activity__header' }, e('button', { ref: triggerRef, 'data-muxui-size': 'sm', 'data-muxui-variant': 'ghost', type: 'button', className: 'muxui-button muxui-activity__trigger', 'aria-expanded': open, 'aria-controls': `${id}-items`, onClick: toggle }, e(ChevronDown, { ref: chevron, className: 'muxui-activity__chevron', size: 16, 'aria-hidden': true, focusable: 'false' }), e('span', { className: 'muxui-activity__label' }, label), groupStatus && e('span', { ref: statusLabel, className: 'muxui-activity__status' }, labels[groupStatus]), e('span', { className: 'muxui-activity__count' }, `${items.length} ${items.length === 1 ? 'item' : 'items'}`)), actionsOf(actions, 'aggregate')), e('div', { ref: itemsHost, className: 'muxui-activity__items-host', hidden: !open ? 'until-found' : undefined }, e(MotionHeight, { isOpen: open, triggerRef, hostRef: itemsHost, className: 'muxui-activity__motion-panel', contentClassName: 'muxui-activity__motion-content', grouped: true }, e('ul', { className: 'muxui-activity__items', id: `${id}-items` }, items.length ? items.map((item) => e(ActivityItemRow, { key: item.id, item, visible: open })) : e('li', { className: 'muxui-activity__empty' }, 'No activity.')))), e('span', { className: 'muxui-activity__sr-only', role: 'status', 'aria-live': 'polite', 'aria-atomic': true }, `${label}: ${groupStatus ? labels[groupStatus] : 'No activity'}.`));
});
Activity.displayName = 'Activity';

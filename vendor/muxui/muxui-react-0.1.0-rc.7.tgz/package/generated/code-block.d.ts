// @generated-from: packages/react/src/supplemental/code-block.ts
// @generated-content-sha256: sha256:4389c9b54e99479fc7bc09383cc11bc943799b6755f5f82ef480890a8000a8cd
import type { ForwardRefExoticComponent, HTMLAttributes, RefAttributes } from 'react';
/**
 * The props Mux UI defines for CodeBlock; the catalog's web.react API is derived from this
 * type (Decision 0031). It is a type literal, not an interface, so the public props type
 * stays assignable to Record<string, unknown>, as it was before the move. The input props
 * are exclusive by mode, which CodeBlockProps enforces with its two arms; here each reads
 * as optional.
 */
type CodeBlockOwnProps = {
    /** What the block shows. In code mode it shows source. In diff mode it shows a line diff from before to after. A mode takes only its own inputs: code mode takes source and not before or after, and diff mode takes before and after and not source. */
    mode?: 'code' | 'diff';
    /** The code to show, in code mode. It is required there and not allowed with before or after. At most 1,000,000 UTF-16 units and 10,000 lines. */
    source?: string;
    /** The original code, in diff mode. It is required there with after, and not allowed with source. At most 1,000,000 UTF-16 units and 10,000 lines. */
    before?: string;
    /** The updated code, in diff mode. It is required there with before, and not allowed with source. The copy action copies it. At most 1,000,000 UTF-16 units and 10,000 lines. */
    after?: string;
    /** A Shiki language name or alias. It colours the code once the highlighter loads, and labels the header when filename is absent. A missing or unsupported language stays plain text. */
    language?: string;
    /** Labels the listing in the header. */
    filename?: string;
    /** Whether line numbers show. A diff shows original and updated positions. */
    lineNumbers?: boolean;
    /** Whether the copy action shows. It copies the exact source, or in diff mode the exact after. */
    copyable?: boolean;
    /** Whether long lines wrap. When false, they scroll horizontally. */
    wrap?: boolean;
};
type CodeBlockArms = {
    mode?: 'code';
    source: string;
    before?: never;
    after?: never;
} | {
    mode: 'diff';
    before: string;
    after: string;
    source?: never;
};
export type CodeBlockProps = Omit<HTMLAttributes<HTMLDivElement>, 'children' | 'dangerouslySetInnerHTML'> & Omit<CodeBlockOwnProps, 'mode' | 'source' | 'before' | 'after'> & CodeBlockArms;
/** Each input accepts at most 1,000,000 UTF-16 units and 10,000 lines. */
export declare const CodeBlock: ForwardRefExoticComponent<CodeBlockProps & RefAttributes<HTMLDivElement>>;
export {};

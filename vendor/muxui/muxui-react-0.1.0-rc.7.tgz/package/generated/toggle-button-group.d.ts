// @generated-from: packages/react/src/toggle-button-group.ts
// @generated-content-sha256: sha256:ee84882b357b18729542b5c6955c5dfe11b35ca5aad6be6620a537b65b3b9f8f
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUIAriaAccessibleName } from './fields.js';
/**
 * The props Mux UI defines for ToggleButtonGroup. The ToggleButtons it groups are its children, and
 * it is named by aria-label or aria-labelledby.
 */
export type ToggleButtonGroupOwnProps = {
    /** The ids of the selected ToggleButtons, when the caller controls the selection. A single-selection group holds at most one; the all value is not accepted. */
    selectedIds?: readonly string[];
    /** The ids of the ToggleButtons that start selected, when the group controls itself. A single-selection group holds at most one; the all value is not accepted. */
    defaultSelectedIds?: readonly string[];
    /** Whether the group selects one ToggleButton or several. Any other value throws a TypeError. */
    selectionMode?: 'single' | 'multiple';
    /** Disables the group and every ToggleButton in it. */
    disabled?: boolean;
    /** The direction the buttons are laid out and the arrow keys move focus along. */
    orientation?: 'horizontal' | 'vertical';
    /** Keeps the selection from being cleared: the selected button stays selected when pressed again. */
    disallowEmptySelection?: boolean;
    /** The control size. The ToggleButtons take it from the group. */
    size?: 'sm' | 'md' | 'lg';
    /** Called with the ids of the selected ToggleButtons each time the selection changes. A disabled group does not call it. */
    onSelectionChange?: (ids: readonly string[]) => void;
};
export type ToggleButtonGroupProps = ToggleButtonGroupOwnProps & {
    children?: ReactNode;
    className?: string;
} & MuxUIAriaAccessibleName;
export declare const ToggleButtonGroup: ForwardRefExoticComponent<ToggleButtonGroupProps & RefAttributes<HTMLDivElement>>;

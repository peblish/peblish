// @generated-from: packages/react/src/substrate.ts
// @generated-content-sha256: sha256:8e609bb71c20b858c77f0e9f90bb1319db8477b13f9f965f1a1e18524bf50881
export {};

// @generated-from: packages/react/src/overlays.ts
// @generated-content-sha256: sha256:4074a0603644330a56e1c44a797ecfd0e6928248a4668cfa5b39cdd794aa66d9
import type { FC, ForwardRefExoticComponent, ReactElement, ReactNode, RefAttributes, RefObject } from 'react';
import type { ColorMode } from './color-mode.js';
/** What a drop does with what it carries: copies, links, or moves it, or is cancelled. */
export type MuxUIDropOperation = 'copy' | 'link' | 'move' | 'cancel';
/** A dropped file. */
export interface MuxUIFileDropItem {
    readonly kind: 'file';
    readonly type: string;
    readonly name: string;
    readonly getFile: () => Promise<File>;
    readonly getText: () => Promise<string>;
}
/** A dropped directory. */
export interface MuxUIDirectoryDropItem {
    readonly kind: 'directory';
    readonly name: string;
    readonly getEntries: () => AsyncIterable<MuxUIDropItem>;
}
/** Dropped text, in each of the formats it carries. */
export interface MuxUITextDropItem {
    readonly kind: 'text';
    readonly types: ReadonlySet<string>;
    readonly getText: (type: string) => Promise<string>;
}
/** One item a drop carries. */
export type MuxUIDropItem = MuxUIFileDropItem | MuxUIDirectoryDropItem | MuxUITextDropItem;
/** What a drop reports. */
export interface MuxUIDropEvent {
    readonly type: 'drop';
    readonly x: number;
    readonly y: number;
    readonly dropOperation: MuxUIDropOperation;
    readonly items: MuxUIDropItem[];
}
/** What an activation of the drop target reports. */
export interface MuxUIDropActivateEvent {
    readonly type: 'activate';
    readonly x: number;
    readonly y: number;
}
/**
 * The props Mux UI defines for DropZone; the catalog's web.react API is derived from
 * this interface (Decision 0031). The children are the area's content, and the accessible
 * name is the native aria-label or aria-labelledby.
 */
export interface DropZoneOwnProps {
    /** Disables the DropZone: it accepts no drop and reports no activation. */
    disabled?: boolean;
    /** Reports the items a drop, a paste, or a keyboard selection supplies. The items are file, directory, and text items rather than a File array, and they are read asynchronously. */
    onDrop?: (event: MuxUIDropEvent) => void;
    /** Reports an activation of the DropZone's own hidden button. A click on a control inside it, such as a FileTrigger, reports none. */
    onActivate?: (event: MuxUIDropActivateEvent) => void;
}
export interface DropZoneProps extends DropZoneOwnProps {
    children?: ReactNode;
    className?: string;
    'aria-label'?: string;
    'aria-labelledby'?: string;
}
/**
 * MuxUI owns the public callback shape while RAC owns drop, clipboard, hover, and focus semantics.
 */
export declare const DropZone: ForwardRefExoticComponent<DropZoneProps & RefAttributes<HTMLDivElement>>;
/**
 * The props Mux UI defines for FileTrigger; the catalog's web.react API is derived from
 * this interface (Decision 0031). The children are the trigger: text, which becomes a Button,
 * or an element, which keeps its own styling.
 */
export interface FileTriggerOwnProps {
    /** The MIME types or extensions the picker offers. It sets the native accept attribute and narrows the picker without validating the choice. */
    acceptedFileTypes?: readonly string[];
    /** Lets the picker select more than one file. */
    allowsMultiple?: boolean;
    /** Lets the picker select a directory instead of files, through the native webkitdirectory attribute. */
    acceptDirectory?: boolean;
    /** Picks the camera a capture uses, the front one for user or the rear one for environment, through the native capture attribute. */
    defaultCamera?: 'user' | 'environment';
    /** Disables the trigger: the picker does not open, and onSelect is not called. */
    disabled?: boolean;
    /** Reports the chosen files as an array of File objects. */
    onSelect?: (files: File[]) => void;
}
export interface FileTriggerProps extends FileTriggerOwnProps {
    children?: ReactNode;
    className?: string;
}
/** RAC resets the native input before each press, preserving same-file selection behavior. */
export declare const FileTrigger: ForwardRefExoticComponent<FileTriggerProps & RefAttributes<HTMLInputElement>>;
/** How a floating overlay is placed beside its trigger. */
export type MuxUIPlacement = 'top' | 'bottom' | 'start' | 'end' | 'top-start' | 'top-end' | 'bottom-start' | 'bottom-end' | 'start-top' | 'start-bottom' | 'end-top' | 'end-bottom';
/** An overlay's accessible name: an aria-label, or the id of the element that labels it, but not both. */
export type OverlayAccessibleName = {
    'aria-label': string;
    'aria-labelledby'?: never;
} | {
    'aria-label'?: never;
    'aria-labelledby': string;
};
/**
 * The props Mux UI defines for Dialog; the catalog's web.react API is derived from this
 * interface (Decision 0031). The children fill the content, and the accessible name is
 * the title, or else the native aria-label or aria-labelledby.
 */
export interface DialogOwnProps {
    /** The heading, which also names the Dialog. Without one, the Dialog needs an aria-label or aria-labelledby, and a blank title does not count. */
    title?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text under the title, which also describes the Dialog. */
    description?: ReactNode;
    /** The buttons under the content. */
    actions?: ReactNode;
    /** Whether the Dialog is open, when the caller controls it. */
    open?: boolean;
    /** Whether the Dialog starts open, when it controls itself. */
    defaultOpen?: boolean;
    /** Whether Escape, an outside press, the trigger, and the built-in close button close the Dialog. When false, the Dialog renders no close button of its own, and only a button in the close slot closes it. */
    dismissable?: boolean;
    /** The element that opens the Dialog. Without one, only open or defaultOpen opens it. */
    trigger?: ReactElement;
    /** A class added to the backdrop beside Mux UI's own. */
    backdropClassName?: string;
    /** A class added to the dialog panel beside Mux UI's own. */
    panelClassName?: string;
    /** A class added to the title beside Mux UI's own. */
    titleClassName?: string;
    /** A class added to the description beside Mux UI's own. */
    descriptionClassName?: string;
    /** A class added to the content beside Mux UI's own. */
    contentClassName?: string;
    /** A class added to the actions beside Mux UI's own. */
    actionsClassName?: string;
    /** A class added to the built-in close button beside Mux UI's own. */
    closeClassName?: string;
    /** Reports the Dialog opening or closing. A Dialog that is not dismissable reports no close from Escape, an outside press, or the trigger. */
    onOpenChange?: (open: boolean) => void;
}
type DialogArms = {
    title: Exclude<ReactNode, null | undefined | boolean>;
    'aria-label'?: string;
    'aria-labelledby'?: string;
} | ({
    title?: never;
} & OverlayAccessibleName);
export type DialogProps = Omit<DialogOwnProps, 'title'> & {
    'aria-describedby'?: string;
    children?: ReactNode;
    className?: string;
} & DialogArms;
/** RAC Modal/ModalOverlay provide topmost overlay arbitration, inertness, focus scope, and portal lifecycle. */
export declare const Dialog: ForwardRefExoticComponent<DialogProps & RefAttributes<HTMLElement>>;
/**
 * The props Mux UI defines for Popover; the catalog's web.react API is derived from this
 * type (Decision 0031). The children fill the popover, and the accessible name is
 * the native aria-label or aria-labelledby.
 * It is a type literal, not an interface, so the public props type stays assignable to
 * Record<string, unknown>, as it was before the move.
 */
export type PopoverOwnProps = {
    /** The focusable element that opens the Popover. Pressing it toggles the Popover. */
    trigger: ReactElement;
    /** Whether the Popover is open, when the caller controls it. */
    open?: boolean;
    /** Whether the Popover starts open, when it controls itself. */
    defaultOpen?: boolean;
    /** Whether Escape, an outside press, and the trigger close the Popover. When false, only a button in the close slot closes it, in modal and non-modal mode alike. */
    dismissable?: boolean;
    /** Where the Popover opens against its trigger or anchorRef. start and end follow the locale direction. */
    placement?: MuxUIPlacement;
    /** The distance in pixels between the Popover and its trigger, along the placement's side. */
    offset?: number;
    /** The shift in pixels along the side the Popover is placed against. */
    crossOffset?: number;
    /** Whether the Popover moves to the opposite side when the placed side has no room. */
    shouldFlip?: boolean;
    /** The least distance in pixels between the Popover and the edge of the viewport. Must not be negative. */
    containerPadding?: number;
    /** Whether the Popover contains focus until it closes. When false, it is non-blocking: it has no focus containment, outside-content exclusion, or scroll locking. */
    modal?: boolean;
    /** Makes the open Popover a scope of this color scheme, whatever the page's. Its surface is that scheme's raised popup surface, not the strong surface an unscoped Popover has, and its text and any Mux UI component inside follow the scheme. Unset leaves the Popover as the page styles it. A scoped Popover also carries the data-muxui-theme and data-muxui-contrast it reads from its trigger's nearest scope, or from the document root, when it opens. While it is open it follows a change to either on the trigger or its ancestors, and it picks up a replaced trigger node on its next render or the next time it opens. */
    colorScheme?: ColorMode;
    /** Reports the Popover opening or closing. */
    onOpenChange?: (open: boolean) => void;
};
export type PopoverProps = PopoverOwnProps & {
    children: ReactNode;
    className?: string;
    anchorRef?: RefObject<Element | null>;
} & OverlayAccessibleName;
/** RAC Popover owns positioning and dismissal; FocusScope controls optional focus containment. */
export declare const Popover: ForwardRefExoticComponent<PopoverProps & RefAttributes<HTMLDivElement>>;
/**
 * The props Mux UI defines for PreviewTrigger; the catalog's web.react API is derived from
 * this type (Decision 0031). The children fill the preview, and the accessible name is
 * the native aria-label or aria-labelledby.
 * It is a type literal, not an interface, so the public props type stays assignable to
 * Record<string, unknown>, as it was before the move.
 */
export type PreviewTriggerOwnProps = {
    /** The focusable element that opens the preview. Disabling the preview leaves it operable. */
    trigger: ReactElement;
    /** How long a hover waits before the preview opens, in milliseconds. */
    delay?: number;
    /** How long the preview stays open after the pointer leaves, in milliseconds. */
    closeDelay?: number;
    /** Whether the preview is open, when the caller controls it. */
    open?: boolean;
    /** Whether the preview starts open, when it controls itself. */
    defaultOpen?: boolean;
    /** Disables the preview: it does not open, and an open one closes. The trigger stays operable. */
    disabled?: boolean;
    /** Where the preview opens against its trigger. start and end follow the locale direction. */
    placement?: MuxUIPlacement;
    /** The distance in pixels between the preview and its trigger, along the placement's side. */
    offset?: number;
    /** The shift in pixels along the side the preview is placed against. */
    crossOffset?: number;
    /** Whether the preview moves to the opposite side when the placed side has no room. */
    shouldFlip?: boolean;
    /** The least distance in pixels between the preview and the edge of the viewport. Must not be negative. */
    containerPadding?: number;
    /** Reports the preview opening or closing. */
    onOpenChange?: (open: boolean) => void;
};
export type PreviewTriggerProps = PreviewTriggerOwnProps & {
    children: ReactNode;
    className?: string;
} & OverlayAccessibleName;
/** RAC PreviewTrigger owns long press, warmup/cooldown timers, focus, Escape, and safe-area positioning. */
export declare const PreviewTrigger: ForwardRefExoticComponent<PreviewTriggerProps & RefAttributes<HTMLDivElement>>;
/**
 * The props Mux UI defines for Tooltip; the catalog's web.react API is derived from this
 * type (Decision 0031). The tooltip describes its trigger and does not name it.
 * It is a type literal, not an interface, so the public props type stays assignable to
 * Record<string, unknown>, as it was before the move.
 */
export type TooltipOwnProps = {
    /** What the tooltip says. It is required, and a blank string does not count. */
    content: Exclude<ReactNode, null | undefined | boolean>;
    /** The focusable element the tooltip describes. */
    trigger: ReactElement;
    /** How long a hover waits before the tooltip opens, in milliseconds. Keyboard focus opens it at once. */
    delay?: number;
    /** How long the tooltip stays open after the pointer leaves, in milliseconds. */
    closeDelay?: number;
    /** Where the tooltip opens against its trigger or anchorRef. start and end follow the locale direction. */
    placement?: MuxUIPlacement;
    /** The distance in pixels between the tooltip and its trigger, along the placement's side. */
    offset?: number;
    /** The shift in pixels along the side the tooltip is placed against. */
    crossOffset?: number;
    /** Whether the tooltip moves to the opposite side when the placed side has no room. */
    shouldFlip?: boolean;
    /** The least distance in pixels between the tooltip and the edge of the viewport. Must not be negative. */
    containerPadding?: number;
    /** Whether the tooltip is open, when the caller controls it. */
    open?: boolean;
    /** Whether the tooltip starts open, when it controls itself. */
    defaultOpen?: boolean;
    /** Disables the tooltip: it does not open, and an open one closes. The trigger stays operable. */
    disabled?: boolean;
    /** Reports the tooltip opening or closing. */
    onOpenChange?: (open: boolean) => void;
};
export type TooltipProps = TooltipOwnProps & {
    className?: string;
    anchorRef?: RefObject<Element | null>;
};
/** RAC TooltipTrigger owns global hover/focus timing and keyboard modality semantics. */
export declare const Tooltip: ForwardRefExoticComponent<TooltipProps & RefAttributes<HTMLDivElement>>;
/** What a notification added through the manager can say and do. */
export interface ToastOptions {
    title?: ReactNode;
    variant?: 'neutral' | 'success' | 'warning' | 'danger';
    duration?: number;
    onDismiss?: () => void;
    className?: string;
}
/** What useToast returns: add a notification, and close one by the key add returned. */
export interface ToastManager {
    add: (message: Exclude<ReactNode, null | undefined | boolean>, options?: ToastOptions) => string;
    remove: (key: string) => void;
}
export interface ToastProviderProps {
    children?: ReactNode;
    maxVisible?: number;
    placement?: 'top-start' | 'top-end' | 'bottom-start' | 'bottom-end';
    className?: string;
}
/** Stable MuxUI facade over RAC's unstable queue/region implementation. */
export declare const ToastProvider: FC<ToastProviderProps>;
export declare function useToast(): ToastManager;
/**
 * The props Mux UI defines for Toast; the catalog's web.react API is derived from this
 * interface (Decision 0031). A Toast renders nothing where it is mounted: it enqueues one
 * notification in the nearest ToastProvider.
 */
export interface ToastOwnProps {
    /** What the notification says, in one short sentence. It is required, and a blank string does not count. */
    message: Exclude<ReactNode, null | undefined | boolean>;
    /** Says what the message is about. Without one, the notification shows Notification. */
    title?: ReactNode;
    /** How the notification looks, by what happened. It does not change how long the notification stays. */
    variant?: 'neutral' | 'success' | 'warning' | 'danger';
    /** How long the notification stays, in milliseconds. 0 keeps it until it is dismissed or removed. Must be finite, not negative, and at most 2147483647. Changing it replaces the notification with a new one. */
    duration?: number;
    /** Reports the notification being dismissed, by a person or a timeout, at most once. An unmount does not call it. */
    onDismiss?: () => void;
}
export interface ToastProps extends ToastOwnProps {
    className?: string;
}
export declare const Toast: FC<ToastProps>;
export {};

// @generated-from: packages/react/src/supplemental/text.ts
// @generated-content-sha256: sha256:28b0c272914063bfe5d7afc060f29419f9dd2732c5a51c5aea42936fb8aef85e
import type { ComponentPropsWithoutRef, ReactElement, RefAttributes } from 'react';
export type TextVariant = 'display' | 'heading' | 'title' | 'label' | 'body' | 'expressive' | 'mono';
export type TextSize = 'xs' | 'sm' | 'md' | 'lg';
export type TextColor = 'default' | 'muted';
export type TextElement = 'p' | 'span' | 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6' | 'div' | 'label';
/** The variant and size a Text takes together: the display roles have no extra-small size. */
export type TextVisualProps = {
    variant?: 'body';
    size?: TextSize;
} | {
    variant: 'display' | 'heading' | 'title';
    size?: Exclude<TextSize, 'xs'>;
} | {
    variant: 'label' | 'expressive' | 'mono';
    size?: TextSize;
};
/**
 * The props Mux UI defines for Text; the catalog's web.react API is derived from this type (Decision 0031).
 * It is generic over the element Text renders, as the public type is, and the catalog records `as` at its
 * constraint. The public type states `variant` and `size` as the arms of TextVisualProps, which together
 * take every value these two take.
 */
type TextOwnProps<T extends TextElement = 'span'> = {
    /** The typographic role: its size and weight. */
    variant?: TextVariant;
    /** The size within the role. The display roles (display, heading, title) have no extra-small size. */
    size?: TextSize;
    /** The text colour: the default, or the muted tone. */
    color?: TextColor;
    /** The element Text renders. */
    as?: T;
    /** Cuts a line that does not fit short with an ellipsis. */
    truncate?: boolean;
};
export type TextProps<T extends TextElement = 'span'> = Omit<ComponentPropsWithoutRef<T>, 'as' | 'className' | 'color' | 'size' | 'variant'> & TextVisualProps & Pick<TextOwnProps<T>, 'as' | 'color' | 'truncate'> & {
    className?: string;
};
export interface TextComponent {
    <T extends TextElement = 'span'>(props: TextProps<T> & RefAttributes<HTMLElementTagNameMap[T]>): ReactElement | null;
}
export declare const Text: TextComponent;
export {};

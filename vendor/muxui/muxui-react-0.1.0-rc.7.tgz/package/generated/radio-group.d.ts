// @generated-from: packages/react/src/radio-group.ts
// @generated-content-sha256: sha256:8b183798a71537ab895ef5fbbb82ab1dd508b88d92e5fd9c70037e58b7f3ade1
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUIAccessibleName } from './fields.js';
/** One radio the group builds from its options. */
export type RadioOption = {
    /** The radio's key, which also stands in for the value when the option has none. */
    id?: string;
    /** What the group's value, change callback, and form field carry when this option is selected. */
    value: string;
    /** What the radio shows beside its indicator. Without one it shows the value. */
    label?: ReactNode;
    /** Disables this radio alone. A disabled group disables them all. */
    disabled?: boolean;
};
/**
 * The props Mux UI defines for RadioGroup. The group is named by label, aria-label, or aria-labelledby,
 * and it takes no description. Its radios come from options, or from RadioField children.
 */
export type RadioGroupOwnProps = {
    /** The visible label, which also names the group. Without one, the group needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Shown once for the whole group, only while the group is invalid, through the invalid prop or failed native, custom, or server validation. It replaces the built-in message and never makes the group invalid by itself. */
    errorMessage?: ReactNode;
    /** The radios the group builds, one per option. A non-empty options cannot be combined with children: passing both throws a TypeError. */
    options?: RadioOption[];
    /** RadioField radios, when the group does not build them from options. They cannot be combined with a non-empty options. */
    children?: ReactNode;
    /** The value of the selected radio, when the caller controls it. */
    value?: string;
    /** The value of the radio that starts selected, when the group controls itself. */
    defaultValue?: string;
    /** Called with the value of the radio each time one is selected. A disabled or read-only group does not call it. */
    onChange?: (value: string) => void;
    /** Disables the group and every radio in it. */
    disabled?: boolean;
    /** Makes the group read-only: its radios stay visible and focusable but cannot be changed. */
    readOnly?: boolean;
    /** Marks the group required, so a form with native validation does not submit while no radio is selected. */
    required?: boolean;
    /** Marks the group invalid and shows its error message. Left false, validation decides, so failed native, custom, or server validation can still make the group invalid. */
    invalid?: boolean;
    /** Whether the radios stack in a column or sit in a row. */
    orientation?: 'vertical' | 'horizontal';
    /** The control size. The radios take it from the group. */
    size?: 'sm' | 'md' | 'lg';
    /** The form field name. A named group submits the selected value under it. */
    name?: string;
};
export type RadioGroupProps = Omit<RadioGroupOwnProps, 'label'> & {
    className?: string;
} & MuxUIAccessibleName;
export declare const RadioGroup: ForwardRefExoticComponent<RadioGroupProps & RefAttributes<HTMLDivElement>>;

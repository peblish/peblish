// @generated-from: packages/react/src/slider.ts
// @generated-content-sha256: sha256:f67bf638caec41de1f1c0f40482670f42d79e31c852622381b18c87625334863
import React from 'react';
import { Label as AriaLabel } from 'react-aria-components';
import { AriaSlider, AriaSliderOutput } from './substrate.js';
import { SliderMotionTrack } from './slider-motion.mjs';
import { classNames, accessibleName } from './control-utils.js';
import { readOnlyKeyGuard, useReadOnlyTargets } from './read-only-guard.js';
export const Slider = /* @__PURE__ */ (() => {
    const component = React.forwardRef(function Slider({ label, value, defaultValue, onChange, onChangeEnd, min = 0, max = 100, step = 1, disabled = false, readOnly = false, orientation = 'horizontal', name, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
        accessibleName({ label, ariaLabel, ariaLabelledby }, 'Slider');
        const readOnlyRef = useReadOnlyTargets(ref, readOnly, '[role="slider"], input[type="range"]');
        const preventReadOnlyInteraction = React.useCallback((event) => {
            if (readOnly) {
                event.preventDefault();
                event.stopPropagation();
            }
        }, [readOnly]);
        const handleChange = React.useCallback((next) => {
            if (!disabled && !readOnly)
                onChange?.(next);
        }, [disabled, onChange, readOnly]);
        const handleChangeEnd = React.useCallback((next) => {
            if (!disabled && !readOnly)
                onChangeEnd?.(next);
        }, [disabled, onChangeEnd, readOnly]);
        const assignSliderRef = React.useCallback((node) => {
            if (node) {
                if (disabled)
                    node.setAttribute('aria-disabled', 'true');
                else
                    node.removeAttribute('aria-disabled');
            }
            readOnlyRef(node);
        }, [disabled, readOnlyRef]);
        return React.createElement(AriaSlider, {
            ...props,
            ref: assignSliderRef,
            value,
            defaultValue,
            onChange: handleChange,
            onChangeEnd: readOnly ? undefined : handleChangeEnd,
            minValue: min,
            maxValue: max,
            step,
            isDisabled: disabled,
            orientation,
            // React Aria's props do not name the data-muxui-state-read-only hook the styles read, nor the capture handlers for a key press
            // or a change, and TypeScript accepts such a key in a call only from a spread.
            ...{ 'data-muxui-state-read-only': readOnly ? readOnly : undefined },
            onMouseDownCapture: preventReadOnlyInteraction,
            onTouchStartCapture: preventReadOnlyInteraction,
            onPointerDownCapture: preventReadOnlyInteraction,
            onPointerMoveCapture: preventReadOnlyInteraction,
            onTouchMoveCapture: preventReadOnlyInteraction,
            onClickCapture: preventReadOnlyInteraction,
            ...{ onKeyDownCapture: readOnlyKeyGuard(readOnly), onChangeCapture: preventReadOnlyInteraction },
            className: classNames('muxui-slider', className),
            'aria-label': ariaLabel,
            'aria-labelledby': ariaLabelledby,
        }, React.createElement('div', { className: 'muxui-slider__header' }, label !== undefined ? React.createElement(AriaLabel, { className: 'muxui-field-label' }, label) : null, React.createElement(AriaOutput, { className: 'muxui-slider__output' })), React.createElement('div', { className: 'muxui-slider__control' }, React.createElement(SliderMotionTrack, { orientation, readOnly, name })));
    });
    component.displayName = 'Slider';
    return component;
})();
const AriaOutput = AriaSliderOutput;

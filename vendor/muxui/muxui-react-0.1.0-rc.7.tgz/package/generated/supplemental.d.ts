// @generated-from: packages/react/src/supplemental/index.ts
// @generated-content-sha256: sha256:40c2dc8203cdb7cd36d62679db01e122421f879ab8e2133382b31ea65b362a5e
export declare const supplementalFamilies: readonly ["AlertDialog", "Avatar", "ButtonGroup", "Card", "CheckboxField", "ColorModeToggle", "CommandPalette", "HeaderNav", "Image", "InputTags", "Input", "MultiSelect", "PaymentInput", "ProgressCircle", "RadioField", "SelectNative", "Sidebar", "SwitchField", "TagSelect", "TextArea", "Text"];

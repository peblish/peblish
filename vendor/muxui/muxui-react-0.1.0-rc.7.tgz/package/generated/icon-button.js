// @generated-from: packages/react/src/supplemental/icon-button.ts
// @generated-content-sha256: sha256:c8c22a4270c9c24705b39d57770fd301a1f2ab7bb2696cc8b5e65880e43ed74d
import React from 'react';
import { ButtonContext, useSlottedContext } from 'react-aria-components';
import { Button } from './button.js';
/** An icon-only action with Button behavior and an explicit accessible name. */
export const IconButton = React.forwardRef(function IconButton({ children, className, disabled, pending, variant = 'ghost', size = 'md', onActivate, ...props }, ref) {
    const contextProps = useSlottedContext(ButtonContext, props.slot);
    const ariaLabel = props['aria-label'] !== undefined ? props['aria-label'] : contextProps?.['aria-label'];
    const ariaLabelledby = props['aria-labelledby'] !== undefined ? props['aria-labelledby'] : contextProps?.['aria-labelledby'];
    const hasName = [ariaLabel, ariaLabelledby]
        .some((value) => typeof value === 'string' && value.trim().length > 0);
    if (!hasName) {
        throw new TypeError('IconButton requires a non-empty aria-label or aria-labelledby.');
    }
    // Button forwards data attributes to its <button>, though ButtonProps does not name them.
    const buttonProps = {
        ...props,
        ref,
        disabled,
        pending,
        variant,
        size,
        onActivate,
        className: ['muxui-icon-button', className].filter(Boolean).join(' '),
        'data-muxui-icon-button': '',
        showTextWhileLoading: false,
    };
    return React.createElement(Button, buttonProps, React.createElement('span', {
        className: 'muxui-icon-button__icon',
        'aria-hidden': true,
    }, children));
});
IconButton.displayName = 'IconButton';

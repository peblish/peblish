// @generated-from: packages/react/src/virtualizer.ts
// @generated-content-sha256: sha256:f1b0cd89be292f2359a2c4b2192bb5eaabbd65e1b97dc1a3b5d4cbde3b0c6a9c
import type { CSSProperties, ForwardRefExoticComponent, ReactElement, RefAttributes, UIEventHandler } from 'react';
import type { MuxUIItems } from './collection-items.js';
import type { MuxUIAriaLabel } from './fields.js';
/** The props Mux UI defines for Virtualizer. */
export type VirtualizerOwnProps = {
    /** `stack`, the default, is a fixed-row list that renders its own items. `grid` wraps one GridList that has layout="grid" and the vertical orientation, and lays it out in measured rows. */
    layout?: 'stack' | 'grid';
    /** The rows of a stack layout, as strings or items with an `id`, a `label`, a `textValue`, and `disabled`. Stack layout only: a grid takes its items on its GridList. */
    items?: MuxUIItems;
    /** The stack viewport's block size in px, a finite number greater than 0. Stack layout only. */
    height?: number;
    /** The fixed height of each stack row in px, a finite number greater than 0. Rows are not measured, so content taller than this overflows into the next row. Stack layout only. */
    itemHeight?: number;
    /** The rows mounted above and below the visible window, an integer of 0 or more. For a grid they are whole grid rows. */
    overscan?: number;
    /** Disables every stack row and stops `onScroll`. Stack layout only: a grid disables its GridList instead. */
    disabled?: boolean;
    /** Called when the stack viewport scrolls. It is not called while the Virtualizer is disabled. Stack layout only. */
    onScroll?: UIEventHandler<HTMLDivElement>;
    /** The GridList a grid layout lays out, which must have layout="grid". Required for a grid; a stack renders its own items and takes no children. */
    children?: ReactElement;
    /** Minimum item width in px for a grid, a finite number greater than 0. Default 200. */
    minItemWidth?: number;
    /** Maximum item width in px for a grid, Infinity or a finite number no smaller than `minItemWidth`. Default unbounded, so items stretch to fill their columns. */
    maxItemWidth?: number;
    /** Estimated height in px of the grid rows that have not mounted yet, a finite number greater than 0. Default 200. Mounted rows take their measured content height. */
    estimatedItemHeight?: number;
    /** Cap on the number of grid columns, Infinity or an integer greater than 0. Default unbounded. A narrow container shows fewer. */
    maxColumns?: number;
};
/** The default fixed-row list: a bounded, named scroll viewport that renders its own items. */
export type VirtualizerStackProps = MuxUIAriaLabel & Pick<VirtualizerOwnProps, 'items' | 'height' | 'itemHeight' | 'overscan' | 'disabled' | 'onScroll'> & {
    layout?: 'stack';
    className?: string;
    style?: CSSProperties;
    children?: never;
    minItemWidth?: never;
    maxItemWidth?: never;
    estimatedItemHeight?: never;
    maxColumns?: never;
};
/** Lays out a GridList with layout="grid" in measured rows. It renders no element of its own: the GridList is the scroll region, so name, size, spacing, and scroll handling belong on the GridList. */
export type VirtualizerGridProps = Pick<VirtualizerOwnProps, 'minItemWidth' | 'maxItemWidth' | 'estimatedItemHeight' | 'maxColumns' | 'overscan'> & {
    layout: 'grid';
    children: ReactElement;
    'aria-label'?: never;
    'aria-labelledby'?: never;
    items?: never;
    height?: never;
    itemHeight?: never;
    disabled?: never;
    onScroll?: never;
    className?: never;
    style?: never;
};
export type VirtualizerProps = VirtualizerStackProps | VirtualizerGridProps;
type VirtualizerComponent = ForwardRefExoticComponent<(VirtualizerStackProps & RefAttributes<HTMLDivElement>) | (VirtualizerGridProps & {
    ref?: never;
})>;
export declare const Virtualizer: VirtualizerComponent;
export {};

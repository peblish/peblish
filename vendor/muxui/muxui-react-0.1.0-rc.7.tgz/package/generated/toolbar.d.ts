// @generated-from: packages/react/src/toolbar.ts
// @generated-content-sha256: sha256:cc2d64c1af2ba4d40e4236247f2a6e7e4ef7aa926a88f99701bec96667e14a5b
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUIAriaAccessibleName } from './fields.js';
/**
 * The props Mux UI defines for Toolbar. The controls it groups are its children, and it is named by
 * aria-label or aria-labelledby.
 */
export type ToolbarOwnProps = {
    /** The direction the controls are laid out and the arrow keys move focus along. Vertical stacks them in a column. */
    orientation?: 'horizontal' | 'vertical';
};
export type ToolbarProps = ToolbarOwnProps & {
    children?: ReactNode;
    className?: string;
} & MuxUIAriaAccessibleName;
export declare const Toolbar: ForwardRefExoticComponent<ToolbarProps & RefAttributes<HTMLDivElement>>;

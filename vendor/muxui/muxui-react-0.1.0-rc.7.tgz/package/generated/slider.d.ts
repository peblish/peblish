// @generated-from: packages/react/src/slider.ts
// @generated-content-sha256: sha256:76f3e965f7eb43ffb09f72645497bd587dbcd46f73927d59325c083116481746
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUIAccessibleName } from './fields.js';
/** The props Mux UI defines for Slider. The slider is named by label, aria-label, or aria-labelledby. */
export type SliderOwnProps = {
    /** The visible label, which also names the slider. Without one, the slider needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** The value, when the caller controls it. */
    value?: number;
    /** The starting value, when the slider controls itself. */
    defaultValue?: number;
    /** The smallest value the thumb can take. */
    min?: number;
    /** The largest value the thumb can take. */
    max?: number;
    /** How far one arrow key press moves the value, and the increment the value snaps to. */
    step?: number;
    /** Disables the slider: it can be neither focused nor changed. */
    disabled?: boolean;
    /** Makes the slider read-only: it stays focusable but its value cannot be changed. */
    readOnly?: boolean;
    /** The direction of the track. */
    orientation?: 'horizontal' | 'vertical';
    /** The form field name. A named slider submits its value. */
    name?: string;
    /** Called with the new value each time it changes while the thumb moves. A disabled or read-only slider does not call it. */
    onChange?: (value: number) => void;
    /** Called with the current value when an interaction ends, such as a key press or a drag release, even when the value did not move. A disabled or read-only slider does not call it. */
    onChangeEnd?: (value: number) => void;
};
export type SliderProps = Omit<SliderOwnProps, 'label'> & {
    className?: string;
} & MuxUIAccessibleName;
export declare const Slider: ForwardRefExoticComponent<SliderProps & RefAttributes<HTMLDivElement>>;

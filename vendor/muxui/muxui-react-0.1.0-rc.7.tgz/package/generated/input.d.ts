// @generated-from: packages/react/src/supplemental/input.ts
// @generated-content-sha256: sha256:036426620517fc96a4d5c5b31d4c3025814bd2ab48426d417678c44d2b168eea
import type { ForwardRefExoticComponent, HTMLAttributes, InputHTMLAttributes, RefAttributes } from 'react';
import type { PartProps } from './part-utils.js';
/**
 * The props Mux UI defines for Input.Root, the compound's root; the catalog's web.react API is
 * derived from this type (Decision 0031). The members every field shares are written out, because
 * the catalog's grammar reads only the members a type lists itself. The input's native attributes,
 * such as type and placeholder, belong to Input.Input.
 */
type InputOwnProps = {
    /** The text, when the caller controls it. */
    value?: string;
    /** The starting text, when the field controls itself. */
    defaultValue?: string;
    /** Called with the new text each time it changes. */
    onChange?: (value: string) => void;
    /** Marks the field disabled. */
    disabled?: boolean;
    /** Marks the field invalid. */
    invalid?: boolean;
    /** Marks the field required. */
    required?: boolean;
    /** Marks the field read-only. */
    readOnly?: boolean;
    /** The field's size. */
    size?: 'sm' | 'md' | 'lg';
};
export type InputRootProps = Omit<HTMLAttributes<HTMLDivElement>, 'onChange' | 'defaultValue'> & InputOwnProps;
export type InputControlProps = InputHTMLAttributes<HTMLInputElement>;
export type InputProps = InputControlProps;
export type InputLabelProps = PartProps<HTMLLabelElement>;
export type InputDescriptionProps = PartProps<HTMLElement>;
export type InputErrorProps = PartProps<HTMLElement>;
export declare const Input: {
    Root: ForwardRefExoticComponent<InputRootProps & RefAttributes<HTMLDivElement>>;
    Input: ForwardRefExoticComponent<InputControlProps & RefAttributes<HTMLInputElement>>;
    Label: ForwardRefExoticComponent<InputLabelProps & RefAttributes<HTMLLabelElement>>;
    Description: ForwardRefExoticComponent<InputDescriptionProps & RefAttributes<HTMLElement>>;
    Error: ForwardRefExoticComponent<InputErrorProps & RefAttributes<HTMLElement>>;
};
export {};

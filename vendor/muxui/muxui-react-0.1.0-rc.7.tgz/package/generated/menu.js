// @generated-from: packages/react/src/menu.ts
// @generated-content-sha256: sha256:b68065ee9cdcadb74835576852b02857752efdf1008be3756bcf3ec315bc4939
import React from 'react';
import { flushSync } from 'react-dom';
import { MenuMotion } from './menu-motion.mjs';
import { MenuSection as AriaMenuSection, MenuTrigger as AriaMenuTrigger, SubmenuTrigger as AriaSubmenuTrigger, Separator as AriaSeparator, Header as AriaHeader, PopoverContext, RootMenuTriggerStateContext, useSlottedContext } from 'react-aria-components';
import { AriaMenu, AriaMenuItem } from './substrate.js';
import { overlayGeometry, normalizeBoolean } from './overlay-positioning.mjs';
import { createFocusManager } from 'react-aria/private/focus/FocusScope';
import { PopoverMotion } from './popover-motion.mjs';
import { classNames, accessibleName } from './control-utils.js';
import { textContent, normalizeItems, collectionItem } from './collection-items.js';
import { CollectionTrigger } from './collection-trigger.js';
const useMenuLayoutEffect = typeof window === 'undefined' ? React.useEffect : React.useLayoutEffect;
// The geometry a popup falls back to, bar its placement, which depends on whether a submenu holds it. A parameter
// default and the geometry helper's fallback both read this record, so the default a block states is the one that runs.
const MENU_POPUP_GEOMETRY = Object.freeze({ offset: 4, crossOffset: 0, shouldFlip: true, containerPadding: 12 });
const MenuContext = React.createContext({ disabled: false });
// The element a popup is anchored to, for the list inside it.
const MenuAnchorContext = React.createContext(null);
// Tab leaves an open menu: the whole menu tree closes, which makes the rest of the page interactive again, and focus goes to
// the first of `origins` that is still in the page and takes it (the trigger, else the element focused as the menu opened,
// else its anchor). The browser then moves on from there by its own rules, so Tab's default action is left alone.
function leaveMenuOnTab(menuTrigger, origins, shiftKey) {
    flushSync(() => menuTrigger.close());
    for (const origin of origins) {
        if (!origin?.isConnected || origin === origin.ownerDocument.body)
            continue;
        // Any element React Aria hands focus to here takes it, an SVG one included.
        origin.focus({ preventScroll: true });
        // A Toolbar may hand focus on to the control it last held, so focus anywhere in it counts.
        const toolbar = origin.closest('[role="toolbar"]');
        const focused = origin.ownerDocument.activeElement;
        if (focused !== origin && !toolbar?.contains(focused))
            continue;
        // A Toolbar sends Tab out of itself by focusing its last control (first for Shift+Tab) before the default action, but
        // it ignores keys from a portalled menu, so the menu does the same.
        if (toolbar) {
            const toolbarFocus = createFocusManager({ current: toolbar });
            if (shiftKey)
                toolbarFocus.focusFirst();
            else
                toolbarFocus.focusLast();
        }
        return;
    }
}
function MenuSubmenu({ children, delay = 200 }) {
    if (!Number.isFinite(delay) || delay < 0)
        throw new TypeError('Menu.Submenu delay must be a nonnegative finite number');
    const pair = React.Children.toArray(children);
    if (pair.length !== 2 || !pair.every(React.isValidElement))
        throw new TypeError('Menu.Submenu requires an item and a popup');
    return React.createElement(AriaSubmenuTrigger, { delay, children: pair });
}
export const Menu = /*#__PURE__*/ (() => {
    const Menu = React.forwardRef(function Menu(props, ref) {
        accessibleName({ ariaLabel: props['aria-label'], ariaLabelledby: props['aria-labelledby'] }, 'Menu');
        return React.createElement(MenuList, { ...props, ref, standalone: true });
    });
    Menu.displayName = 'Menu';
    const MenuRoot = React.forwardRef(function MenuRoot({ open, defaultOpen = false, onOpenChange, onAction, onSelect, disabled = false, shouldCloseOnSelect = true, className, children, ...props }, ref) {
        const [internalOpen, setInternalOpen] = React.useState(defaultOpen);
        // Conditionals, not ?? and || on the owned props: extraction reads a fallback on an owned prop as an executed default.
        const currentOpen = !disabled && (open == null ? internalOpen : open);
        const setOpen = (next) => {
            if (disabled && next)
                return;
            if (open === undefined)
                setInternalOpen(next);
            onOpenChange?.(next);
        };
        const context = { disabled, shouldCloseOnSelect, onAction, onSelect };
        return React.createElement(MenuContext.Provider, { value: context }, React.createElement(AriaMenuTrigger, {
            isOpen: currentOpen,
            onOpenChange: setOpen,
            children: React.createElement('div', { ...props, ref, className: classNames('muxui-menu__root', className), 'data-muxui-state-open': currentOpen || undefined, 'data-muxui-state-disabled': disabled ? disabled : undefined }, children),
        }));
    });
    const MenuTrigger = React.forwardRef(function MenuTrigger({ disabled = false, onActivate, className, children, ...props }, ref) {
        const context = React.useContext(MenuContext);
        const effectiveDisabled = disabled ? disabled : context.disabled;
        return React.createElement(CollectionTrigger, { ...props, ref, disabled: effectiveDisabled, onActivate, className: classNames('muxui-menu__trigger', className) }, children);
    });
    const MenuPopup = /*#__PURE__*/ React.forwardRef(function MenuPopup({ children, placement, offset = MENU_POPUP_GEOMETRY.offset, crossOffset = MENU_POPUP_GEOMETRY.crossOffset, shouldFlip = MENU_POPUP_GEOMETRY.shouldFlip, containerPadding = MENU_POPUP_GEOMETRY.containerPadding, anchorRef, modal = true, className, ...props }, ref) {
        // The placement has no default of its own to state: a top-level popup falls back to bottom-start, and a popup in a submenu to none, so the
        // placement React Aria gives a submenu, beside its item (end top), applies. React Aria renders that popup outside Menu.Submenu's React
        // subtree, so only its PopoverContext, which names the trigger, says the popup is nested; it is read through the popup's own slot, as
        // React Aria reads it. A SubmenuTrigger marker a consumer puts directly around a popup reads as nested too, and Menu.Root replaces any outside it.
        const nested = useSlottedContext(PopoverContext, props.slot)?.trigger === 'SubmenuTrigger';
        const { placement: validPlacement, ...geometry } = overlayGeometry({ placement, offset, crossOffset, shouldFlip, containerPadding }, { ...MENU_POPUP_GEOMETRY, placement: 'bottom-start' }, 'Menu.Popup');
        return React.createElement(PopoverMotion, { ...props, ...geometry, placement: nested && placement === undefined ? undefined : validPlacement, ref, triggerRef: anchorRef, isNonModal: !normalizeBoolean(modal, true, 'Menu.Popup modal'), className: classNames('muxui-menu__popup', className) }, React.createElement(MenuAnchorContext.Provider, { value: anchorRef ?? null }, children));
    });
    const MenuList = React.forwardRef(function MenuList({ items, children, disabled = false, shouldCloseOnSelect, onAction, onSelect, className, standalone = false, ...props }, ref) {
        const context = React.useContext(MenuContext);
        const effectiveDisabled = context.disabled || disabled;
        // normalizeItems takes no items as an empty list, so an omitted list has no default here to state.
        const normalized = normalizeItems(items);
        const hasChildren = children !== undefined && children !== null;
        const disabledKeys = new Set(normalized.filter((item) => effectiveDisabled || item.disabled).map((item) => item.id));
        // Tab leaves an open menu, as it does for a menu button. Only the root list handles it, since a submenu's Tab bubbles
        // to it through the React tree.
        const popover = React.useContext(PopoverContext);
        const menuTrigger = React.useContext(RootMenuTriggerStateContext);
        const anchorRef = React.useContext(MenuAnchorContext);
        // A menu with no trigger button, opened from another control, gives focus back to that control: the one focused as each
        // opening starts, before focus moves into the menu. The list stays mounted while the menu exits, so this follows the
        // open state, not the mount; focus already inside a menu popup is the menu's own, as when StrictMode replays the effect
        // after focus moved in, so it never replaces the opener.
        const opener = React.useRef(null);
        const menuOpen = menuTrigger?.isOpen ?? false;
        useMenuLayoutEffect(() => {
            if (!menuOpen)
                opener.current = null;
            else if (!document.activeElement?.closest('.muxui-menu__popup'))
                opener.current = document.activeElement;
        }, [menuOpen]);
        const menu = React.createElement(AriaMenu, {
            ...props,
            // The list's own Tab handling moves focus back into the list, so the handler must run after it, which `render` allows.
            // React Aria's MenuTrigger provides both the popover's trigger and the menu's state for as long as the popover reports one.
            render: popover?.trigger === 'MenuTrigger' ? (domProps) => React.createElement('div', {
                ...domProps,
                onKeyDown: (event) => {
                    domProps.onKeyDown?.(event);
                    if (event.key === 'Tab')
                        leaveMenuOnTab(menuTrigger, [popover.triggerRef.current, opener.current, anchorRef?.current], event.shiftKey);
                },
            }) : undefined,
            items: hasChildren ? undefined : normalized,
            disabledKeys,
            // A conditional, not ??: extraction reads a fallback on an owned prop as an executed default, and the root's setting is the next fallback.
            shouldCloseOnSelect: shouldCloseOnSelect == null ? (context.shouldCloseOnSelect ?? true) : shouldCloseOnSelect,
            onAction: (key) => {
                const item = normalized.find((candidate) => candidate.id === String(key)) ?? collectionItem(key);
                if (!effectiveDisabled && !item.disabled) {
                    onAction?.(item);
                    onSelect?.(item);
                    context.onAction?.(item);
                    context.onSelect?.(item);
                }
            },
            // React Aria's props do not name aria-disabled or the data-* hooks the styles read, and TypeScript accepts such a key in a call only from a spread.
            ...{ 'data-muxui-state-disabled': effectiveDisabled || undefined, 'aria-disabled': effectiveDisabled || undefined },
            className: classNames(standalone ? 'muxui-menu' : 'muxui-menu muxui-menu__list', className),
            children: hasChildren ? children : (item) => React.createElement(MenuItem, { id: item.id, textValue: item.textValue, disabled: item.disabled }, item.label),
        });
        return React.createElement(MenuContext.Provider, { value: { ...context, disabled: effectiveDisabled } }, React.createElement(MenuMotion, { rootRef: ref, children: menu }));
    });
    const MenuItem = React.forwardRef(function MenuItem({ children, id, textValue, disabled = false, className, onAction, shouldCloseOnSelect, ...props }, ref) {
        const context = React.useContext(MenuContext);
        const effectiveDisabled = disabled ? disabled : context.disabled;
        return React.createElement(AriaMenuItem, {
            ...props, ref, id,
            // A conditional, not ??: extraction reads a fallback on an owned prop as an executed default, and the item's own text is none.
            textValue: textValue == null ? (textContent(children) || undefined) : textValue,
            isDisabled: effectiveDisabled,
            // Forwarded as given: left unset, React Aria applies the menu's setting.
            shouldCloseOnSelect,
            onAction: onAction ? () => { if (!effectiveDisabled)
                onAction(); } : undefined,
            ...{ 'data-muxui-state-disabled': effectiveDisabled || undefined, 'aria-disabled': effectiveDisabled || undefined },
            className: classNames('muxui-menu__item', className),
        }, children);
    });
    const MenuSection = React.forwardRef(function MenuSection({ children, title, className, ...props }, ref) {
        return React.createElement(AriaMenuSection, { ...props, ref, className: classNames('muxui-menu__section', className) }, title !== undefined ? React.createElement(MenuHeader, null, title) : null, children);
    });
    const MenuHeader = React.forwardRef(function MenuHeader({ children, className, ...props }, ref) {
        return React.createElement(AriaHeader, { ...props, ref, className: classNames('muxui-menu__header', className) }, children);
    });
    const MenuSeparator = React.forwardRef(function MenuSeparator({ className, ...props }, ref) {
        return React.createElement(AriaSeparator, { ...props, ref, elementType: 'hr', className: classNames('muxui-menu__separator', className) });
    });
    Menu.Root = MenuRoot;
    Menu.Trigger = MenuTrigger;
    Menu.Popup = MenuPopup;
    Menu.List = MenuList;
    Menu.Item = MenuItem;
    Menu.Submenu = MenuSubmenu;
    Menu.Section = MenuSection;
    Menu.Header = MenuHeader;
    Menu.Separator = MenuSeparator;
    return Menu;
})();

// @generated-from: packages/react/src/supplemental/modal-parts.ts
// @generated-content-sha256: sha256:5ede5e085cff2435732051e4d072ca332b176cef1c02560c6bd8b3dc5a613377
import type { ForwardRefExoticComponent, HTMLAttributes, RefAttributes, RefObject } from 'react';
export type MotionModalBackdropProps = HTMLAttributes<HTMLDivElement> & {
    isOpen?: boolean;
    onOpenChange?: (isOpen: boolean) => void;
    isDismissable?: boolean;
    triggerRef?: RefObject<Element | null>;
};
export type MotionModalPopupProps = HTMLAttributes<HTMLDivElement> & {
    isExiting?: boolean;
};
export declare const MotionModalBackdropForwardRef: ForwardRefExoticComponent<MotionModalBackdropProps & RefAttributes<HTMLDivElement>>;
export declare const MotionModalPopupForwardRef: ForwardRefExoticComponent<MotionModalPopupProps & RefAttributes<HTMLDivElement>>;

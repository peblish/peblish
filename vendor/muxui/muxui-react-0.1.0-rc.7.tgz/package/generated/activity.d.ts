// @generated-from: packages/react/src/supplemental/activity.ts
// @generated-content-sha256: sha256:d99fc5f7ffac2b121ffbf4cec211ff6b937b69093a7578cfa135b686e1ba0fde
import type { ForwardRefExoticComponent, HTMLAttributes, ReactNode, RefAttributes } from 'react';
export type ActivityStatus = 'queued' | 'running' | 'completed' | 'failed' | 'cancelled';
export type ActivityAction = {
    id: string;
    label: string;
    onAction: () => void;
    disabled?: boolean;
};
export type ActivityItem = {
    id: string;
    label: string;
    status: ActivityStatus;
    details?: ReactNode;
    context?: ReactNode;
    meta?: ReactNode;
    time?: string;
    actions?: readonly ActivityAction[];
    /** Starts the item's disclosure open. Read at mount, so later changes do not open or close it; an item without details, context, or actions ignores it. */
    defaultExpanded?: boolean;
};
/**
 * The props Mux UI defines for Activity; the catalog's web.react API is derived from
 * this type (Decision 0031).
 * It is a type literal, not an interface, so the public props type stays assignable to
 * Record<string, unknown>, as it was before the move.
 */
type ActivityOwnProps = {
    /** Names the group of tasks. */
    label: string;
    /** The tasks, each with the status the application supplies. Each id is unique and nonempty. */
    items: readonly ActivityItem[];
    /** The group status. Without it the group follows its items: failed first, then running, queued, cancelled, and completed. */
    status?: ActivityStatus;
    /** Whether the group is open, when the caller controls it. */
    expanded?: boolean;
    /** Whether the group starts open, when Activity controls it. */
    defaultExpanded?: boolean;
    /** Reports the group opening or closing. */
    onExpandedChange?: (expanded: boolean) => void;
    /** Buttons that act on the whole group. */
    actions?: readonly ActivityAction[];
};
export type ActivityProps = ActivityOwnProps & Omit<HTMLAttributes<HTMLDivElement>, keyof ActivityOwnProps | 'children' | 'dangerouslySetInnerHTML'>;
/** Caller-supplied status, metadata and time; this component never starts or simulates tasks. */
export declare const Activity: ForwardRefExoticComponent<ActivityProps & RefAttributes<HTMLDivElement>>;
export {};

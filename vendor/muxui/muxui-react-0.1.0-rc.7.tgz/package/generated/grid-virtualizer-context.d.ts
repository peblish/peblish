// @generated-from: packages/react/src/grid-virtualizer-context.ts
// @generated-content-sha256: sha256:b5edca600415b27dd73242127aaff17dc48343ff881b6b1c1664a1a3f88b9f27
import type { Context } from 'react';
/** The resolved CSS column and row gap of a grid GridList, in px. */
export type GridGap = {
    column: number;
    row: number;
};
/** What a GridList in a grid Virtualizer calls to report its gap. */
export type ReportGridGap = (gap: GridGap) => void;
export declare const GridVirtualizerContext: Context<ReportGridGap | null>;

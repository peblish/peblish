// @generated-from: packages/react/src/toolbar.ts
// @generated-content-sha256: sha256:a12ea9a9dd7184b4f6c79d59b0d44992827909043070f51d0f2f8e454c6e19fb
import React from 'react';
import { AriaToolbar } from './substrate.js';
import { classNames, accessibleName } from './control-utils.js';
// The wrapper also takes and drops a `disabled`, which its public type does not offer: a Toolbar does not
// disable the controls it groups, and the attribute must not reach the DOM.
export const Toolbar = React.forwardRef(function Toolbar({ orientation = 'horizontal', disabled: _disabled, children, className, ...props }, ref) {
    accessibleName({ ariaLabel: props['aria-label'], ariaLabelledby: props['aria-labelledby'] }, 'Toolbar');
    return React.createElement(AriaToolbar, { ...props, ref, orientation, className: classNames('muxui-toolbar', className) }, children);
});
Toolbar.displayName = 'Toolbar';

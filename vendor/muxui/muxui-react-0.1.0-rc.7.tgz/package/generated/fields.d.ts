// @generated-from: packages/react/src/fields.ts
// @generated-content-sha256: sha256:3c31eecad352f6dacebaf15615d7d64dde5023b93ea0d1441ef90866a024d39b
import type { ForwardRefExoticComponent, FormEventHandler, FormHTMLAttributes, InputHTMLAttributes, ReactNode, Ref, RefAttributes } from 'react';
/** A calendar date as an ISO string, `YYYY-MM-DD`, with no time or time zone. */
export type MuxUIDateValue = string;
/** A local clock time as an ISO string, `HH:mm`, with no date, time zone, or offset. */
export type MuxUITimeValue = string;
/** A range of calendar dates, both ends included. */
export interface MuxUIDateRange {
    start: MuxUIDateValue;
    end: MuxUIDateValue;
}
/** The shared control sizes. */
export type ControlSize = 'sm' | 'md' | 'lg';
export interface FieldValidationProps {
    description?: ReactNode;
    /** Shown only while the field is invalid, through the invalid prop or failed validation, and replaces the built-in message; it never makes the field invalid by itself. */
    errorMessage?: ReactNode;
    disabled?: boolean;
    readOnly?: boolean;
    required?: boolean;
    invalid?: boolean;
    size?: ControlSize;
    className?: string;
}
export type MuxUIAccessibleName = {
    label: Exclude<ReactNode, null | undefined | boolean>;
    'aria-label'?: never;
    'aria-labelledby'?: never;
} | {
    label?: never;
    'aria-label': string;
    'aria-labelledby'?: never;
} | {
    label?: never;
    'aria-label'?: never;
    'aria-labelledby': string;
};
export type MuxUIAriaAccessibleName = {
    'aria-label': string;
    'aria-labelledby'?: never;
} | {
    'aria-label'?: never;
    'aria-labelledby': string;
};
export type MuxUIAriaLabel = {
    'aria-label': string;
};
export type NamedFieldProps = FieldValidationProps & MuxUIAccessibleName;
/** The native props of a field's inner input. The field owns the rest: its identity, value, change handlers, name, accessible name, and validation state. */
export type FieldInputProps = Omit<InputHTMLAttributes<HTMLInputElement>, 'children' | 'dangerouslySetInnerHTML' | 'slot' | 'type' | 'id' | 'name' | 'value' | 'defaultValue' | 'checked' | 'defaultChecked' | 'disabled' | 'readOnly' | 'required' | 'onChange' | 'onInput' | 'aria-label' | 'aria-labelledby' | 'aria-describedby' | 'aria-errormessage' | 'aria-invalid' | 'aria-required' | 'aria-disabled' | 'aria-readonly'>;
/**
 * The props Mux UI defines for TextField. The input's native attributes, such as autoComplete,
 * inputMode, maxLength, minLength, pattern, spellCheck, and autoFocus, its id, and its inputRef
 * pass through to the input unchanged.
 */
export type TextFieldOwnProps = {
    /** The visible label, which also names the field. Without one, the field needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the field, which also describes it. */
    description?: ReactNode;
    /** The message the field shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed native, custom, or server validation. It never makes the field invalid by itself. */
    errorMessage?: ReactNode;
    /** The text, when the caller controls it. */
    value?: string;
    /** The starting text, when the field controls itself. */
    defaultValue?: string;
    /** Called with the new text each time it changes. */
    onChange?: (value: string) => void;
    /** Disables the field: it can be neither focused nor changed. */
    disabled?: boolean;
    /** The control size. */
    size?: ControlSize;
    /** Makes the field read-only: its text stays visible and focusable but cannot be changed. */
    readOnly?: boolean;
    /** Marks the field required, so a form with native validation does not submit while it is empty. */
    required?: boolean;
    /** Marks the field invalid and shows its error message. Left false, validation decides, so failed native, custom, or server validation can still make the field invalid. */
    invalid?: boolean;
    /** The form field name. A named field submits its text with the form. */
    name?: string;
    /** An example value shown while the field is empty. It does not name the field. */
    placeholder?: string;
    /** The kind of text the input takes, which sets the keyboard and the browser's checks. */
    type?: 'text' | 'email' | 'password' | 'url' | 'tel';
    /** Native props for the inner input, such as keyboard, paste, focus, and selection handlers, and a className that merges with Mux UI's. The field owns its value, name, type, accessible name, validation, disabled, readOnly, and required, so inputProps cannot replace them. */
    inputProps?: FieldInputProps;
};
export type TextFieldProps = Omit<TextFieldOwnProps, 'label'> & {
    id?: string;
    inputRef?: Ref<HTMLInputElement>;
    autoComplete?: InputHTMLAttributes<HTMLInputElement>['autoComplete'];
    autoFocus?: InputHTMLAttributes<HTMLInputElement>['autoFocus'];
    inputMode?: InputHTMLAttributes<HTMLInputElement>['inputMode'];
    maxLength?: InputHTMLAttributes<HTMLInputElement>['maxLength'];
    minLength?: InputHTMLAttributes<HTMLInputElement>['minLength'];
    pattern?: InputHTMLAttributes<HTMLInputElement>['pattern'];
    spellCheck?: InputHTMLAttributes<HTMLInputElement>['spellCheck'];
} & NamedFieldProps;
/**
 * The props Mux UI defines for SearchField. The input's id and inputRef pass through to
 * the input unchanged.
 */
export type SearchFieldOwnProps = {
    /** The visible label, which also names the field. Without one, the field needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the field, which also describes it. */
    description?: ReactNode;
    /** The message the field shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed native, custom, or server validation. It never makes the field invalid by itself. */
    errorMessage?: ReactNode;
    /** The text, when the caller controls it. */
    value?: string;
    /** The starting text, when the field controls itself. */
    defaultValue?: string;
    /** Called with the new text each time it changes, including the empty string when Escape or the clear button empties the field. */
    onChange?: (value: string) => void;
    /** Called with the current text when Enter is pressed, including an empty string. A read-only field does not submit. */
    onSubmit?: (value: string) => void;
    /** Called after Escape or the clear button empties a field that had text. */
    onClear?: () => void;
    /** Disables the field: it can be neither focused nor changed. */
    disabled?: boolean;
    /** The control size. */
    size?: ControlSize;
    /** Makes the field read-only: its text stays visible and focusable but cannot be changed, submitted, or cleared. */
    readOnly?: boolean;
    /** Marks the field required, so a form with native validation does not submit while it is empty. */
    required?: boolean;
    /** Marks the field invalid and shows its error message. Left false, validation decides, so failed native, custom, or server validation can still make the field invalid. */
    invalid?: boolean;
    /** The form field name. A named field submits its text with the form. */
    name?: string;
    /** An example value shown while the field is empty. It does not name the field. */
    placeholder?: string;
    /** Native props for the inner input, such as keyboard, paste, focus, and selection handlers, and a className that merges with Mux UI's. The field owns its value, name, type, accessible name, validation, disabled, readOnly, and required, so inputProps cannot replace them. */
    inputProps?: FieldInputProps;
};
export type SearchFieldProps = Omit<SearchFieldOwnProps, 'label'> & {
    id?: string;
    inputRef?: Ref<HTMLInputElement>;
} & NamedFieldProps;
/** The props Mux UI defines for NumberField. */
export type NumberFieldOwnProps = {
    /** The visible label, which also names the field. Without one, the field needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the field, which also describes it. */
    description?: ReactNode;
    /** The message the field shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed native, custom, or server validation. It never makes the field invalid by itself. */
    errorMessage?: ReactNode;
    /** The number, when the caller controls it. NaN keeps the field empty. */
    value?: number;
    /** The starting number, when the field controls itself. */
    defaultValue?: number;
    /** Called with the new number each time it is committed, and with NaN when the field is cleared. */
    onChange?: (value: number) => void;
    /** Disables the field: it can be neither focused nor changed. */
    disabled?: boolean;
    /** The control size. */
    size?: ControlSize;
    /** Makes the field read-only: its number stays visible and focusable but cannot be changed. */
    readOnly?: boolean;
    /** Marks the field required, so a form with native validation does not submit while it is empty. */
    required?: boolean;
    /** Marks the field invalid and shows its error message. Left false, validation decides, so failed native, custom, or server validation can still make the field invalid. */
    invalid?: boolean;
    /** The smallest value. A typed value below it is raised to it when committed. */
    minValue?: number;
    /** The largest value. A typed value above it is lowered to it when committed. */
    maxValue?: number;
    /** How much the steppers and arrow keys change the value, and the step a typed value is rounded to when committed. */
    step?: number;
    /** The form field name. A named field submits the plain number, or an empty string while it is empty. */
    name?: string;
    /** How the number is shown, as Intl.NumberFormat options such as currency or percent. It changes only the displayed text: the field reports and submits plain numbers. */
    formatOptions?: Intl.NumberFormatOptions;
};
export type NumberFieldProps = Omit<NumberFieldOwnProps, 'label'> & NamedFieldProps;
/** The props Mux UI defines for CheckboxGroup. The checkboxes are its children. */
export type CheckboxGroupOwnProps = {
    /** The visible label, which also names the group. Without one, the group needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the group, which also describes it. */
    description?: ReactNode;
    /** The message the group shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed native, custom, or server validation. It never makes the group invalid by itself. */
    errorMessage?: ReactNode;
    /** The values of the checked options, when the caller controls them. */
    value?: string[];
    /** The values of the options that start checked, when the group controls itself. */
    defaultValue?: string[];
    /** Called with the values of all the checked options each time one changes. */
    onChange?: (value: string[]) => void;
    /** Disables the group and every option in it. */
    disabled?: boolean;
    /** Makes the group read-only: its options stay visible and focusable but cannot be changed. */
    readOnly?: boolean;
    /** Marks the group required, so a form with native validation does not submit while no option is checked. */
    required?: boolean;
    /** Marks the group invalid and shows its error message. Left false, validation decides, so failed native, custom, or server validation can still make the group invalid. */
    invalid?: boolean;
    /** The form field name, applied to every option. Checked values arrive as repeated entries under it. */
    name?: string;
    /** Whether the options stack in a column or sit in a row. The options take it from the group. */
    orientation?: 'vertical' | 'horizontal';
    /** The control size. The options take it from the group. */
    size?: 'sm' | 'md' | 'lg';
};
export type CheckboxGroupProps = Omit<CheckboxGroupOwnProps, 'label'> & {
    children?: ReactNode;
} & NamedFieldProps;
/** The props Mux UI defines for Switch. */
export type SwitchOwnProps = {
    /** The visible label, which also names the Switch. Without one, the Switch needs an aria-label or aria-labelledby, and children do not count as a name. When both label and children are given, label is shown. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the Switch, which also describes it. */
    description?: ReactNode;
    /** The message the Switch shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed native, custom, or server validation. It never makes the Switch invalid by itself. */
    errorMessage?: ReactNode;
    /** Whether the Switch is on, when the caller controls it. */
    selected?: boolean;
    /** Whether the Switch starts on, when it controls itself. */
    defaultSelected?: boolean;
    /** Called with the new on or off state each time it changes. */
    onChange?: (selected: boolean) => void;
    /** Disables the Switch: it can be neither focused nor changed. */
    disabled?: boolean;
    /** The control size. */
    size?: ControlSize;
    /** Makes the Switch read-only: its state stays visible and focusable but cannot be changed. */
    readOnly?: boolean;
    /** Marks the Switch required, so a form with native validation does not submit while it is off. */
    required?: boolean;
    /** Marks the Switch invalid and shows its error message. Left false, validation decides, so failed native, custom, or server validation can still make the Switch invalid. */
    invalid?: boolean;
    /** The form field name. A named Switch submits its value while it is on. */
    name?: string;
    /** What a named Switch submits while it is on. */
    value?: string;
};
export type SwitchProps = Omit<SwitchOwnProps, 'label'> & {
    children?: ReactNode;
    className?: string;
} & MuxUIAccessibleName;
/** Messages for the fields of a Form, keyed by field name. Each value is one message or several. */
export type MuxUIValidationErrors = {
    readonly [key: string]: string | string[];
};
/**
 * The props Mux UI defines for Form. Its native form attributes and events, such as method,
 * action, onSubmit, and onReset, pass through to the form element unchanged.
 */
export interface FormOwnProps {
    /** When fields show built-in validation errors. With native, the browser checks each field's rules, such as required and type, when the form is submitted, and a failing field stops the submit. With aria, those rules show no error and stop no submit, so the application decides when a field is invalid. */
    validationBehavior?: 'aria' | 'native';
    /** Errors from the application or a server, keyed by field name, each one message or an array of messages. A field shows its errors at once, and editing it or resetting the form dismisses them until a new object arrives. */
    validationErrors?: MuxUIValidationErrors;
}
export interface FormProps extends FormOwnProps, Omit<FormHTMLAttributes<HTMLFormElement>, keyof FormOwnProps | 'children' | 'className' | 'onSubmit' | 'onReset'> {
    children?: ReactNode;
    className?: string;
    onSubmit?: FormEventHandler<HTMLFormElement>;
    onReset?: FormEventHandler<HTMLFormElement>;
}
/** The props Mux UI defines for DateField. */
export type DateFieldOwnProps = {
    /** The visible label, which also names the field. Without one, the field needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the field, which also describes it. */
    description?: ReactNode;
    /** The message the field shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed native, custom, or server validation. It never makes the field invalid by itself. */
    errorMessage?: ReactNode;
    /** The date as YYYY-MM-DD, when the caller controls it. null keeps a controlled field empty. Any other string throws a TypeError. */
    value?: MuxUIDateValue | null;
    /** The starting date as YYYY-MM-DD, when the field controls itself. */
    defaultValue?: MuxUIDateValue;
    /** Called with the new date as YYYY-MM-DD, or with null when the field is cleared. */
    onChange?: (value: MuxUIDateValue | null) => void;
    /** The earliest date, inclusive. A value before it stays visible and invalid. A minValue later than maxValue throws a TypeError. */
    minValue?: MuxUIDateValue;
    /** The latest date, inclusive. A value after it stays visible and invalid. */
    maxValue?: MuxUIDateValue;
    /** Returns true for a date that is unavailable, given as a YYYY-MM-DD string. An unavailable date is invalid. */
    unavailableDateMatcher?: (date: MuxUIDateValue) => boolean;
    /** Disables the field: it can be neither focused nor changed. */
    disabled?: boolean;
    /** The control size. */
    size?: ControlSize;
    /** Makes the field read-only: its date stays visible and focusable but cannot be changed. */
    readOnly?: boolean;
    /** Marks the field required, so a form with native validation does not submit while it is empty. */
    required?: boolean;
    /** Marks the field invalid and shows its error message. Left false, validation decides, so failed native, custom, or server validation can still make the field invalid. */
    invalid?: boolean;
    /** The form field name. A named field submits YYYY-MM-DD, or an empty string while it is empty. */
    name?: string;
};
export type DateFieldProps = Omit<DateFieldOwnProps, 'label'> & NamedFieldProps;
/** The props Mux UI defines for TimeField. */
export type TimeFieldOwnProps = {
    /** The visible label, which also names the field. Without one, the field needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the field, which also describes it. */
    description?: ReactNode;
    /** The message the field shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed native, custom, or server validation. It never makes the field invalid by itself. */
    errorMessage?: ReactNode;
    /** The time as HH:mm, when the caller controls it. HH:mm:ss and HH:mm:ss.fraction are accepted with their seconds ignored. null keeps a controlled field empty. Any other string throws a TypeError. */
    value?: MuxUITimeValue | null;
    /** The starting time, when the field controls itself, in the formats value accepts. */
    defaultValue?: MuxUITimeValue;
    /** Called with the new time as HH:mm, or with null when the field is cleared. */
    onChange?: (value: MuxUITimeValue | null) => void;
    /** The earliest time, inclusive, in the formats value accepts. A value before it stays visible and invalid. A minValue later than maxValue throws a TypeError. */
    minValue?: MuxUITimeValue;
    /** The latest time, inclusive, in the formats value accepts. A value after it stays visible and invalid. */
    maxValue?: MuxUITimeValue;
    /** Disables the field: it can be neither focused nor changed. */
    disabled?: boolean;
    /** The control size. */
    size?: ControlSize;
    /** Makes the field read-only: its time stays visible and focusable but cannot be changed. */
    readOnly?: boolean;
    /** Marks the field required, so a form with native validation does not submit while it is empty. */
    required?: boolean;
    /** Marks the field invalid and shows its error message. Left false, validation decides, so failed native, custom, or server validation can still make the field invalid. */
    invalid?: boolean;
    /** The form field name. A named field submits HH:mm, or an empty string while it is empty. */
    name?: string;
};
/** TimeField works at minute precision: HH:mm:ss values and bounds are accepted, their seconds are ignored, and values submit and emit as HH:mm. */
export type TimeFieldProps = Omit<TimeFieldOwnProps, 'label'> & NamedFieldProps;
/** The props Mux UI defines for DatePicker. */
export type DatePickerOwnProps = {
    /** The visible label, which also names the field. Without one, the field needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the field, which also describes it. */
    description?: ReactNode;
    /** The message the field shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed native, custom, or server validation. It never makes the field invalid by itself. */
    errorMessage?: ReactNode;
    /** The date as YYYY-MM-DD, when the caller controls it. null keeps a controlled field empty. Any other string throws a TypeError. */
    value?: MuxUIDateValue | null;
    /** The starting date as YYYY-MM-DD, when the field controls itself. */
    defaultValue?: MuxUIDateValue;
    /** Called with the new date as YYYY-MM-DD, or with null when the field is cleared. */
    onChange?: (value: MuxUIDateValue | null) => void;
    /** Called with the new open state when the calendar opens or closes, including when choosing a date closes it. */
    onOpenChange?: (open: boolean) => void;
    /** The earliest date, inclusive. A value before it stays visible and invalid. A minValue later than maxValue throws a TypeError. */
    minValue?: MuxUIDateValue;
    /** The latest date, inclusive. A value after it stays visible and invalid. */
    maxValue?: MuxUIDateValue;
    /** Returns true for a date that is unavailable, given as a YYYY-MM-DD string. An unavailable date cannot be chosen in the calendar. */
    unavailableDateMatcher?: (date: MuxUIDateValue) => boolean;
    /** Whether the calendar is open, when the caller controls it. It is independent of the date: controlling one does not control the other. */
    open?: boolean;
    /** Whether the calendar starts open, when the picker controls itself. Omitted, it starts closed unless a React Aria context supplies defaultOpen. */
    defaultOpen?: boolean;
    /** Disables the field: it can be neither focused nor changed. */
    disabled?: boolean;
    /** The control size. */
    size?: ControlSize;
    /** Makes the field read-only: its date stays visible and focusable but cannot be changed. */
    readOnly?: boolean;
    /** Marks the field required, so a form with native validation does not submit while it is empty. */
    required?: boolean;
    /** Marks the field invalid and shows its error message. Left false, validation decides, so failed native, custom, or server validation can still make the field invalid. */
    invalid?: boolean;
    /** The form field name. A named field submits YYYY-MM-DD, or an empty string while it is empty. */
    name?: string;
};
export type DatePickerProps = Omit<DatePickerOwnProps, 'label'> & NamedFieldProps;
/** The props Mux UI defines for DateRangePicker. */
export type DateRangePickerOwnProps = {
    /** The visible label, which also names the field. Without one, the field needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the field, which also describes it. */
    description?: ReactNode;
    /** The message the field shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed native, custom, or server validation. It never makes the field invalid by itself. */
    errorMessage?: ReactNode;
    /** The range as start and end YYYY-MM-DD strings, when the caller controls it. null keeps a controlled field empty. A range missing either end throws a TypeError, and one whose end is before its start is kept as given and is invalid. */
    value?: MuxUIDateRange | null;
    /** The starting range, when the field controls itself, as a complete pair of YYYY-MM-DD strings. */
    defaultValue?: MuxUIDateRange;
    /** Called with the new range as YYYY-MM-DD strings, or with null when the field is cleared. */
    onChange?: (value: MuxUIDateRange | null) => void;
    /** Called with the new open state when the calendar opens or closes. */
    onOpenChange?: (open: boolean) => void;
    /** The earliest date, inclusive. A date before it stays visible and invalid. A minValue later than maxValue throws a TypeError. */
    minValue?: MuxUIDateValue;
    /** The latest date, inclusive. A date after it stays visible and invalid. */
    maxValue?: MuxUIDateValue;
    /** Returns true for a date that cannot be chosen. It receives the date being checked and the anchor, the start date chosen so far or null before a start is chosen, both as YYYY-MM-DD strings. Selection stays contiguous, so a range cannot cross an unavailable date. */
    unavailableDateMatcher?: (date: MuxUIDateValue, anchorDate: MuxUIDateValue | null) => boolean;
    /** Whether the calendar is open, when the caller controls it. It is independent of the range: controlling one does not control the other. */
    open?: boolean;
    /** Whether the calendar starts open, when the picker controls itself. Omitted, it starts closed unless a React Aria context supplies defaultOpen. */
    defaultOpen?: boolean;
    /** Disables the field: it can be neither focused nor changed. */
    disabled?: boolean;
    /** The control size. */
    size?: ControlSize;
    /** Makes the field read-only: its range stays visible and focusable but cannot be changed. */
    readOnly?: boolean;
    /** Marks the field required, so a form with native validation does not submit while it is empty. */
    required?: boolean;
    /** Marks the field invalid and shows its error message. Left false, validation decides, so failed native, custom, or server validation can still make the field invalid. */
    invalid?: boolean;
    /** The form field name of the start date. It submits YYYY-MM-DD, or an empty string while the range is empty. */
    startName?: string;
    /** The form field name of the end date. It submits YYYY-MM-DD, or an empty string while the range is empty. */
    endName?: string;
};
export type DateRangePickerProps = Omit<DateRangePickerOwnProps, 'label'> & NamedFieldProps;
/** One suggestion. */
export interface AutocompleteItem {
    /** Identifies the suggestion. Without one, a record takes its value, or else its position, as one. */
    id?: string;
    /** What the list and the input show. Without one, a record shows its value, or else its id. */
    label?: ReactNode;
    /** What the form and onChange receive when the suggestion is chosen. Without one, a record submits its id, or, with no id either, its label's text. */
    value?: string;
    /** Skips the suggestion in selection. */
    disabled?: boolean;
}
/** The suggestion onSelect receives, with each field filled in. */
export interface AutocompleteSelectionItem {
    id: string;
    label: ReactNode;
    value: string;
}
/**
 * The props Mux UI defines for Autocomplete. The input's accessible name can be an aria-label or
 * aria-labelledby when there is no label.
 */
export type AutocompleteOwnProps = {
    /** The visible label, which also names the field. Without one, the field needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the field, which also describes it. */
    description?: ReactNode;
    /** The message the field shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed native, custom, or server validation. It never makes the field invalid by itself. */
    errorMessage?: ReactNode;
    /** The submitted value, when the caller controls it. The input shows a matching item's label. */
    value?: string;
    /** The starting value, when the field controls itself. */
    defaultValue?: string;
    /** Called with the new value each time the text changes or a suggestion is chosen. A chosen suggestion reports its value, not its label. */
    onChange?: (value: string) => void;
    /** Called when a suggestion is chosen, with the chosen item. */
    onSelect?: (item?: AutocompleteSelectionItem) => void;
    /** Disables the field: it can be neither focused nor changed. */
    disabled?: boolean;
    /** The control size. The suggestion list takes it too. */
    size?: 'sm' | 'md' | 'lg';
    /** Makes the field read-only: its text stays visible and focusable but cannot be changed, and no suggestion can be chosen. */
    readOnly?: boolean;
    /** Marks the field required, so a form with native validation does not submit while it is empty. */
    required?: boolean;
    /** Marks the field invalid and shows its error message. Left false, validation decides, so failed native, custom, or server validation can still make the field invalid. */
    invalid?: boolean;
    /** The form field name. A named field submits the chosen suggestion's value, or the typed text when nothing was chosen. */
    name?: string;
    /** The suggestions, as strings or records. A string is shown and submitted as its text. Typing filters them by their text. */
    items?: (AutocompleteItem | string)[];
    /** An example value shown while the field is empty. It does not name the field. */
    placeholder?: string;
};
export type AutocompleteProps = Omit<AutocompleteOwnProps, 'label'> & NamedFieldProps;
export declare const TextField: ForwardRefExoticComponent<TextFieldProps & RefAttributes<HTMLDivElement>>;
export declare const SearchField: ForwardRefExoticComponent<SearchFieldProps & RefAttributes<HTMLDivElement>>;
export declare const NumberField: ForwardRefExoticComponent<NumberFieldProps & RefAttributes<HTMLDivElement>>;
export declare const CheckboxGroup: ForwardRefExoticComponent<CheckboxGroupProps & RefAttributes<HTMLDivElement>>;
export declare const Switch: ForwardRefExoticComponent<SwitchProps & RefAttributes<HTMLDivElement>>;
export declare const Form: ForwardRefExoticComponent<FormProps & RefAttributes<HTMLFormElement>>;
export declare const DateField: ForwardRefExoticComponent<DateFieldProps & RefAttributes<HTMLDivElement>>;
export declare const TimeField: ForwardRefExoticComponent<TimeFieldProps & RefAttributes<HTMLDivElement>>;
export declare const DatePicker: ForwardRefExoticComponent<DatePickerProps & RefAttributes<HTMLDivElement>>;
export declare const DateRangePicker: ForwardRefExoticComponent<DateRangePickerProps & RefAttributes<HTMLDivElement>>;
export declare const Autocomplete: ForwardRefExoticComponent<AutocompleteProps & RefAttributes<HTMLDivElement>>;

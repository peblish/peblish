// @generated-from: packages/react/src/supplemental/field-root.ts
// @generated-content-sha256: sha256:53b76669f57390d263de6ee3917cd3f7753c8c62515c5d10b1b25b71718cb538
import type { Context, Dispatch, ForwardedRef, ReactElement, SetStateAction } from 'react';
/** What Input and TextArea's description and error parts tell the field's input to describe itself by. */
export interface InputAssociation {
    setDescriptionId: Dispatch<SetStateAction<string | undefined>>;
    setErrorId: Dispatch<SetStateAction<string | undefined>>;
    descriptionId: string | undefined;
    errorId: string | undefined;
    size: 'sm' | 'md' | 'lg';
    invalid: boolean;
}
export declare const InputAssociationContext: Context<InputAssociation | null>;
/** What a field root hands renderFieldRoot: its state flags and size, its class and children, and the rest for the text field. */
type FieldRootProps = {
    disabled?: boolean;
    invalid?: boolean;
    required?: boolean;
    readOnly?: boolean;
    size: string;
    className?: string;
    children?: unknown;
    [other: string]: unknown;
};
/**
 * Renders the root of Input or TextArea: a text field that provides the input association to its parts. It calls hooks,
 * so a family calls it, unconditionally, from its own render function. The props are written structurally so that no
 * declaration names the upstream package.
 */
export declare function renderFieldRoot(rootClass: string, componentName: 'Input' | 'TextArea', { disabled, invalid, required, readOnly, size, className, children, ...props }: FieldRootProps, ref: ForwardedRef<HTMLDivElement>): ReactElement;
export {};

// @generated-from: packages/react/src/supplemental/progress-circle.ts
// @generated-content-sha256: sha256:c54fddd249762d1283acda7a115b45856be72b807f9c97ad0ae1989c90d3b5bb
import type { ForwardRefExoticComponent, HTMLAttributes, RefAttributes, SVGAttributes } from 'react';
import type { PartProps } from './part-utils.js';
/**
 * The props Mux UI defines for ProgressCircle.Root, the compound's root; the catalog's
 * web.react API is derived from this type (Decision 0031). Track, Label and Value take native attributes.
 */
type ProgressCircleOwnProps = {
    /** The progress between `minValue` and `maxValue`; `null` shows indeterminate progress. */
    value?: number | null;
    /** The value at which the circle is empty. */
    minValue?: number;
    /** The value at which the circle is full. */
    maxValue?: number;
    /** The circle's diameter. */
    size?: 'sm' | 'md' | 'lg';
    /** Accessible name shorthand; explicit aria-label or aria-labelledby takes precedence. */
    label?: string;
};
export type ProgressCircleProps = ProgressCircleOwnProps & HTMLAttributes<HTMLDivElement>;
export type ProgressCircleRootProps = ProgressCircleProps;
export type ProgressCircleTrackProps = SVGAttributes<SVGSVGElement>;
export type ProgressCircleLabelProps = PartProps<HTMLSpanElement>;
export type ProgressCircleValueProps = PartProps<HTMLSpanElement>;
export declare const ProgressCircle: {
    Root: ForwardRefExoticComponent<ProgressCircleProps & RefAttributes<HTMLDivElement>>;
    Track: ForwardRefExoticComponent<ProgressCircleTrackProps & RefAttributes<SVGSVGElement>>;
    Label: ForwardRefExoticComponent<ProgressCircleLabelProps & RefAttributes<HTMLSpanElement>>;
    Value: ForwardRefExoticComponent<ProgressCircleValueProps & RefAttributes<HTMLSpanElement>>;
};
export {};

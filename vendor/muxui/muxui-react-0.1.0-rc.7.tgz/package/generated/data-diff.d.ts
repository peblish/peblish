// @generated-from: packages/react/src/supplemental/data-diff.ts
// @generated-content-sha256: sha256:be44fe882c8d3edb356d03d60b1d377b3b76686452925bc7b06d43755fe95a7b
import type { ForwardRefExoticComponent, HTMLAttributes, RefAttributes } from 'react';
export type DataDiffValue = string | number | boolean | null;
export type DataDiffColumn = {
    readonly id: string;
    readonly label: string;
};
/** A row's value for each declared column, by column id. */
export type DataDiffValues = {
    readonly [columnId: string]: DataDiffValue;
};
/** The members every row has. The hand-written declarations made this name public, so it stays exported. */
export type DataDiffRowIdentity = {
    readonly id: string;
    readonly label: string;
    readonly disabled?: boolean;
};
/** A proposed change to one row: added, removed, and unchanged rows carry values, updated rows before and after. */
export type DataDiffRow = {
    readonly id: string;
    readonly label: string;
    readonly disabled?: boolean;
    readonly kind: 'unchanged' | 'added' | 'removed';
    readonly values: DataDiffValues;
    readonly before?: never;
    readonly after?: never;
} | {
    readonly id: string;
    readonly label: string;
    readonly disabled?: boolean;
    readonly kind: 'updated';
    readonly before: DataDiffValues;
    readonly after: DataDiffValues;
    readonly values?: never;
};
/**
 * The props Mux UI defines for DataDiff; the catalog's web.react API is derived from
 * this type (Decision 0031).
 * It is a type literal, not an interface, so the public props type stays assignable to
 * Record<string, unknown>, as it was before the move.
 */
type DataDiffOwnProps = {
    /** Visible heading and accessible table name. Native title remains a tooltip. */
    label: string;
    /** What Apply will do, shown under the heading. */
    description?: string;
    /** The columns, each with a unique, nonblank id and label. */
    columns: readonly DataDiffColumn[];
    /** Records contain exactly the declared column IDs, with explicit scalar values. */
    rows: readonly DataDiffRow[];
    /** The selected row ids, when the caller controls the selection. */
    selectedIds?: readonly string[];
    /** The ids selected at first, when DataDiff controls the selection. Without them every enabled proposed change starts selected; unchanged rows are never selectable. */
    defaultSelectedIds?: readonly string[];
    /** Reports the selected row ids, in row order, after each selection change. */
    onSelectionChange?: (ids: readonly string[]) => void;
    /** Called only by explicit Apply activation, with selected IDs in row order. */
    onApply?: (ids: readonly string[]) => void;
    /** Marks an apply in flight: selection and Apply are unavailable. */
    pending?: boolean;
    /** Makes selection and Apply unavailable. */
    disabled?: boolean;
    /** Replaces the whole Apply button label, which otherwise counts the selected changes. */
    applyLabel?: string;
    /** The text shown when there are no rows. */
    emptyMessage?: string;
};
export type DataDiffProps = DataDiffOwnProps & Omit<HTMLAttributes<HTMLDivElement>, keyof DataDiffOwnProps | 'children' | 'dangerouslySetInnerHTML'> & {
    children?: never;
    dangerouslySetInnerHTML?: never;
};
/** Review caller-supplied scalar changes. Selection and Apply never mutate records. */
export declare const DataDiff: ForwardRefExoticComponent<DataDiffProps & RefAttributes<HTMLDivElement>>;
export {};

// @generated-from: packages/react/src/supplemental/avatar.ts
// @generated-content-sha256: sha256:766ac732da872f92791e35be40cb7a96461a7d7e68b26781fb8ab6d808297b13
import type { ForwardRefExoticComponent, HTMLAttributes, ImgHTMLAttributes, ReactNode, RefAttributes } from 'react';
/** The sizes of an Avatar. */
export type AvatarSize = 'sm' | 'md' | 'lg';
/**
 * The props Mux UI defines for Avatar.Root, the compound's root; the catalog's
 * web.react API is derived from this interface (Decision 0031). Avatar.Image and
 * Avatar.Fallback take native image and span attributes.
 */
interface AvatarOwnProps {
    /** The avatar size. */
    size?: AvatarSize;
}
export type AvatarRootProps = AvatarOwnProps & HTMLAttributes<HTMLSpanElement> & {
    /** Avatar.Image and Avatar.Fallback, directly or inside fragments. */
    children?: ReactNode;
};
export type AvatarImageProps = Omit<ImgHTMLAttributes<HTMLImageElement>, 'alt' | 'className'> & {
    alt: string;
    className?: string;
};
export type AvatarFallbackProps = HTMLAttributes<HTMLSpanElement>;
export declare const Avatar: {
    Root: ForwardRefExoticComponent<AvatarRootProps & RefAttributes<HTMLSpanElement>>;
    Image: ForwardRefExoticComponent<AvatarImageProps & RefAttributes<HTMLImageElement>>;
    Fallback: ForwardRefExoticComponent<AvatarFallbackProps & RefAttributes<HTMLSpanElement>>;
};
export {};

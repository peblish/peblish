// @generated-from: packages/react/src/table.ts
// @generated-content-sha256: sha256:c011aa620df062f4b2eb015d23a1bb504f5418a5d4d77423b8f938a8a380e262
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUICollectionItem, MuxUISelection } from './collection-items.js';
import type { MuxUIAriaLabel } from './fields.js';
/** A column: its `id` names the row field or `values` entry its cells show. */
export interface MuxUITableColumn extends MuxUICollectionItem {
    /** Marks the column whose cells name their row. */
    isRowHeader?: boolean;
    /** Gives the column a sortable header: activating it reports the next sort through `onSortChange`. */
    sortable?: boolean;
}
/** A row: each cell shows the row's `values` entry for its column's id, or else the row's own field of that name. */
export interface MuxUITableRow extends MuxUICollectionItem {
    /** Cell content by column id. */
    values?: Record<string, ReactNode>;
}
export type MuxUITableSortDescriptor = {
    column: string;
    direction: 'ascending' | 'descending';
};
/** The props Mux UI defines for Table. The table is named by aria-label. */
export type TableOwnProps = {
    /** The columns as data: strings, or items with an `id`, a `label`, a `textValue`, `isRowHeader`, and `sortable`. */
    columns?: MuxUITableColumn[];
    /** The rows as data: items with an `id` and either a `values` entry or a field of the row for each column id. Selection follows each row's id when the rows reorder, so give every row an id that stays with its data. */
    rows?: MuxUITableRow[];
    /** The selected row ids when the caller controls the selection, or `'all'`. */
    selectedIds?: MuxUISelection;
    /** The row ids selected at first when the table controls its own selection, or `'all'`. */
    defaultSelectedIds?: MuxUISelection;
    /** The sorted column and its direction. A sort shows only when the application passes it back. `column` must be the id of a column with `sortable: true`, or Table throws a TypeError. */
    sortDescriptor?: MuxUITableSortDescriptor;
    /** Disables the table: rows cannot be selected or acted on, sort changes are ignored, and the root carries `data-muxui-state-disabled`. */
    disabled?: boolean;
    /** How many rows can be selected. */
    selectionMode?: 'none' | 'single' | 'multiple';
    /** Called with the selected row ids, or `'all'`, when the selection changes. It is not called while the table is disabled. */
    onSelectionChange?: (ids: MuxUISelection) => void;
    /** Called with the row record when the user activates a row. With selection on, a click or Enter runs it while nothing is selected and Space starts a selection; once a row is selected, a click changes the selection instead. It is not called for a disabled row or while the table is disabled. */
    onRowAction?: (row?: MuxUITableRow) => void;
    /** Called with the column and the next direction when the user activates a sortable header, which toggles between ascending and descending. Table never sorts rows: the application sorts them and passes `sortDescriptor` back. It is not called while the table is disabled. */
    onSortChange?: (next: MuxUITableSortDescriptor) => void;
};
export type TableProps = MuxUIAriaLabel & TableOwnProps & {
    className?: string;
};
export declare const Table: ForwardRefExoticComponent<TableProps & RefAttributes<HTMLTableElement>>;

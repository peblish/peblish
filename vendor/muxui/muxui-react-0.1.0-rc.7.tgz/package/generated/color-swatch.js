// @generated-from: packages/react/src/color-swatch.ts
// @generated-content-sha256: sha256:25592926265466efc6a0434937be8e7126cd107bcc44aa67692e0d19b505d07e
import React from 'react';
import { ColorSwatch as AriaColorSwatch, useLocale } from 'react-aria-components';
import { classNames } from './control-utils.js';
import { colorValue, ColorPickerContext } from './color-context.js';
export const ColorSwatch = React.forwardRef(function ColorSwatch({ color, secondaryColor, shape = 'square', colorName, disabled = false, className, style, ...props }, ref) {
    const pickerState = React.useContext(ColorPickerContext);
    const { locale } = useLocale();
    if (shape !== 'square' && shape !== 'circle')
        throw new TypeError('ColorSwatch shape must be square or circle');
    const primary = colorValue(color, 'ColorSwatch');
    const secondary = colorValue(secondaryColor, 'ColorSwatch secondaryColor');
    if (secondary && !primary)
        throw new TypeError('Two-tone ColorSwatch requires a primary color');
    // A conditional rather than `disabled || ...`: extraction reads `||` on an owned prop as replacing its default.
    const effectiveDisabled = disabled ? disabled : pickerState.disabled;
    return React.createElement(AriaColorSwatch, {
        ...props, ref, color: primary,
        colorName: colorName?.trim() || (secondary && primary ? `${primary.getColorName(locale)}, ${secondary.getColorName(locale)}` : undefined),
        // React Aria's props do not name isDisabled or the data-* hooks the styles read, and TypeScript accepts such a key in a call only from a spread.
        ...{
            isDisabled: effectiveDisabled,
            'data-muxui-state-disabled': effectiveDisabled || undefined,
            'data-muxui-state-read-only': pickerState.readOnly || undefined,
            'data-muxui-color-paint': 'sample',
            'data-muxui-shape': shape,
            'data-muxui-two-tone': secondary ? '' : undefined,
        },
        className: classNames('muxui-color-swatch', className),
        style: secondary && primary ? {
            ...style,
            // Avoid painting translucent gradient halves over the primary colour.
            backgroundColor: 'transparent',
            ...{
                '--muxui-color-swatch-primary': primary.toString('css'),
                '--muxui-color-swatch-secondary': secondary.toString('css'),
            },
        } : style,
    });
});
ColorSwatch.displayName = 'ColorSwatch';

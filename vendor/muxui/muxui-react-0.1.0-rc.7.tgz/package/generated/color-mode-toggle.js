// @generated-from: packages/react/src/supplemental/color-mode-toggle.ts
// @generated-content-sha256: sha256:0dbe358abb9299710b25703ee18e9bb878291dada29e5ec06b8da0cccb7268bf
import React from 'react';
import { AriaSwitch } from './substrate.js';
import { useColorMode } from './color-mode.js';
import { h, cx } from './part-utils.js';
/* Color mode */
export const ColorModeToggle = /*#__PURE__*/ React.forwardRef(function ColorModeToggle({ mode, defaultMode, storageKey = 'muxui-color-mode', disabled = false, onModeChange, className, children, ...props }, ref) {
    const { choice, select } = useColorMode({ mode, defaultMode, storageKey, followSystem: false });
    const update = (selected) => {
        const next = selected ? 'dark' : 'light';
        select(next);
        onModeChange?.(next);
    };
    // React Aria's props type the handlers on Element, and these on the label; the rest is the label's native attributes.
    return h(AriaSwitch, { ...props, ref, 'aria-label': props['aria-label'] ?? 'Toggle dark mode', isSelected: choice === 'dark', isDisabled: disabled, onChange: update, className: cx('muxui-color-mode-toggle', className), ...{ 'data-muxui-mode': choice } }, children);
});

// @generated-from: packages/react/src/supplemental/text-area.ts
// @generated-content-sha256: sha256:f88db1cfc885c2491d7227f974d44255dd84f81709b78b82c8d73186bf00c6bc
import React from 'react';
import { Label as AriaLabel } from 'react-aria-components';
import { AriaTextArea } from './substrate.js';
import { h, cx } from './part-utils.js';
import { fieldText } from './field-utils.js';
import { fieldError } from './field-error.js';
import { renderFieldRoot } from './field-root.js';
const TextAreaRoot = /*#__PURE__*/ React.forwardRef(function TextAreaRoot({ value, defaultValue, onChange, disabled, invalid, required, readOnly, size = 'md', className, children, ...props }, ref) {
    return renderFieldRoot('muxui-text-area', 'TextArea', { disabled, invalid, required, readOnly, size, className, children, value, defaultValue, onChange, ...props }, ref);
});
const TextAreaInput = /*#__PURE__*/ React.forwardRef(function TextAreaInput({ disabled, className, ...props }, ref) { return h(AriaTextArea, { ...props, ref, disabled, className: cx('muxui-text-area__textarea', className) }); });
const TextAreaLabel = /*#__PURE__*/ React.forwardRef(function TextAreaLabel(props, ref) { return h(AriaLabel, { ...props, ref, className: cx('muxui-text-area__label', props.className) }); });
const TextAreaDescription = /*#__PURE__*/ React.forwardRef(function TextAreaDescription(props, ref) { return fieldText('description', 'muxui-text-area__description', props, ref); });
const TextAreaError = /*#__PURE__*/ React.forwardRef(function TextAreaError(props, ref) { return fieldError('muxui-text-area__error', props, ref); });
export const TextArea = /*#__PURE__*/ Object.freeze({
    Root: TextAreaRoot,
    TextArea: TextAreaInput,
    Label: TextAreaLabel,
    Description: TextAreaDescription,
    Error: TextAreaError,
});

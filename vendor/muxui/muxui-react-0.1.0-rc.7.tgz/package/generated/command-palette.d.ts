// @generated-from: packages/react/src/supplemental/command-palette.ts
// @generated-content-sha256: sha256:1342258377d26a8b9391f9e1789b1db0a2498a8c9acc868bf49e0171a48766ca
import type { ButtonHTMLAttributes, ForwardRefExoticComponent, HTMLAttributes, InputHTMLAttributes, ReactElement, ReactNode, RefAttributes } from 'react';
import type { PartProps, SupplementalActivation } from './part-utils.js';
/**
 * The props Mux UI defines for CommandPalette.Root, the compound's root; the catalog's web.react API is derived from
 * this type (Decision 0031). Trigger, Backdrop, Close, SearchField, ClearButton, Item and Shortcut define theirs in the
 * OwnProps types below, and the other parts take native attributes only. They are type literals, not interfaces, so the
 * public props types stay assignable to Record<string, unknown>, as they were before the move.
 */
type CommandPaletteOwnProps = {
    /** Whether the palette is open, when the caller controls it. */
    open?: boolean;
    /** Whether the palette starts open, when it controls itself. */
    defaultOpen?: boolean;
    /** Called with the new open state each time the palette opens or closes. */
    onOpenChange?: (open: boolean) => void;
    /** The control size, which the trigger, the search input and the results follow. */
    size?: 'sm' | 'md' | 'lg';
    /** Whether activating an item closes the palette. An item can set its own. */
    closeOnSelect?: boolean;
};
/** The props Mux UI defines for CommandPalette.Trigger; its API is the trigger entry in the catalog's partApis. */
type CommandPaletteTriggerOwnProps = {
    /** Marks the trigger disabled. */
    disabled?: boolean;
    /** Called when the trigger is pressed, which opens the palette. */
    onActivate?: (event: SupplementalActivation) => void;
};
/** The props Mux UI defines for CommandPalette.Backdrop; its API is the backdrop entry in the catalog's partApis. */
type CommandPaletteBackdropOwnProps = {
    /** Whether pressing outside the popup closes the palette. */
    dismissable?: boolean;
};
/** The props Mux UI defines for CommandPalette.Close; its API is the close entry in the catalog's partApis. */
type CommandPaletteCloseOwnProps = {
    /** Marks the close control disabled. */
    disabled?: boolean;
    /** Called when the control is pressed, which closes the palette. */
    onActivate?: (event: SupplementalActivation) => void;
};
/** The props Mux UI defines for CommandPalette.SearchField; its API is the search-field entry in the catalog's partApis. */
type CommandPaletteSearchFieldOwnProps = {
    /** The look of the field's input: `default` draws its border, `inline` leaves it borderless so the input blends into the popup. */
    variant?: 'default' | 'inline';
};
/** The props Mux UI defines for CommandPalette.ClearButton; its API is the clear-button entry in the catalog's partApis. */
type CommandPaletteClearButtonOwnProps = {
    /** Marks the clear button disabled. */
    disabled?: boolean;
};
/** The props Mux UI defines for CommandPalette.Item; its API is the item entry in the catalog's partApis. */
type CommandPaletteItemOwnProps = {
    /** The item's key, which onActivate reports. */
    id?: string;
    /** The visible title, which also names the item for typeahead. */
    title?: string;
    /** Supporting text shown under the title. */
    description?: string;
    /** The text typeahead matches when the item has no title. */
    textValue?: string;
    /** Makes the item a link to this address. */
    href?: string;
    /** Where the link opens, as the anchor's target attribute. */
    target?: string;
    /** Marks the item disabled: it cannot be activated. */
    disabled?: boolean;
    /** Whether activating this item closes the palette. It follows the root's closeOnSelect when unset. */
    closeOnSelect?: boolean;
    /** Called with the item's id when the item is activated. */
    onActivate?: (event: {
        id?: string;
    }) => void;
};
/** The props Mux UI defines for CommandPalette.Shortcut; its API is the shortcut entry in the catalog's partApis. */
type CommandPaletteShortcutOwnProps = {
    /** The keys of the shortcut, each shown in a kbd element. The children show when there are none. */
    keys?: readonly string[];
};
export type CommandPaletteRootProps = HTMLAttributes<HTMLDivElement> & CommandPaletteOwnProps;
export type CommandPaletteItemProps = HTMLAttributes<HTMLDivElement> & CommandPaletteItemOwnProps;
export interface CommandPaletteCommand {
    id: string;
    title: string;
    subtitle?: string;
    keywords?: readonly string[];
    group?: string;
    icon?: ReactNode;
    shortcut?: readonly string[];
    disabled?: boolean;
    href?: string;
    target?: string;
    action?: () => void | Promise<void>;
    closeOnSelect?: boolean;
}
export interface CommandPaletteGroup<T extends CommandPaletteCommand = CommandPaletteCommand> {
    id: string;
    title: string;
    commands: readonly T[];
}
export interface UseCommandPaletteOptions<T extends CommandPaletteCommand> {
    commands: readonly T[];
    query?: string;
    defaultQuery?: string;
    onQueryChange?: (query: string) => void;
    filter?: false | ((command: T, query: string) => boolean);
    sort?: false | ((a: T, b: T, query: string) => number);
    groupBy?: (command: T) => string | null | undefined;
    getGroupTitle?: (groupId: string) => string;
    onAction?: (command: T) => void | Promise<void>;
    onError?: (error: unknown, command: T) => void;
    close?: () => void;
    closeOnSelect?: boolean;
}
export interface UseCommandPaletteReturn<T extends CommandPaletteCommand> {
    query: string;
    setQuery: (query: string) => void;
    filteredCommands: readonly T[];
    groupedCommands: readonly CommandPaletteGroup<T>[];
    runCommand: (commandOrId: T | string) => Promise<void>;
    getItemProps: (command: T) => CommandPaletteItemProps;
}
export type CommandPaletteTriggerProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    className?: string;
} & CommandPaletteTriggerOwnProps;
export type CommandPaletteBackdropProps = PartProps<HTMLDivElement> & CommandPaletteBackdropOwnProps;
export type CommandPalettePopupProps = PartProps<HTMLElement>;
export type CommandPaletteTitleProps = PartProps<HTMLHeadingElement>;
export type CommandPaletteDescriptionProps = PartProps<HTMLParagraphElement>;
export type CommandPaletteCloseProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    className?: string;
} & CommandPaletteCloseOwnProps;
export type CommandPaletteContentProps = PartProps<HTMLDivElement>;
export type CommandPaletteSearchFieldProps = HTMLAttributes<HTMLDivElement> & CommandPaletteSearchFieldOwnProps;
export type CommandPaletteInputProps = InputHTMLAttributes<HTMLInputElement>;
export type CommandPaletteClearButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    className?: string;
    onActivate?: (event: SupplementalActivation) => void;
} & CommandPaletteClearButtonOwnProps;
export type CommandPaletteItemsProps<T> = {
    items?: undefined;
    dependencies?: undefined;
    children?: ReactNode;
} | {
    items: Iterable<T>;
    dependencies?: readonly unknown[];
    children: (item: T) => ReactElement;
};
export type CommandPaletteListBoxProps<T = unknown> = Omit<PartProps<HTMLDivElement>, 'children'> & CommandPaletteItemsProps<T>;
export type CommandPaletteSectionProps<T = unknown> = Omit<PartProps<HTMLElement>, 'children'> & CommandPaletteItemsProps<T>;
export type CommandPaletteSectionHeaderProps = PartProps<HTMLElement>;
export type CommandPaletteSeparatorProps = PartProps<HTMLHRElement>;
export type CommandPaletteItemIconProps = PartProps<HTMLSpanElement>;
export type CommandPaletteItemContentProps = PartProps<HTMLDivElement>;
export type CommandPaletteItemTitleProps = PartProps<HTMLSpanElement>;
export type CommandPaletteItemDescriptionProps = PartProps<HTMLSpanElement>;
export type CommandPaletteItemMetaProps = PartProps<HTMLSpanElement>;
export type CommandPaletteShortcutProps = PartProps<HTMLSpanElement> & CommandPaletteShortcutOwnProps;
export type CommandPaletteLoadMoreItemProps = PartProps<HTMLDivElement>;
export type CommandPaletteCollectionProps<T = unknown> = CommandPaletteItemsProps<T>;
export type CommandPaletteEmptyProps = PartProps<HTMLDivElement>;
export type CommandPaletteFooterProps = PartProps<HTMLDivElement>;
export type CommandPaletteChipsProps = PartProps<HTMLDivElement>;
export type CommandPaletteChipProps = PartProps<HTMLSpanElement>;
export type CommandPaletteChipRemoveProps = ButtonHTMLAttributes<HTMLButtonElement>;
export interface CommandPaletteListBoxComponent {
    <T = unknown>(props: CommandPaletteListBoxProps<T> & RefAttributes<HTMLDivElement>): ReactElement | null;
}
export interface CommandPaletteSectionComponent {
    <T = unknown>(props: CommandPaletteSectionProps<T> & RefAttributes<HTMLElement>): ReactElement | null;
}
export interface CommandPaletteCollectionComponent {
    <T = unknown>(props: CommandPaletteCollectionProps<T>): ReactElement | null;
}
export declare function useCommandPalette<T extends CommandPaletteCommand>(options: UseCommandPaletteOptions<T>): UseCommandPaletteReturn<T>;
export declare const CommandPalette: {
    Root: ForwardRefExoticComponent<CommandPaletteRootProps & RefAttributes<HTMLDivElement>>;
    Trigger: ForwardRefExoticComponent<CommandPaletteTriggerProps & RefAttributes<HTMLButtonElement>>;
    Backdrop: ForwardRefExoticComponent<CommandPaletteBackdropProps & RefAttributes<HTMLDivElement>>;
    Popup: ForwardRefExoticComponent<CommandPalettePopupProps & RefAttributes<HTMLElement>>;
    Title: ForwardRefExoticComponent<CommandPaletteTitleProps & RefAttributes<HTMLHeadingElement>>;
    Description: ForwardRefExoticComponent<CommandPaletteDescriptionProps & RefAttributes<HTMLParagraphElement>>;
    Close: ForwardRefExoticComponent<CommandPaletteCloseProps & RefAttributes<HTMLButtonElement>>;
    Content: ForwardRefExoticComponent<CommandPaletteContentProps & RefAttributes<HTMLDivElement>>;
    SearchField: ForwardRefExoticComponent<CommandPaletteSearchFieldProps & RefAttributes<HTMLDivElement>>;
    Input: ForwardRefExoticComponent<CommandPaletteInputProps & RefAttributes<HTMLInputElement>>;
    ClearButton: ForwardRefExoticComponent<CommandPaletteClearButtonProps & RefAttributes<HTMLButtonElement>>;
    ListBox: CommandPaletteListBoxComponent;
    Section: CommandPaletteSectionComponent;
    SectionHeader: ForwardRefExoticComponent<CommandPaletteSectionHeaderProps & RefAttributes<HTMLElement>>;
    Item: ForwardRefExoticComponent<CommandPaletteItemProps & RefAttributes<HTMLDivElement>>;
    Separator: ForwardRefExoticComponent<CommandPaletteSeparatorProps & RefAttributes<HTMLHRElement>>;
    Collection: CommandPaletteCollectionComponent;
    ItemIcon: ForwardRefExoticComponent<CommandPaletteItemIconProps & RefAttributes<HTMLSpanElement>>;
    ItemContent: ForwardRefExoticComponent<CommandPaletteItemContentProps & RefAttributes<HTMLDivElement>>;
    ItemTitle: ForwardRefExoticComponent<CommandPaletteItemTitleProps & RefAttributes<HTMLSpanElement>>;
    ItemDescription: ForwardRefExoticComponent<CommandPaletteItemDescriptionProps & RefAttributes<HTMLSpanElement>>;
    ItemMeta: ForwardRefExoticComponent<CommandPaletteItemMetaProps & RefAttributes<HTMLSpanElement>>;
    Shortcut: ForwardRefExoticComponent<CommandPaletteShortcutProps & RefAttributes<HTMLSpanElement>>;
    LoadMoreItem: ForwardRefExoticComponent<CommandPaletteLoadMoreItemProps & RefAttributes<HTMLDivElement>>;
    Empty: ForwardRefExoticComponent<CommandPaletteEmptyProps & RefAttributes<HTMLDivElement>>;
    Footer: ForwardRefExoticComponent<CommandPaletteFooterProps & RefAttributes<HTMLDivElement>>;
    Chips: ForwardRefExoticComponent<CommandPaletteChipsProps & RefAttributes<HTMLDivElement>>;
    Chip: ForwardRefExoticComponent<CommandPaletteChipProps & RefAttributes<HTMLSpanElement>>;
    ChipRemove: ForwardRefExoticComponent<CommandPaletteChipRemoveProps & RefAttributes<HTMLButtonElement>>;
};
export {};

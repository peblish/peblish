// @generated-from: packages/react/src/button.ts
// @generated-content-sha256: sha256:89f8340522b1ec9b72181b60dda05a484cf5e7dcbc541eebd82f7dca6f4eb22c
import React from 'react';
import { AriaButton } from './substrate.js';
// Records keyed by the prop types, so a value added to a type must be added here too.
const BUTTON_VARIANTS = {
    primary: true, neutral: true, ghost: true, danger: true, 'danger-neutral': true, 'danger-ghost': true, inverse: true,
};
const BUTTON_SIZES = { sm: true, md: true, lg: true };
const subscribeToNothing = () => () => { };
/**
 * DOM button props that keep a pending submit button from submitting its form, or `undefined`
 * when `pending` and `type` do not call for them. Spread them onto the rendered `<button>` of
 * a React Aria Button (Button and Card.Button) after its own DOM props.
 */
export function usePendingSubmitProps(pending, type) {
    // React Aria renders a pending submit Button as type=button, but a form with one text field
    // still submits on Enter when it has no submit button. Keep type=submit so Enter clicks this
    // Button, and cancel that click along with any other click on it. A script's
    // form.requestSubmit(button) fires no click and is application code, so it is not blocked.
    // Server markup has no click handler until hydration, so a pending submit Button is natively
    // disabled until then: it cannot be clicked, and a disabled default button makes Enter submit
    // nothing. False while hydrating and true for client-only renders, so hydration finds the same markup.
    const hydrated = React.useSyncExternalStore(subscribeToNothing, () => true, () => false);
    if (!pending || type !== 'submit')
        return undefined;
    return {
        type: 'submit',
        onClick: (event) => event.preventDefault(),
        ...(hydrated ? {} : { disabled: true }),
    };
}
/**
 * Lays the caller's host attributes under the DOM props a React Aria component renders. React Aria's DOM filter keeps
 * ids, data-* attributes, its own handlers and a few named attributes, so a title, a tabIndex or most aria-* attributes
 * the component accepts in its types would never reach the element. Whatever React Aria renders still wins, with one
 * exception: the caller's tabIndex replaces React Aria's default one. autoFocus stays React Aria's, which focuses the
 * element itself. React Aria's behaviour props, which an internal caller such as TextEditor's bubble menu passes through
 * an untyped spread, are React Aria's to read and never reach the element.
 */
export function withHostAttributes(caller, domProps) {
    const { autoFocus: _autoFocus, tabIndex, ...attributes } = caller;
    for (const name of reactAriaBehaviourProps)
        delete attributes[name];
    return { ...attributes, ...domProps, ...(tabIndex === undefined ? {} : { tabIndex }) };
}
const reactAriaBehaviourProps = Object.freeze([
    'preventFocusOnPress', 'excludeFromTabOrder', 'isDisabled', 'isPending', 'routerOptions',
    'onPress', 'onPressStart', 'onPressEnd', 'onPressChange', 'onPressUp', 'onHoverStart', 'onHoverEnd', 'onHoverChange', 'onFocusChange',
]);
// Untyped callers can pass anything; Object.hasOwn alone would coerce ['primary'] or a String object to a key.
function assertButtonOption(name, value, allowed) {
    if (typeof value !== 'string' || !Object.hasOwn(allowed, value)) {
        throw new TypeError(`Button ${name} must be one of: ${Object.keys(allowed).join(', ')}`);
    }
}
/**
 * Mux UI's Button is an immediate-action control. The React Aria primitive is
 * deliberately kept behind this boundary so the public package can replace
 * its substrate without changing the MuxUI contract.
 */
export const Button = React.forwardRef(function Button({ children, className, disabled, pending, showTextWhileLoading = false, variant = 'primary', size = 'md', onActivate, type = 'button', 'aria-busy': ariaBusy, ...props }, ref) {
    assertButtonOption('variant', variant, BUTTON_VARIANTS);
    assertButtonOption('size', size, BUTTON_SIZES);
    const handlePress = (event) => {
        const activation = {
            type: 'activate',
            pointerType: event.pointerType,
            // React Aria presses on the rendered <button>.
            target: event.target,
        };
        onActivate?.(activation);
    };
    const pendingSubmitProps = usePendingSubmitProps(pending, type);
    const showPendingText = pending && showTextWhileLoading;
    const callerNamesButton = props['aria-label'] != null || props['aria-labelledby'] != null;
    const pendingContentLabelId = `muxui-button-label-${React.useId()}`;
    const labelPendingContent = pending && !showTextWhileLoading && !callerNamesButton;
    // Omit undefined state props so RAC slots can supply their own state; an explicit false still wins.
    const inheritedStateProps = {
        ...(disabled === undefined ? {} : { isDisabled: disabled }),
        ...(pending === undefined ? {} : { isPending: pending }),
    };
    const pendingAriaProps = pending === undefined && ariaBusy === undefined
        ? {}
        // A conditional, not pending || ...: extraction reads a fallback on an owned prop as an executed default.
        : { 'aria-busy': pending ? true : ariaBusy || undefined };
    const content = React.createElement('span', {
        className: ['muxui-button__label', showPendingText ? 'muxui-button__label--with-spinner' : ''].filter(Boolean).join(' '),
        id: labelPendingContent ? pendingContentLabelId : undefined,
        style: pending && !showTextWhileLoading ? { visibility: 'hidden' } : undefined,
    }, children);
    const spinner = pending ? React.createElement('svg', {
        className: ['muxui-button__spinner', showPendingText ? 'muxui-button__spinner--inline' : ''].filter(Boolean).join(' '),
        viewBox: '0 0 24 24',
        fill: 'none',
        'aria-hidden': 'true',
    }, React.createElement('circle', {
        className: 'muxui-button__spinner-track', cx: '12', cy: '12', r: '10', strokeWidth: '3',
    }), React.createElement('circle', {
        className: 'muxui-button__spinner-arc', cx: '12', cy: '12', r: '10', strokeWidth: '3', strokeLinecap: 'round',
    })) : null;
    return React.createElement(AriaButton, {
        // React Aria passes the native attributes it does not own through to the <button>; its
        // focus and keyboard handler types name Element where React's name HTMLButtonElement.
        ...props,
        ...inheritedStateProps,
        ref,
        type,
        className: ['muxui-button', className].filter(Boolean).join(' '),
        render: (domProps) => React.createElement('button', {
            ...withHostAttributes(props, domProps),
            ...(labelPendingContent && !callerNamesButton
                ? { 'aria-labelledby': pendingContentLabelId }
                : {}),
            'data-muxui-variant': variant,
            'data-muxui-size': size,
            ...pendingAriaProps,
            ...pendingSubmitProps,
        }),
        onPress: handlePress,
    }, content, spinner);
});
Button.displayName = 'Button';

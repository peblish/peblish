// @generated-from: packages/react/src/calendar.ts
// @generated-content-sha256: sha256:c1ef9446fce60d60566844cc1e9c5684715cb3239089e56d1aefe65915979f67
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUIAccessibleName, MuxUIDateRange, MuxUIDateValue } from './fields.js';
/** The props Mux UI defines for Calendar. Calendar renders no form input, description, or error message, so it submits nothing. */
export type CalendarOwnProps = {
    /** The visible label, which also names the calendar. Without one, the calendar needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** The selected date as YYYY-MM-DD, when the caller controls it. null keeps a controlled calendar empty. An empty string counts as no date, and any other string that is not a valid date throws a TypeError. */
    value?: MuxUIDateValue | null;
    /** The starting selected date as YYYY-MM-DD, when the calendar controls itself. */
    defaultValue?: MuxUIDateValue;
    /** The focused date as YYYY-MM-DD, when the caller controls it. It is separate from the selected date, and controlling it also controls the month shown. Moving focus does not select. */
    focusedValue?: MuxUIDateValue;
    /** The earliest date, inclusive, that can be focused or selected. */
    minValue?: MuxUIDateValue;
    /** The latest date, inclusive, that can be focused or selected. */
    maxValue?: MuxUIDateValue;
    /** Returns true for a date that is unavailable, given as a YYYY-MM-DD string. An unavailable date can take focus but cannot be selected. */
    unavailableDateMatcher?: (date: MuxUIDateValue) => boolean;
    /** Called with the date the user selects, as YYYY-MM-DD. It is not called while the calendar is disabled or read-only. */
    onChange?: (value?: MuxUIDateValue) => void;
    /** Called with the focused date as YYYY-MM-DD when focus moves to another date, by the arrow keys or the month buttons. It is not called while the calendar is disabled. */
    onFocusChange?: (value?: MuxUIDateValue) => void;
    /** Disables the calendar: no date can be focused or selected. */
    disabled?: boolean;
    /** Makes the calendar read-only: focus still moves between dates, but selecting a date does nothing. */
    readOnly?: boolean;
    /** Marks the calendar required. It currently has no effect on a calendar, which submits no form value. */
    required?: boolean;
    /** Forces the invalid state when true. Left false, validation follows the selected dates, so a date before minValue, after maxValue, or marked unavailable still makes the calendar invalid. */
    invalid?: boolean;
};
export type CalendarProps = Omit<CalendarOwnProps, 'label'> & {
    className?: string;
} & MuxUIAccessibleName;
/** The props Mux UI defines for RangeCalendar. RangeCalendar renders no form input, description, or error message, so it submits nothing. */
export type RangeCalendarOwnProps = {
    /** The visible label, which also names the calendar. Without one, the calendar needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** The selected range as YYYY-MM-DD start and end dates, when the caller controls it. null keeps a controlled calendar empty. A string that is not a valid date throws a TypeError. */
    value?: MuxUIDateRange | null;
    /** The starting selected range, when the calendar controls itself. */
    defaultValue?: MuxUIDateRange;
    /** The focused date as YYYY-MM-DD, when the caller controls it. It is separate from the selected range, and controlling it also controls the month shown. Moving focus does not select. */
    focusedValue?: MuxUIDateValue;
    /** The earliest date, inclusive, that can be focused or selected. */
    minValue?: MuxUIDateValue;
    /** The latest date, inclusive, that can be focused or selected. */
    maxValue?: MuxUIDateValue;
    /** Returns true for a date that is unavailable, given as a YYYY-MM-DD string. An unavailable date can take focus but cannot be selected. */
    unavailableDateMatcher?: (date: MuxUIDateValue) => boolean;
    /** Called with the range the user selects, as YYYY-MM-DD start and end dates, once both are chosen. It is not called while the calendar is disabled or read-only. */
    onChange?: (value?: MuxUIDateRange) => void;
    /** Called with the focused date as YYYY-MM-DD when focus moves to another date, by the arrow keys or the month buttons. It is not called while the calendar is disabled. */
    onFocusChange?: (value?: MuxUIDateValue) => void;
    /** Disables the calendar: no date can be focused or selected. */
    disabled?: boolean;
    /** Makes the calendar read-only: focus still moves between dates, but selecting a range does nothing. */
    readOnly?: boolean;
    /** Marks the calendar required. It currently has no effect on a calendar, which submits no form value. */
    required?: boolean;
    /** Forces the invalid state when true. Left false, validation follows the selected range, so the calendar is still invalid when either endpoint is before minValue, after maxValue, or marked unavailable. Dates between the endpoints are not checked. */
    invalid?: boolean;
};
export type RangeCalendarProps = Omit<RangeCalendarOwnProps, 'label'> & {
    className?: string;
} & MuxUIAccessibleName;
export declare const Calendar: ForwardRefExoticComponent<CalendarProps & RefAttributes<HTMLDivElement>>;
export declare const RangeCalendar: ForwardRefExoticComponent<RangeCalendarProps & RefAttributes<HTMLDivElement>>;

// @generated-from: packages/react/src/color-slider.ts
// @generated-content-sha256: sha256:32dc288c242a6d6b1048c1b9ecffdbe50ffac100a0cc8b51e2102cb9926dbd08
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUIColorChannel, MuxUIColorSpace, MuxUIColorValue } from './color-context.js';
import type { MuxUIAccessibleName } from './fields.js';
/** The props Mux UI defines for ColorSlider. The slider is named by label, aria-label, or aria-labelledby. */
export type ColorSliderOwnProps = {
    /** The visible label, which also names the slider. Without one, the slider needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** The slider's color, when the caller controls it. */
    value?: MuxUIColorValue;
    /** The starting color, when the slider controls itself. */
    defaultValue?: MuxUIColorValue;
    /** Called with the new color as a CSS string each time the channel changes. It is in the slider's color space when colorSpace is set, and otherwise in the space of the value, the enclosing ColorPicker, or defaultValue. A disabled or read-only slider does not call it. */
    onChange?: (value: MuxUIColorValue) => void;
    /** The channel the slider adjusts. It must belong to colorSpace or, without colorSpace, to the space of the enclosing ColorPicker's color, otherwise of value or defaultValue; any other pair throws a TypeError. */
    channel?: MuxUIColorChannel;
    /** The color space the slider reads and reports in. Without it the slider uses the enclosing ColorPicker's space, otherwise the space of the value. */
    colorSpace?: MuxUIColorSpace;
    /** Disables the slider: it can be neither focused nor changed. A disabled enclosing ColorPicker disables it too. */
    disabled?: boolean;
    /** Makes the slider read-only: it stays focusable but its channel cannot be changed. A read-only enclosing ColorPicker does the same. */
    readOnly?: boolean;
    /** The direction of the track. */
    orientation?: 'horizontal' | 'vertical';
};
export type ColorSliderProps = Omit<ColorSliderOwnProps, 'label'> & {
    className?: string;
} & MuxUIAccessibleName;
export declare const ColorSlider: ForwardRefExoticComponent<ColorSliderProps & RefAttributes<HTMLDivElement>>;

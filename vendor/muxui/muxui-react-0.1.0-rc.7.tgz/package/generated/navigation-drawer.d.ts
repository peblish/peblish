// @generated-from: packages/react/src/supplemental/navigation-drawer.ts
// @generated-content-sha256: sha256:10dcbfb7728f07f3533bafdadcbbc95a9642584910078cf691add2c342b30293
/** Where focus can be sent: a rendered element, or nothing. */
type Focusable = HTMLElement | null | undefined;
export declare const sidebarUnreachable: (node: Element) => boolean;
/** Focuses the first candidate that is rendered and really takes focus, and says whether one did; a Root reached this way gets a tabindex only then. */
export declare function sidebarFocusFirst(candidates: Iterable<Focusable>, roots: ReadonlySet<Element>): boolean;
/**
 * Hands lost focus over to the first candidate that takes it, retrying on animation frames for about half a second:
 * an overlay that is still closing keeps the target inert. It only acts while focus is lost, on nothing, on the body,
 * or on `stale` content, so a newer deliberate focus is never overwritten.
 */
export declare function sidebarHandoff(candidates: () => Iterable<Focusable>, roots: ReadonlySet<Element>, stale: (active: Element) => unknown): void;
/** Runs `exit` once the drawer content unmounts, after any exit animation. */
export declare function SidebarDrawerExit({ exit }: {
    exit: () => void;
}): null;
export {};

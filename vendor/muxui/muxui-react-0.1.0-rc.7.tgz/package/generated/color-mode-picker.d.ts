// @generated-from: packages/react/src/supplemental/color-mode-picker.ts
// @generated-content-sha256: sha256:57cd928252227da3d2428b829ea6b7bf87d16780fc2d5d0825b5cc6574a84556
import type { ForwardRefExoticComponent, RefAttributes } from 'react';
import type { ColorModeChoice } from './color-mode.js';
export type { ColorModeChoice };
/**
 * The props Mux UI defines for ColorModePicker; the catalog's web.react API is derived from this type (Decision 0031).
 * The picker is named by aria-label or aria-labelledby, and by Color mode when it has neither.
 */
type ColorModePickerOwnProps = {
    /** The color mode, when the page controls it. System follows the operating system's preference. */
    mode?: ColorModeChoice;
    /** The mode the picker starts in, before a saved mode is read. Without one it starts on System. */
    defaultMode?: ColorModeChoice;
    /** The localStorage key a light or dark choice is saved under, and System removes. */
    storageKey?: string;
    /** Disables the picker and every option in it. */
    disabled?: boolean;
    /** Called with the new mode when the user changes it. */
    onModeChange?: (mode: ColorModeChoice) => void;
};
export type ColorModePickerProps = ColorModePickerOwnProps & {
    className?: string;
    'aria-label'?: string;
    'aria-labelledby'?: string;
};
export declare const ColorModePicker: ForwardRefExoticComponent<ColorModePickerProps & RefAttributes<HTMLDivElement>>;

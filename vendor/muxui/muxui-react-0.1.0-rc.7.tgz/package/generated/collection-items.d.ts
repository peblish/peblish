// @generated-from: packages/react/src/collection-items.ts
// @generated-content-sha256: sha256:20e6dcf74c81e8016c274c84523d0211e6c40c4f19aac06ca235f0ee23e3a6c6
import type { ReactNode } from 'react';
import type { MuxUIAriaAccessibleName } from './fields.js';
/** An item a collection renders from data. Other string-keyed fields are consumer data. */
export interface MuxUICollectionItem {
    id?: string;
    key?: string;
    label?: ReactNode;
    /** Consumer data; named Select and ComboBox forms submit the item `id`, not `value`. */
    value?: string;
    textValue?: string;
    disabled?: boolean;
    [key: string]: unknown;
}
export type MuxUISelection = string[] | 'all';
export type MuxUIItems = (MuxUICollectionItem | string)[];
export type CollectionProps = MuxUIAriaAccessibleName & {
    items?: MuxUIItems;
    selectedIds?: MuxUISelection;
    defaultSelectedIds?: MuxUISelection;
    disabled?: boolean;
    selectionMode?: 'none' | 'single' | 'multiple';
    onSelectionChange?: (ids: MuxUISelection) => void;
    onAction?: (item?: MuxUICollectionItem) => void;
    className?: string;
};
/** An item once `normalizeItems` has given it the fields the collection families read. */
export interface NormalizedItem extends MuxUICollectionItem {
    id: string;
    key: string;
    label: ReactNode;
    value: string;
    textValue: string;
}
export declare function textContent(value: unknown): string;
export declare function normalizeItems(items?: MuxUIItems): NormalizedItem[];
export declare function keySet(value: MuxUISelection | undefined): Set<string> | 'all' | undefined;
export declare function keyList(value: 'all' | Iterable<string | number> | null | undefined): MuxUISelection;
export declare function collectionItem(id: string | number): MuxUICollectionItem;

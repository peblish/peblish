// @generated-from: packages/react/src/supplemental/tag-select.ts
// @generated-content-sha256: sha256:7911216c5698bba38847d57360c1b258f948caa8a02ff5c0df0c9e65d478dc44
import type { ForwardRefExoticComponent, HTMLAttributes, Key, ReactElement, ReactNode, RefAttributes } from 'react';
/** An item TagSelect lists: a key, and whatever else the caller keeps on it. */
export type TagSelectItem = {
    id: Key;
    [key: string]: unknown;
};
/**
 * The props Mux UI defines for TagSelect.Root, the compound's root; the catalog's web.react API is derived from
 * this type (Decision 0031). It is generic over the item the caller lists, as the public type is, and the catalog
 * records the item at its constraint. The members every field shares are written out, because the catalog's grammar
 * reads only the members a type lists itself.
 */
type TagSelectOwnProps<T extends TagSelectItem = TagSelectItem> = {
    /** The control size. */
    size?: 'sm' | 'md' | 'lg';
    /** The visible label, which also names the field. */
    label?: ReactNode;
    /** The text shown in the input while no tag is selected. */
    placeholder?: string;
    /** Supporting text shown below the field. */
    description?: ReactNode;
    /** The message shown, in place of the description, while the field is invalid. */
    errorMessage?: ReactNode;
    /** Marks the field disabled. */
    disabled?: boolean;
    /** Marks a selection as required. */
    required?: boolean;
    /** Marks the field invalid. */
    invalid?: boolean;
    /** The items to choose from. */
    items?: T[];
    /** The selected keys, when the caller controls them. */
    selectedKeys?: Set<Key>;
    /** The keys selected at first, when the field keeps its own selection. */
    defaultSelectedKeys?: Set<Key>;
    /** Called with the new selection each time a tag is added or removed. */
    onSelectionChange?: (keys: Set<Key>) => void;
    /** The text of an item's tag and of its option; an item's name, label, or id when omitted. */
    getItemLabel?: (item: T) => string;
};
export type TagSelectProps<T extends TagSelectItem = TagSelectItem> = Omit<HTMLAttributes<HTMLDivElement>, 'children'> & TagSelectOwnProps<T> & {
    children?: ReactNode | ((item: T) => ReactNode);
    readOnly?: boolean;
};
export type TagSelectRootProps<T extends TagSelectItem = TagSelectItem> = TagSelectProps<T>;
/** The props Mux UI defines for TagSelect.Item; its API is the item entry in the catalog's partApis. */
type TagSelectItemOwnProps = {
    /** Marks the item disabled: it cannot be selected. */
    disabled?: boolean;
    /** The text that search and typeahead match, when the item's content is not plain text. */
    textValue?: string;
};
export type TagSelectItemProps = HTMLAttributes<HTMLDivElement> & TagSelectItemOwnProps;
export interface TagSelectRootComponent {
    <T extends TagSelectItem = TagSelectItem>(props: TagSelectRootProps<T> & RefAttributes<HTMLDivElement>): ReactElement | null;
}
export declare const TagSelect: {
    Root: TagSelectRootComponent;
    Item: ForwardRefExoticComponent<TagSelectItemProps & RefAttributes<HTMLDivElement>>;
};
export {};

// @generated-from: packages/react/src/supplemental/prompt-composer.ts
// @generated-content-sha256: sha256:31a1df1c5b365fbfa16dba5f0e70566fc35c10c2aaec484e51b1491f13e7a545
import type { ForwardRefExoticComponent, FormHTMLAttributes, ReactNode, Ref, RefAttributes, TextareaHTMLAttributes } from 'react';
export type PromptComposerSuggestion = {
    id: string;
    label: string;
    description?: string;
    insertText?: string;
};
export type PromptComposerAttachment = {
    id: string;
    label: string;
};
export type PromptComposerModel = {
    id: string;
    label: string;
};
/**
 * The props Mux UI defines for PromptComposer; the catalog's web.react API is derived from this type
 * (Decision 0031). It is a type literal, so the public props type stays assignable to Record<string, unknown>,
 * as it was before the move, and it is not exported: this module is re-exported whole, so exporting it would add
 * it to the package's surface. Every other attribute of a form passes through to the form, and `inputRef`, a ref,
 * stays in the public type beside it. The form's own `submit`, `change`, and `reset` events are native events the
 * form passes through, so they are not Mux UI-owned. Cancelling `submit` stops `onSend`, and cancelling `reset`
 * stops the composer restoring its text and model.
 */
type PromptComposerOwnProps = {
    /** The accessible name of the textarea, when `inputProps` gives it neither an `aria-label` nor an `aria-labelledby`. */
    inputLabel?: string;
    /** The text, when the caller controls it. */
    value?: string;
    /** The text at first, when the composer controls itself. A form reset restores it. */
    defaultValue?: string;
    /** Called with the new text each time it changes. */
    onValueChange?: (value: string) => void;
    /** Native textarea props. `form` associates text and Send with that external form's validation, submission and reset. */
    inputProps?: Omit<TextareaHTMLAttributes<HTMLTextAreaElement>, 'value' | 'defaultValue' | 'children' | 'dangerouslySetInnerHTML'>;
    /** Runs only when the composer host form receives an uncancelled submission, with the text. */
    onSend?: (value: string) => void;
    /** Called when Stop is pressed. Stop replaces Send while `pending`, and shows only with this callback. */
    onStop?: () => void;
    /** Makes the text read-only and disables the auxiliary actions. Stop replaces Send when `onStop` is given. */
    pending?: boolean;
    /** Prevents all editing and actions. */
    disabled?: boolean;
    /** A message shown with the composer, associated with the textarea and announced; it also marks the textarea invalid. */
    error?: ReactNode;
    /** The records a caret token beginning with @ at a word boundary suggests. Up and Down choose, Enter inserts, and Escape dismisses. */
    sources?: readonly PromptComposerSuggestion[];
    /** The records a caret token beginning with / at a word boundary suggests. Up and Down choose, Enter inserts, and Escape dismisses. */
    commands?: readonly PromptComposerSuggestion[];
    /** Called with the chosen record and its kind when a suggestion is inserted. Insertion replaces only the current token, respects `maxLength`, and never sends. */
    onSuggestionSelect?: (item: PromptComposerSuggestion, kind: 'source' | 'command') => void;
    /** Display records for the files attached. Each shows with a remove button when `onRemoveAttachment` is given. */
    attachments?: readonly PromptComposerAttachment[];
    /** Called with the id of an attachment whose remove button was pressed. */
    onRemoveAttachment?: (id: string) => void;
    /** Shows an attach button that opens a native file picker, and receives the chosen files. Nothing is uploaded. */
    onFilesSelected?: (files: File[]) => void;
    /** The file types the attach picker accepts, as the native input's `accept`. */
    accept?: string;
    /** Whether the attach picker admits several files. */
    multiple?: boolean;
    /** The models the picker offers. It renders only with `models` and `onModelChange`. */
    models?: readonly PromptComposerModel[];
    /** The id of the selected model, when the caller controls it. */
    selectedModel?: string;
    /** The id of the model selected at first, when the composer controls itself; without one, the first model. A form reset restores it. */
    defaultSelectedModel?: string;
    /** Called with the id of the chosen model. */
    onModelChange?: (id: string) => void;
    /** Shows a dictation button that calls this when pressed. Mux UI performs no recognition. */
    onDictation?: () => void;
};
export type PromptComposerProps = Omit<FormHTMLAttributes<HTMLFormElement>, 'children' | 'dangerouslySetInnerHTML' | 'defaultValue'> & PromptComposerOwnProps & {
    inputRef?: Ref<HTMLTextAreaElement>;
};
/** Native form host; Enter submits through native validation, Shift+Enter adds a line. Presentation and local editing only: files, models, requests and dictation stay caller-owned. */
export declare const PromptComposer: ForwardRefExoticComponent<PromptComposerProps & RefAttributes<HTMLFormElement>>;
export {};

// @generated-from: packages/react/src/supplemental/part-utils.ts
// @generated-content-sha256: sha256:3e4d745e58738a6977a7246c5e8e915d397655afb0d8d0810b85660029166cd3
import type { ButtonHTMLAttributes, ForwardedRef, HTMLAttributes, ReactElement, ReactNode, createElement, useEffect } from 'react';
export declare const h: typeof createElement;
export declare const useIsomorphicLayoutEffect: typeof useEffect;
export declare function cx(...values: unknown[]): string;
export declare function dataState(value: unknown): "" | undefined;
/** The native props of a part: its element's attributes, and a className. */
export type PartProps<T extends HTMLElement = HTMLElement> = HTMLAttributes<T> & {
    className?: string;
};
/** Renders `tag` with the part's native props, its base class first, then the caller's className. */
export declare function nativePart<E extends HTMLElement>(tag: string, base: string, props: PartProps<E> | null | undefined, ref: ForwardedRef<E>, children?: ReactNode): ReactElement;
/** The activation a press reports: the pointer and target of the event that caused it. */
export type SupplementalActivation = {
    type: 'activate';
    pointerType?: string;
    target?: EventTarget | null;
};
/** The native props of a button part: its attributes, a disabled flag, `onActivate`, and a className. */
export type ButtonPartProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    disabled?: boolean;
    onActivate?: (event: SupplementalActivation) => void;
    className?: string;
};
/** The state and size props the field compounds share. */
export type SupplementalFieldProps = {
    disabled?: boolean;
    invalid?: boolean;
    required?: boolean;
    readOnly?: boolean;
    size?: 'sm' | 'md' | 'lg';
};
export declare function pressHandler(onActivate?: (event: SupplementalActivation) => void): ((event?: {
    pointerType?: string;
    target?: EventTarget | null;
}) => void) | undefined;

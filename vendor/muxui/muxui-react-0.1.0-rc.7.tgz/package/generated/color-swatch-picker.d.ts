// @generated-from: packages/react/src/color-swatch-picker.ts
// @generated-content-sha256: sha256:84469156166e03b2b9de324df99f9ff2c1b693198c7489e48899c025a601c54e
import type { ForwardRefExoticComponent, RefAttributes } from 'react';
import type { MuxUIItems } from './collection-items.js';
import type { MuxUIColorValue } from './color-context.js';
import type { MuxUIAriaAccessibleName } from './fields.js';
/** The props Mux UI defines for ColorSwatchPicker. It takes no `name` and does not submit with a form; use a named ColorField to submit a color. */
export type ColorSwatchPickerOwnProps = {
    /** The swatches as data: color strings, or items whose `color` or `value` is a valid CSS color string. Each item needs a distinct color, because options are keyed by color, and duplicate colors throw a TypeError. An item's `label` or `textValue` names its swatch; otherwise the swatch uses its color name. */
    items?: MuxUIItems;
    /** The selected color, when the caller controls it. `null` is controlled and empty; `undefined` leaves the value uncontrolled. */
    value?: MuxUIColorValue | null;
    /** The color selected at first, when the picker controls itself. */
    defaultValue?: MuxUIColorValue;
    /** Disables the picker and every swatch. A disabled enclosing ColorPicker disables it too. */
    disabled?: boolean;
    /** Makes the picker read-only: arrow keys still move focus between swatches, but presses, Space, and Enter do not select one. A read-only enclosing ColorPicker does the same. */
    readOnly?: boolean;
    /** Called with the selected swatch's color as a CSS string in that swatch's color space: rgba(r, g, b, a) for a hex or RGB swatch, and hsla(h, s%, l%, a) for an HSL or HSB swatch. A disabled or read-only picker does not call it. */
    onChange?: (value: MuxUIColorValue) => void;
};
export type ColorSwatchPickerProps = ColorSwatchPickerOwnProps & {
    className?: string;
} & MuxUIAriaAccessibleName;
export declare const ColorSwatchPicker: ForwardRefExoticComponent<ColorSwatchPickerProps & RefAttributes<HTMLDivElement>>;

// @generated-from: packages/react/src/control-utils.ts
// @generated-content-sha256: sha256:dd2cee3b1fc2a9383fee5389385a5579e853abace749ee97d9bf65ae1e5510da
/** The base class followed by the caller's `className`, leaving out whichever is empty. */
export function classNames(base, className) {
    return [base, className].filter(Boolean).join(' ');
}
/** Throws unless the control has a visible label, an `aria-label`, or an `aria-labelledby`; an empty label does not count. */
export function accessibleName(props, componentName) {
    const { label, ariaLabel, ariaLabelledby } = props;
    if ((label === undefined || label === null || label === '') && !ariaLabel && !ariaLabelledby) {
        throw new TypeError(`${componentName} requires label, aria-label, or aria-labelledby`);
    }
}

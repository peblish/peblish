// @generated-from: packages/react/src/supplemental/card.ts
// @generated-content-sha256: sha256:85d74877fc1d0738de215205910b09dff51440578a1b039566ea7b32e2734d40
import type { ButtonHTMLAttributes, ForwardRefExoticComponent, HTMLAttributes, RefAttributes } from 'react';
import type { PartProps, SupplementalActivation } from './part-utils.js';
export type CardVariant = 'elevated' | 'outlined' | 'filled';
export type CardPadding = 'sm' | 'md' | 'lg';
/**
 * The props Mux UI defines for Card.Root, the compound's root; the catalog's web.react API is derived from
 * this type (Decision 0031). Button owns the same two and more, in CardButtonOwnProps. Both are type literals,
 * not interfaces, so the public props types stay assignable to Record<string, unknown>, as they were before the move.
 */
type CardOwnProps = {
    /** The card's surface: raised, outlined or filled. */
    variant?: CardVariant;
    /** The space inside the card. */
    padding?: CardPadding;
};
/** The props Mux UI defines for Card.Button; its API is the button entry in the catalog's partApis. */
type CardButtonOwnProps = {
    /** The card's surface: raised, outlined or filled. */
    variant?: CardVariant;
    /** The space inside the card. */
    padding?: CardPadding;
    /** Marks the card as the chosen one, as aria-pressed. */
    selected?: boolean;
    /** Marks the card busy: it ignores presses until the work finishes. */
    pending?: boolean;
    /** Marks the card disabled. */
    disabled?: boolean;
    /** Called when the card is pressed. */
    onActivate?: (event: SupplementalActivation) => void;
};
export type CardRootProps = HTMLAttributes<HTMLDivElement> & CardOwnProps;
export type CardButtonProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    className?: string;
} & CardButtonOwnProps;
export type CardHeaderProps = PartProps<HTMLDivElement>;
export type CardBodyProps = PartProps<HTMLDivElement>;
export type CardFooterProps = PartProps<HTMLDivElement>;
export declare const Card: {
    Root: ForwardRefExoticComponent<CardRootProps & RefAttributes<HTMLDivElement>>;
    Button: ForwardRefExoticComponent<CardButtonProps & RefAttributes<HTMLButtonElement>>;
    Header: ForwardRefExoticComponent<PartProps<HTMLDivElement> & RefAttributes<HTMLDivElement>>;
    Body: ForwardRefExoticComponent<PartProps<HTMLDivElement> & RefAttributes<HTMLDivElement>>;
    Footer: ForwardRefExoticComponent<PartProps<HTMLDivElement> & RefAttributes<HTMLDivElement>>;
};
export {};

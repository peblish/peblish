// @generated-from: packages/react/src/list-box.ts
// @generated-content-sha256: sha256:006cfcba522afc956a66226e095731d5e5f55e77a56c87f4d42e735bee050805
import type { CSSProperties, ForwardRefExoticComponent, HTMLAttributes, ReactNode, RefAttributes } from 'react';
import type { MuxUICollectionItem, MuxUIItems, MuxUISelection } from './collection-items.js';
import type { MuxUIAriaAccessibleName } from './fields.js';
/** The props Mux UI defines for ListBox. ListBox has no `name` and submits nothing. */
export type ListBoxOwnProps = {
    /** The options as data: strings, or items with an `id`, a `label`, a `textValue`, and `disabled`. Children take precedence: when both are supplied, the items are not rendered. */
    items?: MuxUIItems;
    /** The selected item ids when the caller controls the selection, or `'all'`. */
    selectedIds?: MuxUISelection;
    /** The ids selected at first when the list controls its own selection, or `'all'`. */
    defaultSelectedIds?: MuxUISelection;
    /** Disables every item and stops the selection and action callbacks. An item's own `disabled={false}` cannot re-enable it under a disabled list. */
    disabled?: boolean;
    /** How many items can be selected. With `single`, pressing the selected item again clears the selection, so the list can end with nothing selected. */
    selectionMode?: 'none' | 'single' | 'multiple';
    /** Called with the selected item ids, or `'all'`, when the selection changes. It is not called while the list is disabled. */
    onSelectionChange?: (ids: MuxUISelection) => void;
    /** Called when the user activates an item. A list built from `items` passes the item record; one built from children passes the identity fields `id`, `key`, and `value`. It is not called for a disabled item or while the list is disabled. */
    onAction?: (item?: MuxUICollectionItem) => void;
    /** `stack` navigates along the orientation. `grid` uses the items' actual positions for two-dimensional arrow navigation, and the columns and sizes come from CSS or `style`. */
    layout?: 'stack' | 'grid';
    /** The direction arrow keys move along a stack layout. */
    orientation?: 'vertical' | 'horizontal';
};
export type ListBoxProps = ListBoxOwnProps & {
    children?: ReactNode;
    style?: CSSProperties;
    className?: string;
} & MuxUIAriaAccessibleName;
/** The props Mux UI defines for ListBox.Item. Every other attribute of a div passes through to the option. */
export type ListBoxItemOwnProps = {
    /** The stable string id the selection and action callbacks report. */
    id: string;
    /** The text typeahead matches. Without one it is the text of the item's children, which is unambiguous only for plain text, so give rich children a `textValue`. */
    textValue?: string;
    /** Disables the item. A disabled list disables every item whatever this says. */
    disabled?: boolean;
};
export type ListBoxItemProps = Omit<HTMLAttributes<HTMLDivElement>, 'id'> & ListBoxItemOwnProps;
/** The props Mux UI defines for ListBox.Section. Every other attribute of a section passes through to it. */
export type ListBoxSectionOwnProps = {
    /** The visible heading of the section, rendered in a ListBox.Header. Without one, name the section with `aria-label`. */
    title?: ReactNode;
};
export type ListBoxSectionProps = Omit<HTMLAttributes<HTMLElement>, 'title'> & ListBoxSectionOwnProps;
type ListBoxComponent = ForwardRefExoticComponent<ListBoxProps & RefAttributes<HTMLDivElement>> & {
    Root: ForwardRefExoticComponent<ListBoxProps & RefAttributes<HTMLDivElement>>;
    Section: ForwardRefExoticComponent<ListBoxSectionProps & RefAttributes<HTMLElement>>;
    Header: ForwardRefExoticComponent<HTMLAttributes<HTMLElement> & RefAttributes<HTMLElement>>;
    Item: ForwardRefExoticComponent<ListBoxItemProps & RefAttributes<HTMLDivElement>>;
};
export declare const ListBox: ListBoxComponent;
export {};

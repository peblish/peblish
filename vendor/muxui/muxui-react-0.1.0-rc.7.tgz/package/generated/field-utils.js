// @generated-from: packages/react/src/supplemental/field-utils.ts
// @generated-content-sha256: sha256:d17cc3d2bb080640c8d0ff19c1ae54af63f3ea33a0b7bdbe94b8294939c2f0ea
import { Text as AriaText } from 'react-aria-components';
import { h, cx } from './part-utils.js';
export function fieldText(slot, className, props, ref) {
    return h(AriaText, { ...props, ref, slot, className: cx(className, props?.className) });
}
/** The props without the four flags, plus the renamed flags as `is`-prefixed booleans. */
export function mappedFieldProps({ disabled, invalid, required, readOnly, ...props }) {
    return {
        ...props,
        isDisabled: disabled,
        isInvalid: invalid,
        isRequired: required,
        isReadOnly: readOnly,
    };
}

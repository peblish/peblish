// @generated-from: packages/react/src/color-picker.ts
// @generated-content-sha256: sha256:e9d32680fe57862e118fdd5b8aee5f83d467a8d8a1e0e18d37aaef4c9097db9a
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUIColorValue } from './color-context.js';
/**
 * The props Mux UI defines for ColorPicker. Its children are the color controls it shares one color
 * with, and className styles its wrapper.
 */
export type ColorPickerOwnProps = {
    /** The picker's color, when the caller controls it. The picker keeps its color in this value's color space. */
    value?: MuxUIColorValue;
    /** The starting color, when the picker controls itself. It also sets the color space the picker keeps its color in. */
    defaultValue?: MuxUIColorValue;
    /** Called with the new color as a CSS string each time a color control inside changes it, in the color space of the value, or of defaultValue when uncontrolled, and in rgba() form with neither. A disabled or read-only picker does not call it. */
    onChange?: (value: MuxUIColorValue) => void;
    /** Disables every Mux UI color control inside the picker, at any depth. A child cannot turn it off, and native elements inside are not affected. */
    disabled?: boolean;
    /** Makes every Mux UI color control inside the picker read-only, at any depth. A child cannot turn it off, and native elements inside are not affected. */
    readOnly?: boolean;
};
export type ColorPickerProps = ColorPickerOwnProps & {
    children?: ReactNode;
    className?: string;
};
export declare const ColorPicker: ForwardRefExoticComponent<ColorPickerProps & RefAttributes<HTMLDivElement>>;

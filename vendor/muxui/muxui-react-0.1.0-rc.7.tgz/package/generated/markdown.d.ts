// @generated-from: packages/react/src/markdown/index.ts
// @generated-content-sha256: sha256:12c3997d7c58cfc1b2f43772e726986be2e4c38e619003dfda7fc1174a4b3c5a
import type { ForwardRefExoticComponent, HTMLAttributes, ReactNode, RefAttributes } from 'react';
/** Longest accepted source, in UTF-16 code units. */
export declare const MARKDOWN_SOURCE_LIMIT: number;
/** Most lines accepted in a source. A trailing newline starts a final blank line. */
export declare const MARKDOWN_LINE_LIMIT: number;
/** Longest accepted single line, in UTF-16 code units. */
export declare const MARKDOWN_LINE_LENGTH_LIMIT: number;
/** Deepest accepted nesting of block and inline structure. */
export declare const MARKDOWN_DEPTH_LIMIT: number;
/** Most parsed nodes accepted. */
export declare const MARKDOWN_NODE_LIMIT: number;
/**
 * The props Mux UI defines for Markdown; the catalog's web.react API is derived from this
 * type (Decision 0031). It is a type literal, as the props were before the move.
 */
type MarkdownOwnProps = {
    /** The Markdown to render. Raw HTML is dropped, and a source over one of the exported limits is replaced by invalidFallback. */
    source: string;
    /** The absolute HTTP(S) URL, with no username or password, that relative links and images resolve against. Without it, relative links and images are not allowed. */
    baseUrl?: string;
    /** What replaces the whole content when baseUrl is invalid or the source fails a limit. */
    invalidFallback?: ReactNode;
};
export type MarkdownProps = HTMLAttributes<HTMLDivElement> & MarkdownOwnProps;
/** Renders a bounded Markdown subset. Raw HTML and unsafe URLs are removed. */
export declare const Markdown: ForwardRefExoticComponent<MarkdownProps & RefAttributes<HTMLDivElement>>;
export {};

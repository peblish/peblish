// @generated-from: packages/react/src/supplemental/sidebar.ts
// @generated-content-sha256: sha256:9ec52dacbecfc4faae6b2777b7748b7cdf0dcfb8ca3ade2aac43c60ab3773332
import type { AnchorHTMLAttributes, ChangeEventHandler, ComponentType, ForwardRefExoticComponent, HTMLAttributes, ReactNode, RefAttributes } from 'react';
import type { MuxUICollectionItem, MuxUIItems } from './collection-items.js';
import type { MenuListProps } from './menu.js';
import type { IconButtonProps } from './icon-button.js';
import type { PartProps } from './part-utils.js';
/**
 * The props Mux UI defines for Sidebar.Root, the compound's root; the catalog's web.react API is derived from
 * this type (Decision 0031). Provider, Search, Section, NavItem, NavButton, AccountCard, AccountMenu, MobileTrigger and
 * FeatureCard define theirs in the OwnProps types below, and Toggle, Header, Divider and NavList define none.
 * They are type literals, not interfaces, so the public props types stay assignable to Record<string, unknown>.
 */
type SidebarOwnProps = {
    /** Removes the border on the column's edge. */
    hideBorder?: boolean;
    /** `compact` tightens nav rows, gaps, section labels, and nesting; text sizes and focus rings are unchanged. */
    density?: 'default' | 'compact';
};
/** The props Mux UI defines for Sidebar.Provider; its API is the provider entry in the catalog's partApis. */
type SidebarProviderOwnProps = {
    /** Folded state; supply it with `onCollapsedChange` to control the rail. */
    collapsed?: boolean;
    /** Whether the rail starts folded, when it controls itself. */
    defaultCollapsed?: boolean;
    /** Called with the new folded state each time the rail folds or unfolds. */
    onCollapsedChange?: (collapsed: boolean) => void;
    /** A key that toggles the rail with Cmd on macOS or Ctrl elsewhere; ignored while typing in a text field or editor. */
    shortcut?: string;
};
/** The props Mux UI defines for Sidebar.Search; its API is the search entry in the catalog's partApis. */
type SidebarSearchOwnProps = {
    /** The input's placeholder and accessible name; folded, it also names the button that unfolds the rail. */
    placeholder?: string;
    /** The input's value, when the caller controls it. */
    value?: string;
    /** Called with the change event of the input each time its value changes. */
    onChange?: ChangeEventHandler<HTMLInputElement>;
};
/** The props Mux UI defines for Sidebar.Section; its API is the section entry in the catalog's partApis. */
type SidebarSectionOwnProps = {
    /** The section's visible heading, which also names its list. */
    label: ReactNode;
};
/** The icon a nav item or button draws: a component that takes a class name, such as one from an icon library. */
type SidebarIconProps = {
    className?: string;
};
/** Open state shared by every nav group: supply `expanded` with `onExpandedChange` to control it, or `defaultExpanded` to start it open. */
export type SidebarExpandedProps = {
    /** Whether the group is open, when the caller controls it. */
    expanded?: boolean;
    /** Whether the group starts open, when it controls itself. */
    defaultExpanded?: boolean;
    /** Called with the new open state each time the group opens or closes. */
    onExpandedChange?: (expanded: boolean) => void;
};
/**
 * A nested nav entry. An entry with `items` and no `href` is a disclosure group; with both, it is a link beside a
 * toggle button. `id` is a stable React key and defaults to `href`.
 */
export type SidebarNavEntry = {
    expanded?: boolean;
    defaultExpanded?: boolean;
    onExpandedChange?: (expanded: boolean) => void;
    id?: string;
    label: ReactNode;
    current?: boolean;
    href: string;
    items?: SidebarNavEntry[];
} | {
    expanded?: boolean;
    defaultExpanded?: boolean;
    onExpandedChange?: (expanded: boolean) => void;
    id?: string;
    label: ReactNode;
    current?: boolean;
    href?: string;
    items: SidebarNavEntry[];
};
/** The props Mux UI defines for Sidebar.NavItem; its API is the nav-item entry in the catalog's partApis. */
type SidebarNavItemOwnProps = {
    /** The destination. Without it, `items` make a disclosure group. */
    href?: string;
    /** An icon drawn before the label. Folded, an item without one keeps the first character of its label. */
    icon?: ComponentType<SidebarIconProps>;
    /** A count or short mark shown after the label. */
    badge?: ReactNode;
    /** Marks the item's page with `aria-current="page"`; on a group without `href` it only styles the header. */
    current?: boolean;
    /** The entries nested under the item. */
    items?: SidebarNavEntry[];
    /** Marks the link as leaving the application, with an icon that says so. */
    external?: boolean;
    /** Whether the group is open, when the caller controls it. */
    expanded?: boolean;
    /** Whether the group starts open, when it controls itself. */
    defaultExpanded?: boolean;
    /** Called with the new open state each time the group opens or closes. */
    onExpandedChange?: (expanded: boolean) => void;
};
/** The props Mux UI defines for Sidebar.NavButton; its API is the nav-button entry in the catalog's partApis. */
type SidebarNavButtonOwnProps = {
    /** An icon drawn inside the button. */
    icon?: ComponentType<SidebarIconProps>;
    /** The button's accessible name. */
    label?: string;
    /** Marks the link as the current page: it is styled as such. */
    current?: boolean;
};
/** The props Mux UI defines for Sidebar.AccountCard; its API is the account-card entry in the catalog's partApis. */
type SidebarAccountCardOwnProps = {
    /** The account's name. */
    name: string;
    /** The account's email address. */
    email: string;
    /** The avatar image. Without it, the card shows the first letter of the name. */
    avatarSrc?: string;
    /** The avatar image's text alternative; without it, the name. */
    avatarAlt?: string;
    /** Marks the account online or offline with a dot on the avatar. */
    status?: 'online' | 'offline';
};
/** The props Mux UI defines for Sidebar.AccountMenu; its API is the account-menu entry in the catalog's partApis. */
type SidebarAccountMenuOwnProps = {
    /** The menu's options as data, as Menu.List takes them. Children take precedence. */
    items?: MuxUIItems;
    /** Called when the user activates an option, with the item record for a list built from `items`. */
    onAction?: (item?: MuxUICollectionItem) => void;
};
/** The props Mux UI defines for Sidebar.MobileTrigger; its API is the mobile-trigger entry in the catalog's partApis. */
type SidebarMobileTriggerOwnProps = {
    /** A mark or name shown beside the button that opens the drawer. */
    logo?: ReactNode;
};
/** The props Mux UI defines for Sidebar.FeatureCard; its API is the feature-card entry in the catalog's partApis. */
type SidebarFeatureCardOwnProps = {
    /** The card's heading. */
    title?: string;
    /** The card's supporting text. */
    description?: string;
    /** The dismiss button's label. */
    dismissLabel?: string;
    /** Called when the dismiss button is pressed; without it the card has no button. */
    onDismiss?: () => void;
};
export type SidebarProps = HTMLAttributes<HTMLElement> & SidebarOwnProps;
export type SidebarProviderProps = SidebarProviderOwnProps & {
    children?: ReactNode;
};
/** Names the control "Toggle sidebar" unless `aria-label` or `aria-labelledby` says otherwise. */
export type SidebarToggleProps = Omit<IconButtonProps, 'aria-label' | 'aria-labelledby'> & {
    'aria-label'?: string;
    'aria-labelledby'?: string;
};
type SidebarSearchProps = PartProps<HTMLDivElement> & SidebarSearchOwnProps;
export type SidebarSectionProps = PartProps<HTMLLIElement> & SidebarSectionOwnProps;
export type SidebarNavItemProps = SidebarNavItemOwnProps & {
    children?: ReactNode;
};
type SidebarNavButtonProps = AnchorHTMLAttributes<HTMLAnchorElement> & SidebarNavButtonOwnProps;
type SidebarAccountCardProps = PartProps<HTMLDivElement> & SidebarAccountCardOwnProps;
/** The part of Menu's list props that AccountMenu supports. The card's button names the menu and owns its open state. */
export type SidebarAccountMenuProps = SidebarAccountMenuOwnProps & Pick<MenuListProps, 'children' | 'className'>;
type SidebarMobileTriggerProps = SidebarMobileTriggerOwnProps & {
    children?: ReactNode;
};
type SidebarFeatureCardProps = PartProps<HTMLDivElement> & SidebarFeatureCardOwnProps;
export declare const Sidebar: {
    Provider: ComponentType<SidebarProviderProps>;
    Root: ForwardRefExoticComponent<SidebarProps & RefAttributes<HTMLElement>>;
    Toggle: ForwardRefExoticComponent<SidebarToggleProps & RefAttributes<HTMLButtonElement>>;
    Header: ForwardRefExoticComponent<PartProps<HTMLDivElement> & RefAttributes<HTMLDivElement>>;
    Search: ForwardRefExoticComponent<SidebarSearchProps & RefAttributes<HTMLDivElement>>;
    Divider: ForwardRefExoticComponent<PartProps<HTMLHRElement> & RefAttributes<HTMLHRElement>>;
    NavList: ForwardRefExoticComponent<PartProps<HTMLUListElement> & RefAttributes<HTMLUListElement>>;
    Section: ForwardRefExoticComponent<SidebarSectionProps & RefAttributes<HTMLLIElement>>;
    NavItem: ComponentType<SidebarNavItemProps>;
    NavButton: ForwardRefExoticComponent<SidebarNavButtonProps & RefAttributes<HTMLAnchorElement>>;
    /** Shows the account. While an `AccountMenu` is mounted inside it, its Account options button opens that menu; without one the card has no button. */
    AccountCard: ForwardRefExoticComponent<SidebarAccountCardProps & RefAttributes<HTMLDivElement>>;
    /** The menu the card's Account options button opens: pass `Menu.Item`, `Menu.Section`, and `Menu.Separator` children, or `items`, and read the chosen item from `onAction`. Only valid inside `AccountCard`, one per card. */
    AccountMenu: ForwardRefExoticComponent<SidebarAccountMenuProps & RefAttributes<HTMLDivElement>>;
    MobileTrigger: ComponentType<SidebarMobileTriggerProps>;
    FeatureCard: ForwardRefExoticComponent<SidebarFeatureCardProps & RefAttributes<HTMLDivElement>>;
};
export {};

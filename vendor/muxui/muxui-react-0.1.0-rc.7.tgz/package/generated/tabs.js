// @generated-from: packages/react/src/tabs.ts
// @generated-content-sha256: sha256:a5285e2b8358c0f146779f6674a71ed84eb1ef2a02880ace7b1ae66d4829f17e
import React from 'react';
import { TabPanels as AriaTabPanels } from 'react-aria-components';
import { AriaTabs, AriaTabList, AriaTab, AriaTabPanel } from './substrate.js';
import { normalizeChoiceControlSize } from './choice-context.mjs';
import { TabsMotion } from './tabs-motion.mjs';
import { classNames, accessibleName } from './control-utils.js';
import { normalizeItems } from './collection-items.js';
const TABS_VARIANTS = new Set(['underline', 'pill', 'overflow', 'segment']);
function isTabsVariant(value) {
    return TABS_VARIANTS.has(value);
}
function normalizeTabsVariant(value = 'underline') {
    if (!isTabsVariant(value)) {
        throw new TypeError('Tabs variant must be one of: underline, pill, overflow, segment');
    }
    return value;
}
export const Tabs = /*#__PURE__*/ (() => {
    const component = React.forwardRef(function Tabs({ items, value, defaultValue, onChange, keyboardActivation = 'automatic', orientation = 'horizontal', disabled = false, size = 'md', variant = 'underline', children: _children, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
        // normalizeItems takes no items as an empty list, so an omitted list has no default here to state.
        const normalized = normalizeItems(items);
        accessibleName({ ariaLabel, ariaLabelledby }, 'Tabs');
        const resolvedSize = normalizeChoiceControlSize(size, 'Tabs');
        const resolvedVariant = normalizeTabsVariant(variant);
        return React.createElement(AriaTabs, {
            ...props,
            ref,
            selectedKey: value,
            // Conditionals, not ?? and ||: extraction reads a fallback on an owned prop as an executed default.
            defaultSelectedKey: defaultValue === undefined || defaultValue === null ? (normalized.find((item) => !item.disabled) ?? normalized[0])?.id : defaultValue,
            onSelectionChange: (key) => { const item = normalized.find((candidate) => candidate.id === String(key)); if (!disabled && !item?.disabled)
                onChange?.(String(key)); },
            orientation,
            keyboardActivation,
            // React Aria's Tabs props name neither isDisabled nor the data hooks the styles read, and TypeScript accepts such a key in a call only from a spread.
            ...{ isDisabled: disabled },
            className: classNames('muxui-tabs', className),
            ...{ 'data-muxui-size': resolvedSize, 'data-muxui-variant': resolvedVariant },
        }, React.createElement(TabsMotion, { orientation, variant: resolvedVariant, disabled }, React.createElement(AriaTabList, {
            items: normalized,
            className: 'muxui-tabs__list',
            // React Aria names a tablist from the TabList's own props; the Tabs root is a div with no role to name.
            'aria-label': ariaLabel,
            'aria-labelledby': ariaLabelledby,
            // A render function is a child of React Aria's collection parts, which TypeScript accepts as a prop here and not as a createElement child.
            children: (item) => React.createElement(AriaTab, {
                id: item.id,
                ...{
                    isDisabled: disabled ? disabled : item.disabled,
                    'data-muxui-state-disabled': (disabled ? disabled : item.disabled) || undefined,
                    'aria-disabled': (disabled ? disabled : item.disabled) || undefined,
                },
                className: 'muxui-tabs__tab',
            }, React.createElement('span', { className: 'muxui-tabs__tab-label' }, item.label)),
        })), React.createElement(AriaTabPanels, {
            items: normalized,
            className: 'muxui-tabs__panels',
            children: (item) => React.createElement(AriaTabPanel, { id: item.id, className: 'muxui-tabs__panel' }, item.panel),
        }));
    });
    component.displayName = 'Tabs';
    return component;
})();

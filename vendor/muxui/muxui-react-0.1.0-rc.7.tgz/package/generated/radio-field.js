// @generated-from: packages/react/src/supplemental/radio-field.ts
// @generated-content-sha256: sha256:7fc58ce405211f69402ebbc6b416aed70998f260eb9f802d917d804a0b1fa4c9
import React from 'react';
import { RadioGroupStateContext as AriaRadioGroupStateContext } from 'react-aria-components';
import { AriaRadioField, AriaRadioButton } from './substrate.js';
import { normalizeChoiceControlSize, ChoiceControlSizeContext } from './choice-context.mjs';
import { h, cx, nativePart } from './part-utils.js';
import { fieldText, mappedFieldProps } from './field-utils.js';
const RadioFieldContext = React.createContext(undefined);
function useRadioGroupState() {
    const state = React.useContext(AriaRadioGroupStateContext);
    if (!state)
        throw new Error('RadioField must be used inside RadioGroup');
    return state;
}
function splitIds(value) {
    return typeof value === 'string' ? value.trim().split(/\s+/u).filter(Boolean) : [];
}
function makeRadioField() {
    // The root swallows onChange: the enclosing RadioGroup owns it, so the public type leaves it out and this one names it to discard it.
    const Root = /*#__PURE__*/ React.forwardRef(function RadioFieldRoot({ onChange: _onChange, value, disabled, invalid, required, size: sizeProp, className, ...props }, ref) {
        const inheritedSize = React.useContext(ChoiceControlSizeContext);
        const radioGroupState = useRadioGroupState();
        const size = normalizeChoiceControlSize(sizeProp === undefined || sizeProp === null ? inheritedSize : sizeProp, 'RadioField');
        const fallbackErrorId = React.useId();
        const inputRef = React.useRef(null);
        const [errorId, setErrorId] = React.useState(undefined);
        const effectiveInvalid = Boolean(invalid ? invalid : radioGroupState.isInvalid);
        const context = React.useMemo(() => ({ effectiveInvalid, errorId, fallbackErrorId, inputRef, setErrorId }), [effectiveInvalid, errorId, fallbackErrorId]);
        // React Aria's props type the handlers on Element, and these on the div; the rest is the div's native attributes.
        return h(RadioFieldContext.Provider, { value: context }, h(AriaRadioField, { ...mappedFieldProps({ disabled, invalid, required, ...props }), value, ref, inputRef, ...{ 'data-muxui-size': size }, className: cx('muxui-radio-field', size !== 'md' && `muxui-radio-field--${size}`, className) }));
    });
    const Button = /*#__PURE__*/ React.forwardRef(function RadioFieldButton({ disabled, className, 'aria-describedby': ariaDescribedBy, 'aria-errormessage': ariaErrorMessage, ...props }, ref) {
        const field = React.useContext(RadioFieldContext);
        const priorCallerIds = React.useRef([]);
        React.useEffect(() => {
            const input = field?.inputRef.current;
            if (!input)
                return;
            const callerIds = splitIds(ariaDescribedBy);
            const baseIds = splitIds(input.getAttribute('aria-describedby')).filter((id) => !priorCallerIds.current.includes(id));
            const describedBy = [...new Set([...baseIds, ...callerIds])].join(' ');
            if (describedBy)
                input.setAttribute('aria-describedby', describedBy);
            else
                input.removeAttribute('aria-describedby');
            priorCallerIds.current = callerIds;
            const errorMessage = ariaErrorMessage ?? field?.errorId;
            if (errorMessage)
                input.setAttribute('aria-errormessage', errorMessage);
            else
                input.removeAttribute('aria-errormessage');
        }, [ariaDescribedBy, ariaErrorMessage, field?.errorId, field?.inputRef]);
        return h(AriaRadioButton, { ...props, ref, ...{ isDisabled: disabled }, className: cx('muxui-radio-field__button', className) });
    });
    const Indicator = /*#__PURE__*/ React.forwardRef(function RadioFieldIndicator(props, ref) { return nativePart('span', 'muxui-radio-field__indicator', props, ref); });
    const Dot = /*#__PURE__*/ React.forwardRef(function RadioFieldDot(props, ref) { return nativePart('span', 'muxui-radio-field__dot', props, ref); });
    const Description = /*#__PURE__*/ React.forwardRef(function RadioFieldDescription(props, ref) { return fieldText('description', 'muxui-radio-field__description', props, ref); });
    const Error = /*#__PURE__*/ React.forwardRef(function RadioFieldError({ className, id, role, ...props }, ref) {
        const field = React.useContext(RadioFieldContext);
        const errorId = id ?? field?.fallbackErrorId;
        const effectiveInvalid = field?.effectiveInvalid;
        const setErrorId = field?.setErrorId;
        React.useEffect(() => {
            if (!effectiveInvalid || !errorId || !setErrorId)
                return undefined;
            setErrorId((current) => current === errorId ? current : errorId);
            return () => setErrorId((current) => current === errorId ? undefined : current);
        }, [effectiveInvalid, errorId, setErrorId]);
        if (!effectiveInvalid || !errorId)
            return null;
        return nativePart('span', 'muxui-radio-field__error', { ...props, id: errorId, className, role: role ?? 'alert' }, ref);
    });
    return /*#__PURE__*/ Object.freeze({ Root, Button, Indicator, Dot, Description, Error });
}
export const RadioField = /*#__PURE__*/ makeRadioField();

// @generated-from: packages/react/src/combo-box.ts
// @generated-content-sha256: sha256:9f24b90acc0437f429bbbaf51e4a4aa25a6920569c9663978bde70155cf4801e
import React from 'react';
import ChevronDownIcon from 'lucide-react/dist/esm/icons/chevron-down.mjs';
import { Label as AriaLabel, Text as AriaText, FieldError as AriaFieldError } from 'react-aria-components';
import { AriaComboBox, AriaListBox, AriaListBoxItem, AriaGroup, AriaInput } from './substrate.js';
import { normalizeChoiceControlSize } from './choice-context.mjs';
import { PopoverMotion } from './popover-motion.mjs';
import { IconButton } from './icon-button.js';
import { classNames, accessibleName } from './control-utils.js';
import { normalizeItems } from './collection-items.js';
export const ComboBox = /*#__PURE__*/ (() => {
    const component = React.forwardRef(function ComboBox({ label, description, errorMessage, items, value, defaultValue, selectedId, defaultSelectedId, onChange, onSelect, disabled = false, readOnly = false, required = false, invalid = false, placeholder, size = 'md', name, children: _children, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, ...props }, ref) {
        accessibleName({ label, ariaLabel, ariaLabelledby }, 'ComboBox');
        if (selectedId === '')
            throw new TypeError('ComboBox selectedId must be an item id, or null for no selection; an empty string is not an id');
        if (defaultSelectedId === '')
            throw new TypeError('ComboBox defaultSelectedId must be an item id; omit it for no selection');
        const resolvedSize = normalizeChoiceControlSize(size, 'ComboBox');
        // normalizeItems takes no items as an empty list, so an omitted list has no default here to state.
        const normalized = normalizeItems(items);
        const disabledKeys = new Set(normalized.filter((item) => item.disabled).map((item) => item.id));
        // React Aria reports a cleared selection as a null key, except when both the text and
        // the selection are controlled: then the application owns both, so the clear is read from the emptied input.
        const bothControlled = value !== undefined && selectedId !== undefined;
        // Two checks, not ||: extraction reads a fallback on an owned prop as an executed default.
        const handleSelection = (key) => {
            if (disabled)
                return;
            if (readOnly)
                return;
            if (key == null) {
                if (!bothControlled)
                    onSelect?.(undefined);
                return;
            }
            const item = normalized.find((candidate) => candidate.id === String(key));
            if (item && !item.disabled)
                onSelect?.(item);
        };
        const handleInput = (next) => {
            if (disabled)
                return;
            if (readOnly)
                return;
            onChange?.(next);
            if (bothControlled && next === '' && selectedId !== null)
                onSelect?.(undefined);
        };
        // defaultItems lets React Aria filter options by the typed text; items would mean consumer-filtered.
        return React.createElement(AriaComboBox, { ...props, ref, defaultItems: normalized, disabledKeys, ...(value === undefined ? {} : { inputValue: value }), defaultInputValue: defaultValue, selectedKey: selectedId, defaultSelectedKey: defaultSelectedId, onInputChange: handleInput, onSelectionChange: handleSelection, isDisabled: disabled, isReadOnly: readOnly, isRequired: required, isInvalid: invalid ? invalid : undefined, name, className: classNames('muxui-combo-box', className), ...{ 'data-muxui-size': resolvedSize }, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby }, label !== undefined ? React.createElement(AriaLabel, { className: 'muxui-field-label' }, label) : null, React.createElement(AriaGroup, { className: 'muxui-combo-box__control' }, React.createElement(AriaInput, { className: 'muxui-field-input', placeholder }), React.createElement(IconButton, { className: 'muxui-combo-box__trigger', 'aria-label': 'Show options' }, React.createElement(ChevronDownIcon, { className: 'muxui-combo-box__arrow', 'aria-hidden': 'true', focusable: 'false', size: 16 }))), description !== undefined ? React.createElement(AriaText, { slot: 'description', className: 'muxui-field-description' }, description) : null, errorMessage !== undefined ? React.createElement(AriaFieldError, { className: 'muxui-field-error' }, errorMessage) : null, React.createElement(PopoverMotion, { className: 'muxui-combo-box__popover', ...{ 'data-muxui-size': resolvedSize } }, React.createElement(AriaListBox, { items: normalized, className: 'muxui-combo-box__list', ...{ 'data-muxui-size': resolvedSize }, children: (item) => React.createElement(AriaListBoxItem, { id: item.id, textValue: item.textValue, isDisabled: item.disabled, ...{ 'data-muxui-state-disabled': item.disabled || undefined, 'aria-disabled': item.disabled || undefined }, className: 'muxui-combo-box__option' }, item.label) })));
    });
    component.displayName = 'ComboBox';
    return component;
})();

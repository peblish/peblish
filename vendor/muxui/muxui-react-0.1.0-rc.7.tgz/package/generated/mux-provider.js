// @generated-from: packages/react/src/mux-provider.ts
// @generated-content-sha256: sha256:ea1b93963c3a4a5b7538b8560ecf82161b8b072e0250bb4fb8a546d6f762a61f
import React from 'react';
import { I18nProvider, RouterProvider } from 'react-aria-components';
/**
 * Sets the application-wide context Mux UI components read: the locale and, optionally, the router. It renders no
 * element, so place it once near the root, inside the document body. The page still owns `<html lang dir>`.
 */
export function MuxProvider(props) {
    const { locale, navigate, useHref, children } = props;
    const localized = React.createElement(I18nProvider, { locale, children });
    return navigate ? React.createElement(RouterProvider, { navigate, useHref, children: localized }) : localized;
}

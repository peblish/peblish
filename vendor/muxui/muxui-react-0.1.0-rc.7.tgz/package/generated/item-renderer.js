// @generated-from: packages/react/src/supplemental/item-renderer.ts
// @generated-content-sha256: sha256:ee59732f9c85e0fdd1c2b4dd81546d62feef8d2f9d597d83ca678a4ceb96b227
import React from 'react';
import { h } from './part-utils.js';
export const defaultItemLabel = (item) => String(item.name ?? item.label ?? item.id);
// react-aria collection render functions must return an item element: its
// useCachedChildren reads `rendered.props.id`, and fragments or host elements
// cannot become collection nodes. The public type allows any ReactNode, so
// wrap everything except a composite element (such as the component's Item).
// `getTextValue(item, rendered)` names the wrapped item for search/typeahead.
export function useItemRenderer(children, Item, getTextValue) {
    return React.useMemo(() => {
        if (typeof children !== 'function')
            return children;
        const renderItem = (item) => {
            const rendered = children(item);
            const isItemElement = React.isValidElement(rendered) && rendered.type !== React.Fragment && typeof rendered.type !== 'string';
            return isItemElement ? rendered : h(Item, { id: item.id, textValue: getTextValue(item, rendered) }, rendered);
        };
        // react-aria resets its item cache in development when children.toString()
        // changes (hot reload), so expose the caller's source text.
        renderItem.toString = () => String(children);
        return renderItem;
    }, [children, Item, getTextValue]);
}

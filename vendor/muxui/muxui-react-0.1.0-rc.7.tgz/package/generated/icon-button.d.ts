// @generated-from: packages/react/src/supplemental/icon-button.ts
// @generated-content-sha256: sha256:2356ef2d5edfb7421b9b6da9a8232d5ff6aa744059ec5f4f9784a35672e26fe3
import type { ForwardRefExoticComponent, RefAttributes } from 'react';
import type { ButtonActivationEvent, ButtonProps, ButtonSize, ButtonVariant } from './button.js';
/**
 * The props Mux UI defines for IconButton; the catalog's web.react API is derived
 * from this type (Decision 0031).
 * It is a type literal, not an interface, so the public props type stays assignable to
 * Record<string, unknown>, as it was before the move.
 */
type IconButtonOwnProps = {
    /** Applies the native disabled attribute: the IconButton is neither focusable nor activatable. */
    disabled?: boolean;
    /** Marks an action in flight: a static indicator replaces the icon, and the IconButton stays focusable and named but does not activate. */
    pending?: boolean;
    /** Button's visual recipe, chosen by where the icon sits and what it does. */
    variant?: ButtonVariant;
    /** The square control size. */
    size?: ButtonSize;
    /** Requests the IconButton's one immediate action. */
    onActivate?: (event: ButtonActivationEvent) => void;
};
type IconButtonName = {
    'aria-label': string;
    'aria-labelledby'?: string;
} | {
    'aria-label'?: string;
    'aria-labelledby': string;
};
/** Supply an icon as children and at least one explicit accessible name. */
export type IconButtonProps = IconButtonOwnProps & Omit<ButtonProps, keyof IconButtonOwnProps | 'aria-label' | 'aria-labelledby' | 'showTextWhileLoading'> & IconButtonName;
/** An icon-only action with Button behavior and an explicit accessible name. */
export declare const IconButton: ForwardRefExoticComponent<IconButtonProps & RefAttributes<HTMLButtonElement>>;
export {};

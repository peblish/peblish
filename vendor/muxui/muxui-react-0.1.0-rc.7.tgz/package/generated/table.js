// @generated-from: packages/react/src/table.ts
// @generated-content-sha256: sha256:70888ba0a1297a4d89ccf3ba47bd7d1add38b81b0ac6e7721df050f81f21fb59
import React from 'react';
import ChevronDownIcon from 'lucide-react/dist/esm/icons/chevron-down.mjs';
import { AriaTable, AriaTableBody, AriaTableHeader, AriaColumn, AriaRow, AriaCell } from './substrate.js';
import { classNames, accessibleName } from './control-utils.js';
import { normalizeItems, keySet, keyList } from './collection-items.js';
// A sort descriptor is exactly {column, direction}. Each property is read where the checks need it and no earlier, so a
// getter that throws is reached in the order the checks run, and the descriptor is read no more often than it needs to be.
function sortDescriptorOf(value, columns) {
    const keys = value && typeof value === 'object' && !Array.isArray(value) ? Object.keys(value) : [];
    const descriptor = value;
    if (!value || typeof value !== 'object' || Array.isArray(value) || keys.length !== 2
        || !keys.includes('column') || !keys.includes('direction') || typeof descriptor.column !== 'string'
        || (descriptor.direction !== 'ascending' && descriptor.direction !== 'descending')) {
        throw new TypeError('Table sortDescriptor must be {column: string; direction: ascending|descending}');
    }
    const column = columns.find((candidate) => candidate.id === descriptor.column);
    if (!column || !column.sortable)
        throw new TypeError(`Table sortDescriptor column must be sortable: ${descriptor.column}`);
    return { column: descriptor.column, direction: descriptor.direction };
}
function normalizeSortDescriptor(value, columns) {
    return value === undefined ? undefined : sortDescriptorOf(value, columns);
}
// Decorative Lucide chevron for sortable Table headers. CSS flips it for
// direction and reveals it for the sorted column, hover, and keyboard focus;
// aria-sort from React Aria carries the real state.
function sortChevron() {
    return React.createElement(ChevronDownIcon, { className: 'muxui-icon muxui-icon--sm muxui-table__sort-icon', 'aria-hidden': 'true', focusable: 'false' });
}
export const Table = React.forwardRef(function Table({ columns, rows, selectedIds, defaultSelectedIds, onSelectionChange, onRowAction, sortDescriptor, onSortChange, selectionMode = 'none', disabled = false, children: _children, className, 'aria-label': ariaLabel, 'aria-labelledby': _ariaLabelledby, ...props }, ref) {
    // normalizeItems takes no items as an empty list, so an omitted list has no default here to state. The normalized items carry the fields the table types declare.
    const normalizedRows = normalizeItems(rows);
    // Cells read the consumer's row, not the normalized copy that injects id, label, and value.
    const sourceRows = new Map(normalizedRows.map((row, index) => [row.id, rows?.[index]]));
    const normalizedColumns = normalizeItems(columns);
    const normalizedSortDescriptor = normalizeSortDescriptor(sortDescriptor, normalizedColumns);
    accessibleName({ ariaLabel }, 'Table');
    const disabledKeys = disabled ? new Set(normalizedRows.map((row) => row.id)) : new Set(normalizedRows.filter((row) => row.disabled).map((row) => row.id));
    return React.createElement(AriaTable, {
        ...props,
        ref,
        selectionMode,
        selectedKeys: keySet(selectedIds),
        defaultSelectedKeys: keySet(defaultSelectedIds),
        sortDescriptor: normalizedSortDescriptor,
        disabledKeys,
        // React Aria's Table props name neither isDisabled nor the disabled hooks the styles read, and TypeScript accepts such a key in a call only from a spread.
        ...{ isDisabled: disabled },
        onSelectionChange: (keys) => { if (!disabled)
            onSelectionChange?.(keyList(keys)); },
        onSortChange: (next) => {
            // Conditionals, not ||: extraction reads a fallback on an owned prop as an executed default.
            if (disabled)
                return;
            if (!next)
                return;
            const descriptor = sortDescriptorOf({ column: String(next.column), direction: next.direction }, normalizedColumns);
            onSortChange?.(descriptor);
        },
        ...(onRowAction ? {
            onRowAction: (key) => {
                const row = normalizedRows.find((item) => item.id === String(key));
                if (!disabled && !row?.disabled)
                    onRowAction(row);
            },
        } : {}),
        'aria-label': ariaLabel,
        ...{ 'aria-disabled': disabled ? disabled : undefined, 'data-muxui-state-disabled': disabled ? disabled : undefined },
        className: classNames('muxui-table', className),
    }, React.createElement(AriaTableHeader, {
        columns: normalizedColumns,
        className: 'muxui-table__header',
        // A render function is a child of React Aria's collection parts, which TypeScript accepts as a prop here and not as a createElement child.
        children: (column) => React.createElement(AriaColumn, {
            id: column.id,
            textValue: column.textValue,
            isRowHeader: column.isRowHeader,
            allowsSorting: column.sortable,
            className: 'muxui-table__column',
        }, column.sortable ? React.createElement('span', { className: 'muxui-table__column-content' }, column.label, sortChevron()) : column.label),
    }), React.createElement(AriaTableBody, {
        items: normalizedRows,
        className: 'muxui-table__body',
        children: (row) => React.createElement(AriaRow, { id: row.id, className: 'muxui-table__row' }, normalizedColumns.map((column) => React.createElement(AriaCell, { key: column.id, className: 'muxui-table__cell' }, row.values?.[column.id] ?? sourceRows.get(row.id)?.[column.id] ?? ''))),
    }));
});
Table.displayName = 'Table';

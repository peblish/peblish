// @generated-from: packages/react/src/grid-virtualizer-context.ts
// @generated-content-sha256: sha256:04c6662fb42f093bb2f163f0fd27f9151e9396d5cc1f0c71657963c9b4ed5759
import React from 'react';
// A grid Virtualizer provides this so its GridList can report the CSS gap it
// resolves to; the Virtualizer turns that gap into layout spacing. Both read the one
// type, so the value a provider supplies is the value a consumer calls.
export const GridVirtualizerContext = React.createContext(null);

// @generated-from: packages/react/src/supplemental/checkbox-field.ts
// @generated-content-sha256: sha256:69c533ae06bf28c0da7dc45ff055cea74cb6d1892a8bc27b66ff01ce7143a1a7
import type { ForwardRefExoticComponent, HTMLAttributes, LabelHTMLAttributes, RefAttributes } from 'react';
import type { PartProps } from './part-utils.js';
/**
 * The props Mux UI defines for CheckboxField.Root, the compound's root; the catalog's web.react
 * API is derived from this type (Decision 0031). The members every field shares are written out,
 * because the catalog's grammar reads only the members a type lists itself.
 */
type CheckboxFieldOwnProps = {
    /** Whether the checkbox is checked, when the caller controls it. */
    checked?: boolean;
    /** Whether the checkbox starts checked, when the field controls itself. */
    defaultChecked?: boolean;
    /** Shows the mixed state in place of checked or unchecked. */
    indeterminate?: boolean;
    /** Called with the new checked state. */
    onChange?: (checked: boolean) => void;
    /** The name the checkbox submits under in a form. */
    name?: string;
    /** The value the checkbox submits while it is checked. */
    value?: string;
    /** Marks the field disabled. */
    disabled?: boolean;
    /** Marks the field invalid. */
    invalid?: boolean;
    /** Marks the field required. */
    required?: boolean;
    /** Marks the field read-only. */
    readOnly?: boolean;
    /** The field's size. */
    size?: 'sm' | 'md' | 'lg';
};
/** The props Mux UI defines for CheckboxField.Button; its API is the button entry in the catalog's partApis. */
type CheckboxFieldButtonOwnProps = {
    /** Marks the checkbox disabled, whatever its field says. */
    disabled?: boolean;
};
export type CheckboxFieldRootProps = Omit<HTMLAttributes<HTMLDivElement>, 'onChange'> & CheckboxFieldOwnProps;
export type CheckboxFieldButtonProps = LabelHTMLAttributes<HTMLLabelElement> & CheckboxFieldButtonOwnProps;
export type CheckboxFieldIndicatorProps = PartProps<HTMLSpanElement>;
export type CheckboxFieldDescriptionProps = PartProps<HTMLElement>;
export type CheckboxFieldErrorProps = PartProps<HTMLElement>;
export declare const CheckboxField: {
    Root: ForwardRefExoticComponent<CheckboxFieldRootProps & RefAttributes<HTMLDivElement>>;
    Button: ForwardRefExoticComponent<CheckboxFieldButtonProps & RefAttributes<HTMLLabelElement>>;
    Indicator: ForwardRefExoticComponent<CheckboxFieldIndicatorProps & RefAttributes<HTMLSpanElement>>;
    Description: ForwardRefExoticComponent<CheckboxFieldDescriptionProps & RefAttributes<HTMLElement>>;
    Error: ForwardRefExoticComponent<CheckboxFieldErrorProps & RefAttributes<HTMLElement>>;
};
export {};

// @generated-from: packages/react/src/collection-trigger.ts
// @generated-content-sha256: sha256:169effecb73cb4bb2cb345e99928754ef0b23acb8f909515a9cb9451485e679d
import type { ButtonHTMLAttributes, ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { ButtonActivationEvent } from './button.js';
/** The props a collection family's trigger takes: the native button attributes, a disabled flag, and `onActivate`. */
interface CollectionTriggerProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'children' | 'className' | 'disabled'> {
    children?: ReactNode;
    className?: string | undefined;
    disabled?: boolean | undefined;
    onActivate?: ((event: ButtonActivationEvent) => void) | undefined;
}
export declare const CollectionTrigger: ForwardRefExoticComponent<CollectionTriggerProps & RefAttributes<HTMLButtonElement>>;
export {};

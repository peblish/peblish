// @generated-from: packages/react/src/supplemental/color-mode-toggle.ts
// @generated-content-sha256: sha256:25a52c65cd95cac3f4803244078abe86047f26c18b05ffcdcae0a96ea4e3fc98
import type { ForwardRefExoticComponent, LabelHTMLAttributes, RefAttributes } from 'react';
import type { ColorMode } from './color-mode.js';
export type { ColorMode };
/**
 * The props Mux UI defines for ColorModeToggle; the catalog's web.react API is derived from
 * this type (Decision 0031). The label is its children, and its accessible name is aria-label.
 */
type ColorModeToggleOwnProps = {
    /** The color mode, when the page controls it. */
    mode?: ColorMode;
    /** The mode the toggle starts in, before a saved mode or the operating system's preference is read. */
    defaultMode?: ColorMode;
    /** The localStorage key the chosen mode is saved under. */
    storageKey?: string;
    /** Marks the toggle disabled. */
    disabled?: boolean;
    /** Called with the new mode when the toggle changes it. */
    onModeChange?: (mode: ColorMode) => void;
};
export type ColorModeToggleProps = LabelHTMLAttributes<HTMLLabelElement> & ColorModeToggleOwnProps;
export declare const ColorModeToggle: ForwardRefExoticComponent<ColorModeToggleProps & RefAttributes<HTMLLabelElement>>;

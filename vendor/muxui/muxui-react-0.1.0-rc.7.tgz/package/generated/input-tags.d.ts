// @generated-from: packages/react/src/supplemental/input-tags.ts
// @generated-content-sha256: sha256:4a4984bd0e3ecebe8241825f3d9cbdd9ac1bcecc5b4949a581b4ffd3035efb5b
import type { ForwardRefExoticComponent, HTMLAttributes, ReactNode, RefAttributes } from 'react';
/**
 * The props Mux UI defines for InputTags.Root, the compound's one part; the catalog's web.react
 * API is derived from this type (Decision 0031). The members every field shares are written out,
 * because the catalog's grammar reads only the members a type lists itself.
 */
type InputTagsOwnProps = {
    /** Where the tags sit: inline with the input, or below it. */
    tagPlacement?: 'inline' | 'below';
    /** The field's size. */
    size?: 'sm' | 'md' | 'lg';
    /** The hint shown in the input while it is empty, and beside the tags when they sit below. */
    placeholder?: string;
    /** The tags, when the caller controls them. */
    value?: string[];
    /** The starting tags, when the field controls itself. */
    defaultValue?: string[];
    /** Called with all of the tags each time one is added or removed. */
    onChange?: (tags: string[]) => void;
    /** Called with the tag that was just added. */
    onTagAdded?: (tag: string) => void;
    /** Called with the tag that was just removed. */
    onTagRemoved?: (tag: string) => void;
    /** Lets the same tag be added more than once. */
    allowDuplicates?: boolean;
    /** The most tags the field holds; adding another does nothing. */
    maxTags?: number;
    /** Decides whether a typed tag may be added. */
    validate?: (value: string) => boolean;
    /** The visible label, which also names the input. */
    label?: ReactNode;
    /** Supporting text shown with the field. */
    description?: ReactNode;
    /** The message shown, in place of the description, while the field is invalid. */
    errorMessage?: ReactNode;
    /** Marks the field disabled. */
    disabled?: boolean;
    /** Marks the field invalid. */
    invalid?: boolean;
    /** Marks the field required. */
    required?: boolean;
};
export type InputTagsProps = Omit<HTMLAttributes<HTMLDivElement>, 'onChange' | 'defaultValue'> & InputTagsOwnProps & {
    readOnly?: boolean;
};
export type InputTagsRootProps = InputTagsProps;
export declare const InputTags: {
    Root: ForwardRefExoticComponent<InputTagsProps & RefAttributes<HTMLDivElement>>;
};
export {};

// @generated-from: packages/react/src/supplemental/message.ts
// @generated-content-sha256: sha256:358d7838a1af8a46c89af1cda77234a1cef920b6d497218dbe0cdb7fec7d88ff
import type { ForwardRefExoticComponent, HTMLAttributes, ReactNode, RefAttributes } from 'react';
export type MessageAction = {
    id: string;
    label: string;
    icon?: ReactNode;
    onAction: () => void;
    disabled?: boolean;
    pressed?: boolean;
};
export type MessageSource = {
    id: string;
    label: string;
    href: string;
    description?: string;
};
export type MessageFollowUp = {
    id: string;
    label: string;
};
/**
 * The props Mux UI defines for Message; the catalog's web.react API is derived from
 * this type (Decision 0031). The content is the children.
 * It is a type literal, not an interface, so the public props type stays assignable to
 * Record<string, unknown>, as it was before the move.
 */
type MessageOwnProps = {
    /** Who the turn is from. A user message shows its content in a filled bubble. */
    sender?: 'user' | 'assistant' | 'system';
    /** Content shown above the message, such as its author's name. */
    author?: ReactNode;
    /** Compact buttons for the message. Pressed makes one a toggle. */
    actions?: readonly MessageAction[];
    /** What the reply relied on, listed behind a count button. Only http, https, and relative links stay links. */
    sources?: readonly MessageSource[];
    /** Whether the source list is open, when the caller controls it. */
    sourcesExpanded?: boolean;
    /** Whether the source list starts open, when Message controls it. */
    defaultSourcesExpanded?: boolean;
    /** Reports the source list opening or closing. */
    onSourcesExpandedChange?: (expanded: boolean) => void;
    /** Suggested next messages. They render only with onFollowUp. */
    followUps?: readonly MessageFollowUp[];
    /** Reports the chosen follow-up. Message sends nothing. */
    onFollowUp?: (item: MessageFollowUp) => void;
    /** Adds the streaming status text while the caller updates the content. */
    streaming?: boolean;
    /** The status text announced while streaming. */
    streamingLabel?: string;
};
export type MessageProps = MessageOwnProps & Omit<HTMLAttributes<HTMLElement>, keyof MessageOwnProps | 'dangerouslySetInnerHTML'>;
/** Caller-updated content; Markdown is composed through its separately imported subpath. */
export declare const Message: ForwardRefExoticComponent<MessageProps & RefAttributes<HTMLElement>>;
export {};

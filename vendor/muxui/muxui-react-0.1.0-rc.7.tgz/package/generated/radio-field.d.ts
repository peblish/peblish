// @generated-from: packages/react/src/supplemental/radio-field.ts
// @generated-content-sha256: sha256:3c7add6a14cd214de61645b5ed7afa784a82f3541e0af7f66cea16146b900d5b
import type { ForwardRefExoticComponent, HTMLAttributes, LabelHTMLAttributes, RefAttributes } from 'react';
import type { PartProps } from './part-utils.js';
/**
 * The props Mux UI defines for RadioField.Root, the compound's root; the catalog's web.react
 * API is derived from this type (Decision 0031). The members every field shares are written out,
 * because the catalog's grammar reads only the members a type lists itself. The size follows
 * the enclosing RadioGroup, so it has no default here.
 */
type RadioFieldOwnProps = {
    /** The option's value, which the enclosing RadioGroup selects by. */
    value: string;
    /** Marks the option disabled. */
    disabled?: boolean;
    /** Marks the option invalid. */
    invalid?: boolean;
    /** Marks the option required. */
    required?: boolean;
    /** The option's size, in place of the enclosing RadioGroup's. */
    size?: 'sm' | 'md' | 'lg';
};
/** The props Mux UI defines for RadioField.Button; its API is the button entry in the catalog's partApis. */
type RadioFieldButtonOwnProps = {
    /** Marks the option disabled, whatever its field says. */
    disabled?: boolean;
};
export type RadioFieldRootProps = Omit<HTMLAttributes<HTMLDivElement>, 'onChange'> & RadioFieldOwnProps;
export type RadioFieldButtonProps = LabelHTMLAttributes<HTMLLabelElement> & RadioFieldButtonOwnProps;
export type RadioFieldIndicatorProps = PartProps<HTMLSpanElement>;
export type RadioFieldDotProps = PartProps<HTMLSpanElement>;
export type RadioFieldDescriptionProps = PartProps<HTMLElement>;
export type RadioFieldErrorProps = PartProps<HTMLElement>;
export declare const RadioField: {
    Root: ForwardRefExoticComponent<RadioFieldRootProps & RefAttributes<HTMLDivElement>>;
    Button: ForwardRefExoticComponent<RadioFieldButtonProps & RefAttributes<HTMLLabelElement>>;
    Indicator: ForwardRefExoticComponent<RadioFieldIndicatorProps & RefAttributes<HTMLSpanElement>>;
    Dot: ForwardRefExoticComponent<RadioFieldDotProps & RefAttributes<HTMLSpanElement>>;
    Description: ForwardRefExoticComponent<RadioFieldDescriptionProps & RefAttributes<HTMLElement>>;
    Error: ForwardRefExoticComponent<RadioFieldErrorProps & RefAttributes<HTMLElement>>;
};
export {};

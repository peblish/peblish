// @generated-from: packages/react/src/tabs.ts
// @generated-content-sha256: sha256:70c089c11d38c5be4194abb4d5ac273e11d2d9e2253df6c314cb81db45fa9259
import type { ForwardRefExoticComponent, RefAttributes } from 'react';
import type { MuxUIItems } from './collection-items.js';
import type { ControlSize, MuxUIAriaAccessibleName } from './fields.js';
/** The props Mux UI defines for Tabs. */
export type TabsOwnProps = {
    /** The tabs as data: strings, or items with an `id`, a `label`, a `textValue`, `disabled`, and the `panel` the tab shows. */
    items?: MuxUIItems;
    /** The id of the selected tab, when the caller controls the selection. */
    value?: string;
    /** The id of the tab selected at first, when Tabs controls its own selection. Without one, the first enabled tab is selected. */
    defaultValue?: string;
    /** Disables every tab. A tab's own `disabled` disables just that tab. */
    disabled?: boolean;
    /** The direction the tabs run, which arrow keys follow. */
    orientation?: 'horizontal' | 'vertical';
    /** How arrow keys act. With `automatic`, an arrow key selects the tab it reaches. With `manual`, arrow keys only move focus, and Enter or Space selects the focused tab. */
    keyboardActivation?: 'automatic' | 'manual';
    /** The control size, sm, md, or lg. */
    size?: ControlSize;
    /** The visual treatment of the tab list: underline, pill, overflow, or segment. */
    variant?: 'underline' | 'pill' | 'overflow' | 'segment';
    /** Called with the id of the tab the user selects. It is not called for a disabled tab or while Tabs is disabled. */
    onChange?: (value: string) => void;
};
export type TabsProps = TabsOwnProps & {
    className?: string;
} & MuxUIAriaAccessibleName;
export declare const Tabs: ForwardRefExoticComponent<TabsProps & RefAttributes<HTMLDivElement>>;

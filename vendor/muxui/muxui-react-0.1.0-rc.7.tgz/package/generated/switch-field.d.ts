// @generated-from: packages/react/src/supplemental/switch-field.ts
// @generated-content-sha256: sha256:bdd798b4f746abe34193523d8121bc43f1017499eef34ece0d6c5a75a9d052fc
import type { ForwardRefExoticComponent, HTMLAttributes, LabelHTMLAttributes, RefAttributes } from 'react';
import type { PartProps } from './part-utils.js';
/**
 * The props Mux UI defines for SwitchField.Root, the compound's root; the catalog's web.react
 * API is derived from this type (Decision 0031). The members every field shares are written out,
 * because the catalog's grammar reads only the members a type lists itself.
 */
type SwitchFieldOwnProps = {
    /** Whether the switch is on, when the caller controls it. */
    checked?: boolean;
    /** Whether the switch starts on, when the field controls itself. */
    defaultChecked?: boolean;
    /** Called with the new on state. */
    onChange?: (checked: boolean) => void;
    /** The name the switch submits under in a form. */
    name?: string;
    /** The value the switch submits while it is on. */
    value?: string;
    /** Marks the field disabled. */
    disabled?: boolean;
    /** Marks the field invalid. */
    invalid?: boolean;
    /** Marks the field required. */
    required?: boolean;
    /** Marks the field read-only. */
    readOnly?: boolean;
    /** The field's size. */
    size?: 'sm' | 'md' | 'lg';
};
/** The props Mux UI defines for SwitchField.Button; its API is the button entry in the catalog's partApis. */
type SwitchFieldButtonOwnProps = {
    /** Marks the switch disabled, whatever its field says. */
    disabled?: boolean;
};
export type SwitchFieldRootProps = Omit<HTMLAttributes<HTMLDivElement>, 'onChange'> & SwitchFieldOwnProps;
export type SwitchFieldButtonProps = LabelHTMLAttributes<HTMLLabelElement> & SwitchFieldButtonOwnProps;
export type SwitchFieldThumbProps = PartProps<HTMLSpanElement>;
export type SwitchFieldDescriptionProps = PartProps<HTMLElement>;
export type SwitchFieldErrorProps = PartProps<HTMLElement>;
export declare const SwitchField: {
    Root: ForwardRefExoticComponent<SwitchFieldRootProps & RefAttributes<HTMLDivElement>>;
    Button: ForwardRefExoticComponent<SwitchFieldButtonProps & RefAttributes<HTMLLabelElement>>;
    Thumb: ForwardRefExoticComponent<SwitchFieldThumbProps & RefAttributes<HTMLSpanElement>>;
    Description: ForwardRefExoticComponent<SwitchFieldDescriptionProps & RefAttributes<HTMLElement>>;
    Error: ForwardRefExoticComponent<SwitchFieldErrorProps & RefAttributes<HTMLElement>>;
};
export {};

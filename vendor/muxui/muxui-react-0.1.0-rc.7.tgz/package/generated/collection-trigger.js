// @generated-from: packages/react/src/collection-trigger.ts
// @generated-content-sha256: sha256:82e278a95a7d93e0405e809c224b883dc9e547d8fab832212e27e466819bb425
import React from 'react';
import { AriaButton } from './substrate.js';
// RAC supplies trigger semantics while Mux preserves native button handlers and refs.
export const CollectionTrigger = React.forwardRef(function CollectionTrigger({ children, disabled, onActivate, className, ...nativeProps }, ref) {
    const eventProps = Object.fromEntries(Object.entries(nativeProps).filter(([key]) => /^on[A-Z]/u.test(key)));
    const attributes = Object.fromEntries(Object.entries(nativeProps).filter(([key]) => !/^on[A-Z]/u.test(key)));
    return React.createElement(AriaButton, {
        // React Aria types its focus and keyboard handlers on Element where React's name HTMLButtonElement.
        ...attributes, ref, isDisabled: disabled, className,
        onPress: onActivate ? (event) => { if (!disabled)
            onActivate({ type: 'activate', pointerType: event.pointerType, target: event.target }); } : undefined,
        render: (buttonProps) => {
            const merged = { ...nativeProps, ...buttonProps };
            // React Aria's own handlers sit beside the native ones in its render props, which are an interface with no index signature.
            const internals = buttonProps;
            for (const [name, handler] of Object.entries(eventProps)) {
                if (typeof handler !== 'function')
                    continue;
                const internal = internals[name];
                merged[name] = typeof internal === 'function'
                    ? (event) => { handler(event); if (!event.defaultPrevented)
                        internal(event); }
                    : handler;
            }
            return React.createElement('button', merged);
        },
    }, children);
});

// @generated-from: packages/react/src/supplemental/field-utils.ts
// @generated-content-sha256: sha256:581efda343ce357bb71bfc068c9588ef79c4d22bb9528e606656abd531838171
import type { ForwardedRef, ReactElement } from 'react';
import type { PartProps } from './part-utils.js';
/** The state flags every field root renames to the names its upstream renderer reads. */
type FieldFlags = {
    disabled?: boolean;
    invalid?: boolean;
    required?: boolean;
    readOnly?: boolean;
};
export declare function fieldText(slot: string, className: string, props: PartProps<HTMLElement> | undefined, ref: ForwardedRef<HTMLElement>): ReactElement;
/** The props without the four flags, plus the renamed flags as `is`-prefixed booleans. */
export declare function mappedFieldProps<P extends object>({ disabled, invalid, required, readOnly, ...props }: P & FieldFlags): Omit<P & FieldFlags, keyof FieldFlags> & {
    [renamed: `is${string}`]: boolean | undefined;
};
export {};

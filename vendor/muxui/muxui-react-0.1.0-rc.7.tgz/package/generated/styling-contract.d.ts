// @generated-from: packages/react/src/styling-contract.ts
// @generated-content-sha256: sha256:f0d599c619204dcc5832be86878c456706d51ae0c80a415e316d815018fdbafd
/**
 * The presence states, each set as `data-muxui-state-<name>` by React Aria through the substrate adapter and by Mux on
 * its own elements. Spelled as the catalog spells them. The list is closed to states React Aria drives; a status Mux
 * writes for one family (loaded, streaming, complete, ...) is a `data-muxui-<name>` attribute, not a state.
 */
export declare const booleanStates: readonly ['disabled', 'read-only', 'required', 'invalid', 'pending', 'selected', 'indeterminate', 'expanded', 'open', 'current', 'placeholder', 'empty', 'hovered', 'pressed', 'focused', 'focus-visible', 'focus-within', 'dragging', 'drop-target', 'unavailable', 'today', 'outside-month', 'selection-start', 'selection-end', 'entering', 'exiting', 'allows-sorting', 'has-child-items', 'has-submenu'];
/**
 * The enumerated states and their values, as React Aria reports them today (`type` is the date segment type, and
 * `placement` is a popover's resolved side). Mux's own placements (PromptComposer's above and below, Toast's corners)
 * are `data-muxui-placement`, a reflected prop, not this state.
 */
export declare const enumeratedStates: {
    readonly orientation: readonly ['horizontal', 'vertical'];
    readonly placement: readonly ['top', 'bottom', 'left', 'right'];
    readonly layout: readonly ['stack', 'grid'];
    readonly 'sort-direction': readonly ['ascending', 'descending'];
    readonly type: readonly ['era', 'year', 'month', 'day', 'hour', 'minute', 'second', 'dayPeriod', 'literal', 'timeZoneName'];
};
export type StateName = (typeof booleanStates)[number] | keyof typeof enumeratedStates;
export declare const stateAttribute: (state: StateName) => string;
/**
 * The attribute React Aria sets for each state, and the Mux name it becomes. React Aria spells every state
 * `data-<name>` except read-only, which it spells `data-readonly`. Written out so the module has no import-time work
 * (`findModuleSideEffects` rejects a computed table); the type checks every value against the state list and the
 * styling guard checks every state has exactly one entry.
 */
export declare const substrateStateAttributes: Readonly<{
    readonly 'data-disabled': 'data-muxui-state-disabled';
    readonly 'data-readonly': 'data-muxui-state-read-only';
    readonly 'data-required': 'data-muxui-state-required';
    readonly 'data-invalid': 'data-muxui-state-invalid';
    readonly 'data-pending': 'data-muxui-state-pending';
    readonly 'data-selected': 'data-muxui-state-selected';
    readonly 'data-indeterminate': 'data-muxui-state-indeterminate';
    readonly 'data-expanded': 'data-muxui-state-expanded';
    readonly 'data-open': 'data-muxui-state-open';
    readonly 'data-current': 'data-muxui-state-current';
    readonly 'data-placeholder': 'data-muxui-state-placeholder';
    readonly 'data-empty': 'data-muxui-state-empty';
    readonly 'data-hovered': 'data-muxui-state-hovered';
    readonly 'data-pressed': 'data-muxui-state-pressed';
    readonly 'data-focused': 'data-muxui-state-focused';
    readonly 'data-focus-visible': 'data-muxui-state-focus-visible';
    readonly 'data-focus-within': 'data-muxui-state-focus-within';
    readonly 'data-dragging': 'data-muxui-state-dragging';
    readonly 'data-drop-target': 'data-muxui-state-drop-target';
    readonly 'data-unavailable': 'data-muxui-state-unavailable';
    readonly 'data-today': 'data-muxui-state-today';
    readonly 'data-outside-month': 'data-muxui-state-outside-month';
    readonly 'data-selection-start': 'data-muxui-state-selection-start';
    readonly 'data-selection-end': 'data-muxui-state-selection-end';
    readonly 'data-entering': 'data-muxui-state-entering';
    readonly 'data-exiting': 'data-muxui-state-exiting';
    readonly 'data-allows-sorting': 'data-muxui-state-allows-sorting';
    readonly 'data-has-child-items': 'data-muxui-state-has-child-items';
    readonly 'data-has-submenu': 'data-muxui-state-has-submenu';
    readonly 'data-orientation': 'data-muxui-state-orientation';
    readonly 'data-placement': 'data-muxui-state-placement';
    readonly 'data-layout': 'data-muxui-state-layout';
    readonly 'data-sort-direction': 'data-muxui-state-sort-direction';
    readonly 'data-type': 'data-muxui-state-type';
}>;

// @generated-from: packages/react/src/supplemental/checkbox-field.ts
// @generated-content-sha256: sha256:ccb5b60c292314d4fbcf6a79956d6a4a1d18ba1cd221d0e65b28637a9d9f2eaa
import React from 'react';
import CheckIcon from 'lucide-react/dist/esm/icons/check.mjs';
import MinusIcon from 'lucide-react/dist/esm/icons/minus.mjs';
import { AriaCheckboxField, AriaCheckboxButton } from './substrate.js';
import { normalizeChoiceControlSize } from './choice-context.mjs';
import { h, cx, nativePart } from './part-utils.js';
import { fieldText, mappedFieldProps } from './field-utils.js';
import { fieldError } from './field-error.js';
const CheckboxFieldIndicatorContext = React.createContext(null);
/* Field compounds */
function makeCheckboxField() {
    const Root = /*#__PURE__*/ React.forwardRef(function CheckboxFieldRoot({ checked, defaultChecked, indeterminate, onChange, name, value, disabled, invalid, required, readOnly, size = 'md', className, ...props }, ref) {
        const resolvedSize = normalizeChoiceControlSize(size, 'CheckboxField');
        // React Aria's props type the handlers on Element, and these on the div; the rest is the div's native attributes.
        return h(AriaCheckboxField, { ...mappedFieldProps({ disabled, invalid, required, readOnly, ...props }), ref, isSelected: checked, defaultSelected: defaultChecked, isIndeterminate: indeterminate, onChange, name, value, ...{ 'data-muxui-size': resolvedSize }, className: cx('muxui-checkbox-field', resolvedSize !== 'md' && `muxui-checkbox-field--${resolvedSize}`, className) });
    });
    const Button = /*#__PURE__*/ React.forwardRef(function CheckboxFieldButton({ disabled, className, children, ...props }, ref) {
        return h(AriaCheckboxButton, { ...props, ref, ...{ isDisabled: disabled }, className: cx('muxui-checkbox-field__button', className),
            children: (renderProps) => h(CheckboxFieldIndicatorContext.Provider, { value: renderProps }, typeof children === 'function' ? children(renderProps) : children) });
    });
    const Indicator = /*#__PURE__*/ React.forwardRef(function CheckboxFieldIndicator({ className, children, ...props }, ref) {
        const renderProps = React.useContext(CheckboxFieldIndicatorContext);
        const content = children === undefined || children === null
            ? renderProps?.isIndeterminate
                ? h(MinusIcon, { className: 'muxui-checkbox-field__indicator-icon', 'aria-hidden': true, focusable: 'false', size: 12 })
                : renderProps?.isSelected
                    ? h(CheckIcon, { className: 'muxui-checkbox-field__indicator-icon', 'aria-hidden': true, focusable: 'false', size: 12 })
                    : null
            : children;
        return nativePart('span', 'muxui-checkbox-field__indicator', props, ref, content);
    });
    const Description = /*#__PURE__*/ React.forwardRef(function CheckboxFieldDescription(props, ref) { return fieldText('description', 'muxui-checkbox-field__description', props, ref); });
    const Error = /*#__PURE__*/ React.forwardRef(function CheckboxFieldError(props, ref) { return fieldError('muxui-checkbox-field__error', props, ref); });
    return /*#__PURE__*/ Object.freeze({ Root, Button, Indicator, Description, Error });
}
export const CheckboxField = /*#__PURE__*/ makeCheckboxField();

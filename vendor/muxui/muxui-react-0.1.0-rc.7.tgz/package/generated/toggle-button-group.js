// @generated-from: packages/react/src/toggle-button-group.ts
// @generated-content-sha256: sha256:16653e74b06a08bfe8704451f6cb8547072562587c47cb232d332a3947a2e599
import React from 'react';
import { AriaToggleButtonGroup } from './substrate.js';
import { normalizeToggleButtonSize, ToggleButtonSizeContext } from './toggle-button-context.mjs';
import { ToggleButtonGroupMotion } from './toggle-button-group-motion.mjs';
import { classNames, accessibleName } from './control-utils.js';
function readonlyKeyArray(value, property) {
    if (value === undefined)
        return undefined;
    if (!Array.isArray(value) || value.some((key) => typeof key !== 'string')) {
        throw new TypeError(`${property} must be a readonly string array`);
    }
    return [...value];
}
function readonlyKeySet(value, property, selectionMode) {
    if (selectionMode !== 'single' && selectionMode !== 'multiple') {
        throw new TypeError('ToggleButtonGroup selectionMode must be single or multiple');
    }
    const keys = readonlyKeyArray(value, property);
    if (keys && selectionMode === 'single' && keys.length > 1) {
        throw new TypeError(`${property} must contain at most one ID in single selection mode`);
    }
    return keys === undefined ? undefined : new Set(keys);
}
export const ToggleButtonGroup = /*#__PURE__*/ (() => {
    const component = React.forwardRef(function ToggleButtonGroup({ selectedIds, defaultSelectedIds, onSelectionChange, selectionMode = 'single', orientation = 'horizontal', disabled = false, disallowEmptySelection = false, size = 'md', children, className, ...props }, ref) {
        accessibleName({ ariaLabel: props['aria-label'], ariaLabelledby: props['aria-labelledby'] }, 'ToggleButtonGroup');
        const selectedKeys = readonlyKeySet(selectedIds, 'selectedIds', selectionMode);
        const defaultSelectedKeys = readonlyKeySet(defaultSelectedIds, 'defaultSelectedIds', selectionMode);
        const resolvedSize = normalizeToggleButtonSize(size, 'ToggleButtonGroup');
        const group = React.createElement(AriaToggleButtonGroup, {
            ...props,
            selectedKeys,
            defaultSelectedKeys,
            selectionMode,
            disallowEmptySelection,
            // React Aria types the selection as a set of keys. The check stays for the all value its state can hold.
            onSelectionChange: (keys) => {
                if (!disabled) {
                    if (keys === 'all')
                        throw new TypeError('ToggleButtonGroup selection cannot be all');
                    if (disallowEmptySelection && keys.size === 0)
                        return;
                    onSelectionChange?.([...keys].map(String));
                }
            },
            orientation,
            isDisabled: disabled,
            // The data-* hook the styles read is not a prop React Aria types, and TypeScript accepts such a key in a call only from a spread.
            ...{ 'data-muxui-size': resolvedSize },
            className: classNames('muxui-toggle-button-group', className),
        }, children);
        return React.createElement(ToggleButtonSizeContext.Provider, { value: resolvedSize }, 
        // The motion wrapper's props name its group as children, which createElement would otherwise set from its third argument.
        React.createElement(ToggleButtonGroupMotion, { selectionMode, disabled, rootRef: ref, children: group }));
    });
    component.displayName = 'ToggleButtonGroup';
    return component;
})();

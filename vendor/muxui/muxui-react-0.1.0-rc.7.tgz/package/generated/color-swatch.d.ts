// @generated-from: packages/react/src/color-swatch.ts
// @generated-content-sha256: sha256:cc835b548d3845ebf52d557367207b7d6684e08ae380e9ca2591b333ee55e7e4
import type { ForwardRefExoticComponent, HTMLAttributes, RefAttributes } from 'react';
import type { MuxUIColorValue } from './color-context.js';
/**
 * The props Mux UI defines for ColorSwatch. Every other attribute of a div, such as aria-label, id,
 * and the event handlers, passes through to the swatch unchanged.
 */
export type ColorSwatchOwnProps = {
    /** The color to show, as a valid CSS color string. Its alpha is kept. */
    color: MuxUIColorValue;
    /** A second color. With it the swatch shows a diagonal two-tone preview, and both colors keep their alpha. It needs a color. */
    secondaryColor?: MuxUIColorValue;
    /** The swatch outline: `square` keeps the token-based corner radius, and `circle` is round. */
    shape?: 'square' | 'circle';
    /** One short phrase that names the whole preview in the application's language. Without one, a single color is named by its own description and a two-tone swatch by both descriptions. */
    colorName?: string;
    /** Marks the swatch disabled. A disabled enclosing ColorPicker disables it too. */
    disabled?: boolean;
};
export type ColorSwatchProps = Omit<HTMLAttributes<HTMLDivElement>, 'children' | 'color'> & ColorSwatchOwnProps;
export declare const ColorSwatch: ForwardRefExoticComponent<ColorSwatchProps & RefAttributes<HTMLDivElement>>;

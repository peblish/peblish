// @generated-from: packages/react/src/select.ts
// @generated-content-sha256: sha256:f105bffa40f743e03523d6fb537040d30317eeff2e571bebc74127f76807eb33
import type { ButtonHTMLAttributes, DetailedHTMLProps, ForwardRefExoticComponent, HTMLAttributes, ReactElement, ReactNode, RefAttributes, RefObject } from 'react';
import type { MuxUIItems } from './collection-items.js';
import type { FieldValidationProps, MuxUIAccessibleName, NamedFieldProps } from './fields.js';
import type { MuxUIPlacement } from './overlays.js';
/**
 * The props Mux UI defines for Select, which is also Select.Root. Every other attribute of a div passes
 * through to the root.
 */
export type SelectOwnProps = {
    /** The visible label, which also names the field. Without one, name the Select with an aria-label, an aria-labelledby, or a nonempty Select.Label among its children; an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the field, which also describes it. */
    description?: ReactNode;
    /** The message the field shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed validation. It never makes the field invalid by itself. */
    errorMessage?: ReactNode;
    /** The options as data: strings, or items with an `id`, a `label`, a `textValue`, and `disabled`. Children take precedence: when both are supplied, the items are not rendered. */
    items?: MuxUIItems;
    /** The id of the selected item, when the caller controls it. A named Select submits this id, not the item's `value`. */
    value?: string;
    /** The id of the item selected at first, when the Select controls itself. */
    defaultValue?: string;
    /** Whether the popup is open, when the caller controls it. A disabled Select is closed whatever this says. */
    open?: boolean;
    /** Whether the popup starts open, when the Select controls itself. A disabled Select starts closed. */
    defaultOpen?: boolean;
    /** Disables the trigger and every option. A Select.Trigger or Select.Item's own `disabled={false}` cannot re-enable them under a disabled Select. */
    disabled?: boolean;
    /** The control size. The popup and its options take it too. */
    size?: 'sm' | 'md' | 'lg';
    /** Makes the Select read-only: it keeps its value, and `onChange` is not called when an option is chosen. */
    readOnly?: boolean;
    /** Marks the field required. */
    required?: boolean;
    /** Marks the field invalid and shows its error message. Left false, validation decides, so failed validation can still make the field invalid. */
    invalid?: boolean;
    /** The form field name. A named Select submits the selected item's id, not the item's `value`. */
    name?: string;
    /** The text the default trigger shows while nothing is selected. */
    placeholder?: string;
    /** Composes the field from Select parts in place of the default trigger, popup, and list; the simple `items`, `selectedContent`, and `trigger` are then not rendered. The `label`, `description`, and `errorMessage` still render. */
    children?: ReactNode;
    /** Content the default trigger shows in place of the selected item's text. */
    selectedContent?: ReactNode;
    /** A native button element that replaces the default trigger, keeping its ref, attributes, and handlers. A Select that is disabled disables it. Any other element throws a TypeError. */
    trigger?: ReactElement<DetailedHTMLProps<ButtonHTMLAttributes<HTMLButtonElement>, HTMLButtonElement>, 'button'>;
    /** Where the popup opens against its trigger or anchorRef. start and end follow the locale direction. A Select.Popup's own placement wins over this. */
    placement?: MuxUIPlacement;
    /** The distance in pixels between the popup and its trigger, along the placement's side. Must be finite. A Select.Popup's own offset wins over this. */
    offset?: number;
    /** The shift in pixels along the side the popup is placed against. Must be finite. A Select.Popup's own crossOffset wins over this. */
    crossOffset?: number;
    /** Whether the popup moves to the opposite side when the placed side has no room. A Select.Popup's own shouldFlip wins over this. */
    shouldFlip?: boolean;
    /** The least distance in pixels between the popup and the edge of the viewport. Must be finite and not negative. A Select.Popup's own containerPadding wins over this. */
    containerPadding?: number;
    /** Whether the rest of the page is made inaccessible while the popup is open. When false, outside content stays accessible. A Select.Popup's own modal wins over this. */
    modal?: boolean;
    /** Called with the id of the chosen item, or with no value when the selection clears. It is not called while the Select is disabled or read-only. */
    onChange?: (value?: string) => void;
    /** Called with the next open state when the popup opens or closes. It is not called for a request to open a disabled Select. */
    onOpenChange?: (open: boolean) => void;
};
/** Select's options beyond what its label arms and FieldValidationProps carry, as the simple Select takes them. */
export type SelectOptions = Omit<SelectOwnProps, 'label' | 'description' | 'errorMessage'> & {
    anchorRef?: RefObject<Element | null>;
};
export type SelectProps = NamedFieldProps & SelectOptions;
/** Select.Root: as Select, but `children` may name the field, in place of a label or an aria-label. */
export type SelectRootProps = SelectOptions & FieldValidationProps & (MuxUIAccessibleName | {
    children: ReactNode;
    label?: ReactNode;
    'aria-label'?: string;
    'aria-labelledby'?: string;
});
/** The props Mux UI defines for Select.Trigger. Every other attribute of a button passes through to it. */
export type SelectTriggerOwnProps = {
    /** Disables the trigger: it can be neither focused nor activated. A disabled Select disables it whatever this says. */
    disabled?: boolean | undefined;
};
export type SelectTriggerProps = ButtonHTMLAttributes<HTMLButtonElement> & SelectTriggerOwnProps;
/** The props Mux UI defines for Select.Popup. Every other attribute of a div passes through to the popup. */
export type SelectPopupOwnProps = {
    /** Where the popup opens against its trigger or anchorRef. start and end follow the locale direction. Without one, the Select's placement applies. */
    placement?: MuxUIPlacement;
    /** The distance in pixels between the popup and its trigger, along the placement's side. Must be finite. Without one, the Select's offset applies. */
    offset?: number;
    /** The shift in pixels along the side the popup is placed against. Must be finite. Without one, the Select's crossOffset applies. */
    crossOffset?: number;
    /** Whether the popup moves to the opposite side when the placed side has no room. Without one, the Select's shouldFlip applies. */
    shouldFlip?: boolean;
    /** The least distance in pixels between the popup and the edge of the viewport. Must be finite and not negative. Without one, the Select's containerPadding applies. */
    containerPadding?: number;
    /** Whether the rest of the page is made inaccessible while the popup is open. When false, outside content stays accessible. Without one, the Select's modal applies. */
    modal?: boolean;
};
export type SelectPopupProps = HTMLAttributes<HTMLDivElement> & SelectPopupOwnProps & {
    anchorRef?: RefObject<Element | null>;
};
/** The props Mux UI defines for Select.List. Every other attribute of a div passes through to the list. */
export type SelectListOwnProps = {
    /** The options as data: strings, or items with an `id`, a `label`, a `textValue`, and `disabled`. Children take precedence: when both are supplied, the items are not rendered. */
    items?: MuxUIItems;
};
type SelectListProps = HTMLAttributes<HTMLDivElement> & SelectListOwnProps;
/** The props Mux UI defines for Select.Item, which the anatomy calls the option. Every other attribute of a div passes through to the option. */
export type SelectItemOwnProps = {
    /** The stable string id the selection reports. A named Select submits it. */
    id: string;
    /** The text typeahead matches. Without one it is the text of the item's children, which is unambiguous only for plain text, so give rich children a `textValue`. */
    textValue?: string;
    /** Disables the item. A disabled Select disables every item whatever this says. */
    disabled?: boolean;
};
export type SelectItemProps = Omit<HTMLAttributes<HTMLDivElement>, 'id'> & SelectItemOwnProps;
type SelectComponent = ForwardRefExoticComponent<SelectProps & RefAttributes<HTMLDivElement>> & {
    Root: ForwardRefExoticComponent<SelectRootProps & RefAttributes<HTMLDivElement>>;
    Label: ForwardRefExoticComponent<HTMLAttributes<HTMLSpanElement> & RefAttributes<HTMLSpanElement>>;
    Trigger: ForwardRefExoticComponent<SelectTriggerProps & RefAttributes<HTMLButtonElement>>;
    Value: ForwardRefExoticComponent<HTMLAttributes<HTMLSpanElement> & RefAttributes<HTMLSpanElement>>;
    Popup: ForwardRefExoticComponent<SelectPopupProps & RefAttributes<HTMLDivElement>>;
    List: ForwardRefExoticComponent<SelectListProps & RefAttributes<HTMLDivElement>>;
    Item: ForwardRefExoticComponent<SelectItemProps & RefAttributes<HTMLDivElement>>;
    Description: ForwardRefExoticComponent<HTMLAttributes<HTMLSpanElement> & RefAttributes<HTMLSpanElement>>;
    Error: ForwardRefExoticComponent<HTMLAttributes<HTMLSpanElement> & RefAttributes<HTMLSpanElement>>;
};
export declare const Select: SelectComponent;
export {};

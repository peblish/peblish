// @generated-from: packages/react/src/color-area.ts
// @generated-content-sha256: sha256:b45db9e4c529d840398c5ef5f359b3ce3fa2aebb04b426c1df0eda03cc698541
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUIColorValue } from './color-context.js';
import type { MuxUIAccessibleName } from './fields.js';
/** The props Mux UI defines for ColorArea. The area is named by label, aria-label, or aria-labelledby. */
export type ColorAreaOwnProps = {
    /** The visible label, which also names the area. Without one, the area needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** The area's color, when the caller controls it. The area edits its saturation and brightness and keeps the hue. */
    value?: MuxUIColorValue;
    /** The starting color, when the area controls itself. */
    defaultValue?: MuxUIColorValue;
    /** Called with the new color as a CSS string each time saturation or brightness changes, in the color space of the value, of the enclosing ColorPicker, or of defaultValue, and in rgba() form with none of them. A disabled or read-only area does not call it. */
    onChange?: (value: MuxUIColorValue) => void;
    /** Disables the area: it can be neither focused nor changed. A disabled enclosing ColorPicker disables it too. */
    disabled?: boolean;
    /** Makes the area read-only: it stays focusable but its color cannot be changed. A read-only enclosing ColorPicker does the same. */
    readOnly?: boolean;
};
export type ColorAreaProps = Omit<ColorAreaOwnProps, 'label'> & {
    className?: string;
} & MuxUIAccessibleName;
export declare const ColorArea: ForwardRefExoticComponent<ColorAreaProps & RefAttributes<HTMLDivElement>>;

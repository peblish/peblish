// @generated-from: packages/react/src/supplemental/color-mode.ts
// @generated-content-sha256: sha256:789553409f5bb362c29e2000eb78cd7c141f6c520bc3708fdce39189e4b27c00
export type ColorMode = 'light' | 'dark';
export type ColorModeChoice = ColorMode | 'system';
type ColorModeOptions = {
    /** The choice when the page controls it. */
    mode: ColorModeChoice | undefined;
    /** The choice the control starts with, before a saved choice or the operating system's preference is read. */
    defaultMode: ColorModeChoice | undefined;
    storageKey: string;
    /** Whether System is a choice that follows the operating system. Without it, the preference is read once as a fallback. */
    followSystem: boolean;
};
/**
 * The mode state ColorModeToggle and ColorModePicker share: the storage key and format (`light` or `dark`, absent for
 * System), the scheme written to the document root, and the restore order.
 *
 * The first render uses `defaultMode` (System when the control follows it, else light) so server rendering and the
 * first client render match. After mount the saved choice wins, then `defaultMode`, then the operating system's
 * preference. Nothing is written until that restore ran, so a saved choice is never overwritten by the default.
 */
export declare function useColorMode({ mode, defaultMode, storageKey, followSystem }: ColorModeOptions): {
    choice: ColorModeChoice;
    select: (next: ColorModeChoice) => void;
};
export {};

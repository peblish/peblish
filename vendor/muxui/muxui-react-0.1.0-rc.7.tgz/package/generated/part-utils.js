// @generated-from: packages/react/src/supplemental/part-utils.ts
// @generated-content-sha256: sha256:819b5e3fe140ab36235aa3dbdc45843ac58ddba5fa69f4dc4189fb16b5e258f5
import React from 'react';
// Annotated, so the declaration names the React types by import and never the default import.
export const h = React.createElement;
export const useIsomorphicLayoutEffect = typeof window === 'undefined' ? React.useEffect : React.useLayoutEffect;
export function cx(...values) {
    return values.filter(Boolean).join(' ');
}
export function dataState(value) {
    return value ? '' : undefined;
}
/** Renders `tag` with the part's native props, its base class first, then the caller's className. */
export function nativePart(tag, base, props, ref, children) {
    const { className, ...rest } = props ?? {};
    const attributes = { ...rest, ref, className: cx(base, className) };
    return children === undefined ? h(tag, attributes) : h(tag, attributes, children);
}
export function pressHandler(onActivate) {
    return onActivate
        ? (event) => onActivate({ type: 'activate', pointerType: event?.pointerType, target: event?.target })
        : undefined;
}

// @generated-from: packages/react/src/supplemental/item-renderer.ts
// @generated-content-sha256: sha256:af396940fb975fd6807d64b2c02dbc48595b4881bbbe34ffb37f189debeadcf0
import type { ElementType, Key, ReactElement, ReactNode } from 'react';
/** An item as a choice control takes it: a key, and whatever else the caller keeps on it. */
type ChoiceItem = {
    id: Key;
    [key: string]: unknown;
};
export declare const defaultItemLabel: (item: ChoiceItem) => string;
export declare function useItemRenderer<T extends ChoiceItem>(children: ReactNode | ((item: T) => ReactNode), Item: ElementType, getTextValue: (item: T, rendered: ReactNode) => string): ReactNode | ((item: T) => ReactElement);
export {};

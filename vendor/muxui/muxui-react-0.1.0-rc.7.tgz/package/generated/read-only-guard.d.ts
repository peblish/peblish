// @generated-from: packages/react/src/read-only-guard.ts
// @generated-content-sha256: sha256:5fe0ac34e5a1527bf18fa02d5c4190f7c723d41c8921ab1211f95cafd1a07459
import type { ForwardedRef, KeyboardEvent as ReactKeyboardEvent } from 'react';
export declare const READ_ONLY_SELECTION_KEYS: ReadonlySet<string>;
export declare function readOnlyKeyGuard(readOnly: boolean, keys?: ReadonlySet<string>): (event: ReactKeyboardEvent) => void;
export declare function useReadOnlyTargets<T extends Element>(forwardedRef: ForwardedRef<T>, readOnly: boolean, selector: string): (node: T | null) => void;

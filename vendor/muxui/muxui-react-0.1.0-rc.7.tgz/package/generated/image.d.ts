// @generated-from: packages/react/src/supplemental/image.ts
// @generated-content-sha256: sha256:2f041b7c226221ba2ff6e16455bdd219cb86aea0437083c5f1c32ef460e13201
import type { ForwardRefExoticComponent, ImgHTMLAttributes, RefAttributes } from 'react';
/** The corner radii of an Image. */
export type ImageRadius = 'none' | 'sm' | 'md' | 'lg' | 'full';
/** How an Image's picture fills its declared box. */
export type ImageFit = 'cover' | 'contain' | 'fill' | 'none';
/**
 * The props Mux UI defines for Image; the catalog's web.react API is derived from this
 * type (Decision 0031). The image's native attributes and events, such as src,
 * width, loading, and onError, pass through unchanged.
 * It is a type literal, not an interface, so the public props type stays assignable to
 * Record<string, unknown>, as it was before the move.
 */
type ImageOwnProps = {
    /** What the picture shows in its context, or an empty string for a decorative image. Required. */
    alt: string;
    /** A source tried once after the primary source fails to load. */
    fallbackSrc?: string;
    /** A source set tried once, with fallbackSrc, after the primary source fails to load. */
    fallbackSrcSet?: string;
    /** The corner radius. */
    radius?: ImageRadius;
    /** How the picture fills the box its width and height declare. */
    fit?: ImageFit;
};
export type ImageProps = ImageOwnProps & Omit<ImgHTMLAttributes<HTMLImageElement>, keyof ImageOwnProps | 'className'> & {
    className?: string;
};
/** A Mux-styled native image with bounded, one-shot source recovery. */
export declare const Image: ForwardRefExoticComponent<ImageProps & RefAttributes<HTMLImageElement>>;
export {};

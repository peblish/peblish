// @generated-from: packages/react/src/control-utils.ts
// @generated-content-sha256: sha256:c8f16b84b73c1dcd1d2b12e1ec537f5e2020a7a60e0d841dafb89145c9e33950
import type { ReactNode } from 'react';
/** The base class followed by the caller's `className`, leaving out whichever is empty. */
export declare function classNames(base: string, className?: string | undefined): string;
/** What names a control: a visible label, `aria-label`, or `aria-labelledby`. */
interface AccessibleNameParts {
    label?: ReactNode;
    ariaLabel?: string | undefined;
    ariaLabelledby?: string | undefined;
}
/** Throws unless the control has a visible label, an `aria-label`, or an `aria-labelledby`; an empty label does not count. */
export declare function accessibleName(props: AccessibleNameParts, componentName: string): void;
export {};

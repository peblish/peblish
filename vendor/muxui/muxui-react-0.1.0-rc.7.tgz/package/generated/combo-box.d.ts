// @generated-from: packages/react/src/combo-box.ts
// @generated-content-sha256: sha256:963a0b3d43323df61d03ca2a0579c46d2b81979e35d3d386a01da54acb1ccbb6
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUICollectionItem, MuxUIItems } from './collection-items.js';
import type { NamedFieldProps } from './fields.js';
/** The props Mux UI defines for ComboBox. Every other attribute of a div passes through to the root. */
export type ComboBoxOwnProps = {
    /** The visible label, which also names the field. Without one, the field needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the field, which also describes it. */
    description?: ReactNode;
    /** The message the field shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed validation. It never makes the field invalid by itself. */
    errorMessage?: ReactNode;
    /** The full option set, filtered as the user types by a case- and accent-insensitive contains match on each item's text. Pass every option rather than a pre-filtered list. */
    items?: MuxUIItems;
    /** The text in the input, when the caller controls it. When the selected id is also controlled, choosing an option does not update the text: the application sets it, usually to the option's label. */
    value?: string;
    /** The text in the input at first, when the field controls itself. */
    defaultValue?: string;
    /** The id of the selected item, when the caller controls the selection. A controlled field with no selection passes null; an empty string is not an id and throws. A controlled selectedId stays until the application changes it. */
    selectedId?: string | null;
    /** The id of the item selected at first, when the field controls its selection. An empty string is not an id and throws. */
    defaultSelectedId?: string;
    /** Disables the field: it can be neither focused nor changed. */
    disabled?: boolean;
    /** The control size. The option list takes it too. */
    size?: 'sm' | 'md' | 'lg';
    /** Makes the field read-only: its text stays visible and focusable but cannot be changed, and no option can be chosen. */
    readOnly?: boolean;
    /** Marks the field required, so a form with native validation does not submit while it is empty. */
    required?: boolean;
    /** Marks the field invalid and shows its error message. Left false, validation decides, so failed validation can still make the field invalid. */
    invalid?: boolean;
    /** The form field name. A named field submits the selected item's id, not the item's `value`, or an empty value when nothing is selected. */
    name?: string;
    /** An example value shown while the field is empty. It does not name the field. */
    placeholder?: string;
    /** Called with the text each time it changes, including when choosing an option sets it to the option's label. */
    onChange?: (value: string) => void;
    /** Called with the chosen item, or with no item when the selection clears. Emptying the input clears the selection. */
    onSelect?: (item?: MuxUICollectionItem) => void;
};
export type ComboBoxProps = Omit<ComboBoxOwnProps, 'label'> & NamedFieldProps;
export declare const ComboBox: ForwardRefExoticComponent<ComboBoxProps & RefAttributes<HTMLDivElement>>;

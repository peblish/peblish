// @generated-from: packages/react/src/supplemental/field-root.ts
// @generated-content-sha256: sha256:b2447c95d349a848016a6efb170bccab5d5f971908716dc024d28cb5d5e55277
import React from 'react';
import { InputContext as AriaInputContext, TextAreaContext as AriaTextAreaContext } from 'react-aria-components';
import { AriaTextField } from './substrate.js';
import { normalizeChoiceControlSize } from './choice-context.mjs';
import { h, cx } from './part-utils.js';
import { mappedFieldProps } from './field-utils.js';
import { lateErrorScope } from './field-error.js';
/* Input and TextArea */
export const InputAssociationContext = React.createContext(null);
/**
 * Renders the root of Input or TextArea: a text field that provides the input association to its parts. It calls hooks,
 * so a family calls it, unconditionally, from its own render function. The props are written structurally so that no
 * declaration names the upstream package.
 */
export function renderFieldRoot(rootClass, componentName, { disabled, invalid, required, readOnly, size, className, children, ...props }, ref) {
    const resolvedSize = normalizeChoiceControlSize(size, componentName);
    const [descriptionId, setDescriptionId] = React.useState(undefined);
    const [errorId, setErrorId] = React.useState(undefined);
    const association = React.useMemo(() => ({
        setDescriptionId,
        setErrorId,
        descriptionId,
        errorId,
        size: resolvedSize,
    }), [descriptionId, errorId, resolvedSize]);
    const renderChildren = (renderProps) => {
        const content = typeof children === 'function' ? children(renderProps) : children;
        // The scope links a late TextArea.Error through the textarea's context; Input.Error links through the association.
        return h(InputAssociationContext.Provider, { value: { ...association, invalid: Boolean(invalid || renderProps?.isInvalid) } }, componentName === 'TextArea' ? lateErrorScope(AriaTextAreaContext, content) : lateErrorScope(AriaInputContext, content));
    };
    return h(AriaTextField, { ...mappedFieldProps({ disabled, invalid, required, readOnly, ...props }), ref, ...{ 'data-muxui-size': resolvedSize }, className: cx(rootClass, resolvedSize !== 'md' && `${rootClass}--${resolvedSize}`, className), children: renderChildren });
}

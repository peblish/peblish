// @generated-from: packages/react/src/color-wheel.ts
// @generated-content-sha256: sha256:6adda6fc0323c2a5d38f70f61c71d075d46c1275701f7a16337f13de93b92b73
import type { ForwardRefExoticComponent, RefAttributes } from 'react';
import type { MuxUIColorValue } from './color-context.js';
import type { MuxUIAriaAccessibleName } from './fields.js';
/** The props Mux UI defines for ColorWheel. The wheel is named by aria-label or aria-labelledby. */
export type ColorWheelOwnProps = {
    /** The wheel's color, when the caller controls it. The wheel edits its hue and keeps the rest. */
    value?: MuxUIColorValue;
    /** The starting color, when the wheel controls itself. */
    defaultValue?: MuxUIColorValue;
    /** Called with the new color as a CSS string each time the hue changes. It is in the color space of the value, of the enclosing ColorPicker, or of defaultValue, and in hsla() form with none of them. A disabled or read-only wheel does not call it. */
    onChange?: (value: MuxUIColorValue) => void;
    /** The wheel's outer radius in pixels: the wheel is twice this wide and tall. It must be a finite number of 0 or more, and more than innerRadius. */
    outerRadius?: number;
    /** The radius of the hole in the middle, in pixels. It must be a finite number of 0 or more, and less than outerRadius. */
    innerRadius?: number;
    /** Disables the wheel: it can be neither focused nor changed. A disabled enclosing ColorPicker disables it too. */
    disabled?: boolean;
    /** Makes the wheel read-only: it stays focusable but its hue cannot be changed. A read-only enclosing ColorPicker does the same. */
    readOnly?: boolean;
};
export type ColorWheelProps = ColorWheelOwnProps & {
    className?: string;
} & MuxUIAriaAccessibleName;
export declare const ColorWheel: ForwardRefExoticComponent<ColorWheelProps & RefAttributes<HTMLDivElement>>;

// @generated-from: packages/react/src/supplemental/button-group.ts
// @generated-content-sha256: sha256:ed8a9cf901a77ff096fbee09cb6daadb4442a20f1a275fec1e19b4b5fbbd785b
import React from 'react';
import { AriaGroup } from './substrate.js';
import { h, cx, dataState } from './part-utils.js';
/* ButtonGroup */
export const ButtonGroup = /*#__PURE__*/ React.forwardRef(function ButtonGroup({ children, orientation = 'horizontal', attached = false, disabled = false, role = 'group', 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, className, ...props }, ref) {
    const resolvedRole = role === 'presentation' || (ariaLabel || ariaLabelledby) ? role : 'presentation';
    return h(AriaGroup, {
        ...props,
        ref,
        role: resolvedRole,
        'aria-label': resolvedRole === 'presentation' ? undefined : ariaLabel,
        'aria-labelledby': resolvedRole === 'presentation' ? undefined : ariaLabelledby,
        isDisabled: disabled,
        ...{ 'data-muxui-state-orientation': orientation === 'vertical' ? 'vertical' : 'horizontal', 'data-muxui-attached': dataState(attached) },
        className: cx('muxui-button-group', `muxui-button-group--${orientation === 'vertical' ? 'vertical' : 'horizontal'}`, attached && 'muxui-button-group--attached', className),
    }, typeof children === 'function' ? null : children);
});

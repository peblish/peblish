// @generated-from: packages/react/src/supplemental/select-native.ts
// @generated-content-sha256: sha256:a50c9ae1c5956399f17528b4f76f2913d918688a0cd94e61620ad5e0a4693f53
import type { ForwardRefExoticComponent, ReactNode, RefAttributes, SelectHTMLAttributes } from 'react';
/** The visual sizes of SelectNative. */
export type SelectNativeVisualSize = 'sm' | 'md' | 'lg';
/**
 * The props Mux UI defines for SelectNative; the catalog's web.react API is derived
 * from this type (Decision 0031). The select's native attributes, such as value,
 * onChange, multiple, and name, pass through unchanged.
 * It is a type literal, not an interface, so the public props type stays assignable to
 * Record<string, unknown>, as it was before the move.
 */
type SelectNativeOwnProps = {
    /** The visible label, associated with the select. */
    label?: ReactNode;
    /** Help text, associated with the select. */
    description?: ReactNode;
    /** Error text, associated with the select. A nonempty message makes the select invalid. */
    errorMessage?: ReactNode;
    /** Applies the native disabled attribute. */
    disabled?: boolean;
    /** Applies the native required attribute. */
    required?: boolean;
    /** Marks the select invalid. */
    invalid?: boolean;
    /** String values select Mux control targets; positive numbers pass to native select size. */
    size?: SelectNativeVisualSize | number;
};
export type SelectNativeProps = SelectNativeOwnProps & Omit<SelectHTMLAttributes<HTMLSelectElement>, keyof SelectNativeOwnProps | 'className'> & {
    className?: string;
};
/** A visible native select with Mux field associations and styling. */
export declare const SelectNative: ForwardRefExoticComponent<SelectNativeProps & RefAttributes<HTMLSelectElement>>;
export {};

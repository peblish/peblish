// @generated-from: packages/react/src/supplemental/theme-picker.ts
// @generated-content-sha256: sha256:415662a0591983e6857c0f933f8a58c64ac6eb8c97a1b3b6bb95eeda6ff9c7d2
import type { ForwardRefExoticComponent, RefAttributes } from 'react';
import type { MuxUIThemeId } from './themes.js';
/** The theme ID of a preset, or `random` for the Random option. */
export type ThemePickerValue = MuxUIThemeId | 'random';
/**
 * The props Mux UI defines for ThemePicker; the catalog's web.react API is derived from this type (Decision 0031).
 * The picker is named by aria-label or aria-labelledby, and by Theme when it has neither.
 */
type ThemePickerOwnProps = {
    /** The selected theme ID, or random, when the page controls it. */
    value?: ThemePickerValue;
    /** The theme ID, or random, that starts selected, when the picker controls itself. */
    defaultValue?: ThemePickerValue;
    /** Called with the theme ID, or random, each time the user selects an option. */
    onChange?: (value: ThemePickerValue) => void;
    /** Adds a Random option before the presets. The picker only reports random; the page chooses the theme. */
    random?: boolean;
    /** Disables the picker and every option in it. */
    disabled?: boolean;
};
export type ThemePickerProps = ThemePickerOwnProps & {
    className?: string;
    'aria-label'?: string;
    'aria-labelledby'?: string;
};
export declare const ThemePicker: ForwardRefExoticComponent<ThemePickerProps & RefAttributes<HTMLDivElement>>;
export {};

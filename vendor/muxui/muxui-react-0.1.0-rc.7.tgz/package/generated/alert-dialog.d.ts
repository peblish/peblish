// @generated-from: packages/react/src/supplemental/alert-dialog.ts
// @generated-content-sha256: sha256:8fb38b1e50a25c41655ea9c456852f0d642e15c474abeebbb8aec5398c293bd2
import type { ButtonHTMLAttributes, ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { PartProps, SupplementalActivation } from './part-utils.js';
/**
 * The props Mux UI defines for AlertDialog.Root, the compound's root; the catalog's web.react API is derived from
 * this type (Decision 0031). Trigger and Close own the props below; the other parts take native attributes.
 */
type AlertDialogOwnProps = {
    /** Whether the dialog is open, when the caller controls it. */
    open?: boolean;
    /** Whether the dialog starts open, when it controls itself. */
    defaultOpen?: boolean;
    /** Called with the new open state each time the dialog opens or closes. */
    onOpenChange?: (open: boolean) => void;
};
/** The props Mux UI defines for AlertDialog.Trigger; its API is the trigger entry in the catalog's partApis. */
type AlertDialogTriggerOwnProps = {
    /** Marks the trigger disabled. */
    disabled?: boolean;
    /** Called when the trigger is pressed, which opens the dialog. */
    onActivate?: (event: SupplementalActivation) => void;
};
/** The props Mux UI defines for AlertDialog.Close; its API is the close entry in the catalog's partApis. */
type AlertDialogCloseOwnProps = {
    /** Marks the close control disabled. */
    disabled?: boolean;
    /** Called when the control is pressed, which closes the dialog. */
    onActivate?: (event: SupplementalActivation) => void;
};
export type AlertDialogRootProps = AlertDialogOwnProps & {
    children?: ReactNode;
};
export type AlertDialogActionsProps = PartProps<HTMLDivElement>;
export type AlertDialogTriggerProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    className?: string;
} & AlertDialogTriggerOwnProps;
export type AlertDialogCloseProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    className?: string;
} & AlertDialogCloseOwnProps;
export declare const AlertDialog: {
    Root: ForwardRefExoticComponent<AlertDialogRootProps & RefAttributes<HTMLElement>>;
    Backdrop: ForwardRefExoticComponent<PartProps<HTMLDivElement> & RefAttributes<HTMLDivElement>>;
    Popup: ForwardRefExoticComponent<PartProps<HTMLDivElement> & RefAttributes<HTMLDivElement>>;
    Content: ForwardRefExoticComponent<PartProps<HTMLElement> & RefAttributes<HTMLElement>>;
    Title: ForwardRefExoticComponent<PartProps<HTMLHeadingElement> & RefAttributes<HTMLHeadingElement>>;
    Description: ForwardRefExoticComponent<PartProps<HTMLParagraphElement> & RefAttributes<HTMLParagraphElement>>;
    Trigger: ForwardRefExoticComponent<AlertDialogTriggerProps & RefAttributes<HTMLButtonElement>>;
    Actions: ForwardRefExoticComponent<AlertDialogActionsProps & RefAttributes<HTMLDivElement>>;
    Close: ForwardRefExoticComponent<AlertDialogCloseProps & RefAttributes<HTMLButtonElement>>;
};
export {};

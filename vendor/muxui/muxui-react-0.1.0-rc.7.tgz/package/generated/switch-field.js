// @generated-from: packages/react/src/supplemental/switch-field.ts
// @generated-content-sha256: sha256:eea77dc706bf709fa02b05e24bbcbcbbb2005255a709728f38c9b826f1b259a3
import React from 'react';
import { AriaSwitchField, AriaSwitchButton } from './substrate.js';
import { normalizeChoiceControlSize } from './choice-context.mjs';
import { SwitchMotionIndicator } from './switch-motion.js';
import { h, cx } from './part-utils.js';
import { fieldText, mappedFieldProps } from './field-utils.js';
import { fieldError } from './field-error.js';
// The state Button reads from React Aria, for Thumb to follow.
const SwitchFieldThumbContext = React.createContext(null);
// SwitchField draws Switch's switch: Button and Thumb carry Switch's `muxui-switch` and `muxui-switch__indicator` classes beside
// their own, and Thumb is Switch's motion indicator, so the stylesheet block and the motion that make a Switch also make this one.
// Description and Error carry the field classes Switch's text uses. Only the part classes and the root layout are SwitchField's.
function makeSwitchField() {
    const Root = /*#__PURE__*/ React.forwardRef(function SwitchFieldRoot({ checked, defaultChecked, onChange, name, value, disabled, invalid, required, readOnly, size = 'md', className, ...props }, ref) {
        const resolvedSize = normalizeChoiceControlSize(size, 'SwitchField');
        // React Aria's props type the handlers on Element, and these on the div; the rest is the div's native attributes.
        return h(AriaSwitchField, { ...mappedFieldProps({ disabled, invalid, required, readOnly, ...props }), ref, isSelected: checked, defaultSelected: defaultChecked, onChange, name, value, ...{ 'data-muxui-size': resolvedSize }, className: cx('muxui-switch-field', className) });
    });
    const Button = /*#__PURE__*/ React.forwardRef(function SwitchFieldButton({ disabled, className, children, ...props }, ref) {
        return h(AriaSwitchButton, { ...props, ref, ...{ isDisabled: disabled }, className: cx('muxui-switch', 'muxui-switch-field__button', className),
            children: (renderProps) => h(SwitchFieldThumbContext.Provider, { value: renderProps }, children) });
    });
    const Thumb = /*#__PURE__*/ React.forwardRef(function SwitchFieldThumb({ className, ...props }, ref) {
        const state = React.useContext(SwitchFieldThumbContext);
        return h(SwitchMotionIndicator, { ...props, ref, className: cx('muxui-switch-field__thumb', className), isSelected: Boolean(state?.isSelected), isPressed: Boolean(state?.isPressed), isDisabled: Boolean(state?.isDisabled), isReadOnly: Boolean(state?.isReadOnly) });
    });
    const Description = /*#__PURE__*/ React.forwardRef(function SwitchFieldDescription(props, ref) { return fieldText('description', 'muxui-switch-field__description muxui-field-description', props, ref); });
    const Error = /*#__PURE__*/ React.forwardRef(function SwitchFieldError(props, ref) { return fieldError('muxui-switch-field__error muxui-field-error', props, ref); });
    return /*#__PURE__*/ Object.freeze({ Root, Button, Thumb, Description, Error });
}
export const SwitchField = /*#__PURE__*/ makeSwitchField();

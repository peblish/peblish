// @generated-from: packages/react/src/supplemental/resizable.ts
// @generated-content-sha256: sha256:9ac965b38aa8e8f86c039a557018ae8fec719dfa9a2772bb5d2f7efd6c36a933
import type { HTMLAttributes, ReactElement } from 'react';
/** The panel sizes as percentages of the container, by panel id. */
export type ResizableSizes = {
    readonly [panelId: string]: number;
};
/** The handle that changed the sizes, and whether a pointer or the keyboard did. */
export type ResizableChange = {
    handleId: string;
    source: 'pointer' | 'keyboard';
};
/**
 * The props Mux UI defines for Resizable; the catalog's web.react API is derived from
 * this interface (Decision 0031). `sizes` and `defaultSizes` are exclusive, which
 * ResizableProps enforces with its two arms; here both read as optional.
 */
interface ResizableOwnProps {
    /** The panel sizes, when the caller controls them. Give sizes or defaultSizes, not both. A controlled value has a finite size for every panel id and no other keys, each within its panel's bounds, adding up to 100. */
    sizes?: ResizableSizes;
    /** The panel sizes at first, when Resizable controls them. Give sizes or defaultSizes, not both. Sizes that are missing, or that do not add up to 100, are adjusted to a valid layout. */
    defaultSizes?: ResizableSizes;
    /** Reports every change to the sizes, with the handle that made it and whether a pointer or the keyboard did. */
    onSizesChange?: (sizes: ResizableSizes, meta: ResizableChange) => void;
    /** Reports sizes worth saving: when a pointer gesture that changed the sizes ends normally, and after each keyboard change. */
    onSizesCommit?: (sizes: ResizableSizes, meta: ResizableChange) => void;
    /** Whether the panels sit side by side or stacked. */
    orientation?: 'horizontal' | 'vertical';
    /** How many percent an arrow key moves a handle. A finite number greater than 0. */
    keyboardStep?: number;
    /** How many percent Shift with an arrow key, Page Up, or Page Down moves a handle. A finite number greater than 0. */
    keyboardLargeStep?: number;
    /** How many decimal places sizes keep, from 0 to 10. */
    precision?: number;
    /** Makes every handle unavailable. */
    disabled?: boolean;
    /** Shows the sizes and ignores resizing. */
    readOnly?: boolean;
}
export type ResizableBaseProps = Omit<ResizableOwnProps, 'sizes' | 'defaultSizes'> & Omit<HTMLAttributes<HTMLDivElement>, keyof ResizableOwnProps>;
export type ResizableProps = ResizableBaseProps & ({
    sizes: ResizableSizes;
    defaultSizes?: never;
} | {
    sizes?: never;
    defaultSizes?: ResizableSizes;
});
type ResizablePanelProps = HTMLAttributes<HTMLDivElement> & {
    id: string;
    minSize?: number;
    maxSize?: number;
};
type ResizableHandleProps = HTMLAttributes<HTMLDivElement> & {
    id: string;
    before: string;
    after: string;
    disabled?: boolean;
};
export declare function Resizable({ sizes, defaultSizes, onSizesChange, onSizesCommit, orientation, keyboardStep, keyboardLargeStep, precision, disabled, readOnly, children, className, ...props }: ResizableProps): ReactElement;
export declare function ResizablePanel({ id, minSize, maxSize, className, style, children, ...props }: ResizablePanelProps): ReactElement;
export declare function ResizableHandle({ id, before, after, disabled, className, onKeyDown, ...props }: ResizableHandleProps): ReactElement;
export {};

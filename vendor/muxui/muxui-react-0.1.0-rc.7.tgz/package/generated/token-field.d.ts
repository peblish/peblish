// @generated-from: packages/react/src/token-field.ts
// @generated-content-sha256: sha256:7a6cb239f3a99f661cad9c87c8ada3b2f6dfe55ef1274d4a72cfceaf36ca9eeb
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUIAccessibleName } from './fields.js';
/**
 * The props Mux UI defines for TokenField. The field is named by label, aria-label, or aria-labelledby,
 * and it takes no description, error message, required, or invalid.
 */
export type TokenFieldOwnProps = {
    /** The visible label, which also names the field. Without one, the field needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** The tokens, in order, when the caller controls them. */
    value?: string[];
    /** The tokens the field starts with, when it controls itself. Form reset restores them. */
    defaultValue?: string[];
    /** Called with the token array each time the tokens change, and only then: typed text that is not yet a token does not call it. A disabled or read-only field does not call it. */
    onChange?: (value: string[]) => void;
    /** Disables the field: it can be neither focused nor changed, and it submits no tokens. */
    disabled?: boolean;
    /** Makes the field read-only: its tokens stay visible and focusable but cannot be changed, and it still submits them. */
    readOnly?: boolean;
    /** The form field name. A named field submits one entry per token under it. */
    name?: string;
    /** Text shown while the field holds no tokens and no typed text. */
    placeholder?: string;
};
export type TokenFieldProps = Omit<TokenFieldOwnProps, 'label'> & {
    className?: string;
} & MuxUIAccessibleName;
export declare const TokenField: ForwardRefExoticComponent<TokenFieldProps & RefAttributes<HTMLDivElement>>;

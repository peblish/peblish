// @generated-from: packages/react/src/supplemental/index.ts
// @generated-content-sha256: sha256:0f5075ccee050408d5c405045511bdb3aa5fa5ab6d4dfbbe812b6ce308528746
// The names of the families the supplemental mapping admitted, in the order the package has always listed them. Metadata only.
export const supplementalFamilies = Object.freeze([
    'AlertDialog', 'Avatar', 'ButtonGroup', 'Card', 'CheckboxField', 'ColorModeToggle', 'CommandPalette', 'HeaderNav', 'Image', 'InputTags', 'Input', 'MultiSelect', 'PaymentInput', 'ProgressCircle', 'RadioField', 'SelectNative', 'Sidebar', 'SwitchField', 'TagSelect', 'TextArea', 'Text',
]);

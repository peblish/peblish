// @generated-from: packages/react/src/color-field.ts
// @generated-content-sha256: sha256:6a1733bc78f314a127cb54a4599d5e643064e2f8a879716eea1b5ece472e93cf
import type { ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUIColorValue } from './color-context.js';
import type { ControlSize, NamedFieldProps } from './fields.js';
/** The props Mux UI defines for ColorField. ColorField edits a whole color as one text value and has no channel or color-space props. */
export type ColorFieldOwnProps = {
    /** The visible label, which also names the field. Without one, the field needs an aria-label or aria-labelledby, and an empty label does not count. */
    label?: Exclude<ReactNode, null | undefined | boolean>;
    /** Supporting text shown with the field, which also describes it. */
    description?: ReactNode;
    /** The message the field shows, in place of the built-in one, only while it is invalid, through the invalid prop or failed validation. It never makes the field invalid by itself. */
    errorMessage?: ReactNode;
    /** The color, when the caller controls it. `null` is controlled and empty. */
    value?: MuxUIColorValue | null;
    /** The starting color, when the field controls itself. It also sets the color space onChange reports in, when there is no value and no enclosing ColorPicker. */
    defaultValue?: MuxUIColorValue;
    /** Called with the typed color as a CSS string once the field applies it, when it loses focus or Enter is pressed, and with `null` when the field is cleared. It is in the color space of the value, of the enclosing ColorPicker, or of defaultValue, and in rgba() form with none of them. The field shows and submits uppercase hex whatever the space. */
    onChange?: (value: MuxUIColorValue | null) => void;
    /** Disables the field: it can be neither focused nor changed. A disabled enclosing ColorPicker disables it too. */
    disabled?: boolean;
    /** Makes the field read-only: its color stays visible and focusable but cannot be changed. A read-only enclosing ColorPicker does the same. */
    readOnly?: boolean;
    /** Marks the field required, so a form with native validation does not submit while it is empty. */
    required?: boolean;
    /** Marks the field invalid and shows its error message. Left false, validation decides, so failed native, custom, or server validation can still make the field invalid. */
    invalid?: boolean;
    /** The control size. */
    size?: ControlSize;
    /** The form field name. A named field submits its color as uppercase hex, #RRGGBB. */
    name?: string;
};
export type ColorFieldProps = Omit<ColorFieldOwnProps, 'label'> & NamedFieldProps;
export declare const ColorField: ForwardRefExoticComponent<ColorFieldProps & RefAttributes<HTMLDivElement>>;

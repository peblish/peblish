// @generated-from: packages/react/src/supplemental/color-mode-picker.ts
// @generated-content-sha256: sha256:66ea89fe058692fb4e61de957ffeada395e106940587ea115180f7cd475704b9
import React from 'react';
import { ToggleButton } from './components.js';
import { ToggleButtonGroup } from './toggle-button-group.js';
import { useColorMode } from './color-mode.js';
import { cx, h } from './part-utils.js';
const OPTIONS = [
    { id: 'light', label: 'Light' },
    { id: 'dark', label: 'Dark' },
    { id: 'system', label: 'System' },
];
export const ColorModePicker = /*#__PURE__*/ React.forwardRef(function ColorModePicker({ mode, defaultMode, storageKey = 'muxui-color-mode', disabled = false, onModeChange, className, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledby, }, ref) {
    const { choice, select } = useColorMode({ mode, defaultMode, storageKey, followSystem: true });
    const name = ariaLabelledby === undefined ? { 'aria-label': ariaLabel ?? 'Color mode' } : { 'aria-labelledby': ariaLabelledby };
    return h(ToggleButtonGroup, {
        ...name,
        ref,
        selectionMode: 'single',
        disallowEmptySelection: true,
        selectedIds: [choice],
        disabled,
        className: cx('muxui-color-mode-picker', className),
        onSelectionChange: ([id]) => {
            const next = OPTIONS.find((option) => option.id === id);
            if (!next)
                return;
            select(next.id);
            onModeChange?.(next.id);
        },
    }, OPTIONS.map(({ id, label }) => h(ToggleButton, { key: id, id }, label)));
});

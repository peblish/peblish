// @generated-from: packages/react/src/grid-list.ts
// @generated-content-sha256: sha256:c3961b647972d5f735d6a360491d85cf040b332ddb4ab60ef1911c4cc1087352
import type { CSSProperties, ForwardRefExoticComponent, ReactNode, RefAttributes } from 'react';
import type { MuxUICollectionItem, MuxUIItems, MuxUISelection } from './collection-items.js';
import type { MuxUIAriaAccessibleName } from './fields.js';
/** The props Mux UI defines for GridList. */
export type GridListOwnProps = {
    /** The rows or cards as data: strings, or items with an `id`, a `label`, a `textValue`, and `disabled`. Children take precedence: when both are supplied, the items are not rendered. */
    items?: MuxUIItems;
    /** The selected item ids when the caller controls the selection, or `'all'`. */
    selectedIds?: MuxUISelection;
    /** The ids selected at first when the list controls its own selection, or `'all'`. */
    defaultSelectedIds?: MuxUISelection;
    /** Disables every item and stops the selection and action callbacks. An item's own `disabled={false}` cannot re-enable it under a disabled list. */
    disabled?: boolean;
    /** How many items can be selected. With `onAction` set and `single` or `multiple`, a click or Enter runs the action while nothing is selected and Space starts a selection; once an item is selected, a click changes the selection instead. */
    selectionMode?: 'none' | 'single' | 'multiple';
    /** Called with the selected item ids, or `'all'`, when the selection changes. It is not called while the list is disabled. */
    onSelectionChange?: (ids: MuxUISelection) => void;
    /** Called when the user activates an item. A list built from `items` passes the item record; one built from children passes the identity fields `id`, `key`, and `value`. It is not called for a disabled item or while the list is disabled. */
    onAction?: (item?: MuxUICollectionItem) => void;
    /** `stack` is a vertical list of rows. `grid` lays the items out in auto-fill columns of at least 10rem, as cards whose content wraps. Inside a grid Virtualizer a GridList must use `grid`. */
    layout?: 'stack' | 'grid';
    /** The direction a stack layout runs. `horizontal` scrolls along the inline axis and moves between items by their rendered positions. Inside a grid Virtualizer a GridList must be `vertical`. */
    orientation?: 'vertical' | 'horizontal';
};
export type GridListProps = GridListOwnProps & {
    children?: ReactNode;
    style?: CSSProperties;
    className?: string;
} & MuxUIAriaAccessibleName;
/** The props Mux UI defines for GridList.Item. */
export type GridListItemOwnProps = {
    /** The stable string id the selection and action callbacks report. */
    id: string;
    /** The text typeahead matches and the item's name. Without one it is the text of the item's children, which is unambiguous only for plain text, so give rich children a `textValue`. */
    textValue?: string;
    /** Disables the item. A disabled list disables every item whatever this says. */
    disabled?: boolean;
};
export type GridListItemProps = GridListItemOwnProps & {
    className?: string;
    style?: CSSProperties;
    children?: ReactNode;
};
type GridListComponent = ForwardRefExoticComponent<GridListProps & RefAttributes<HTMLDivElement>> & {
    Item: ForwardRefExoticComponent<GridListItemProps & RefAttributes<HTMLDivElement>>;
};
export declare const GridList: GridListComponent;
export {};

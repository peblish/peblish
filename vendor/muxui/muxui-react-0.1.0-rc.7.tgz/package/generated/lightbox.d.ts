// @generated-from: packages/react/src/supplemental/lightbox.ts
// @generated-content-sha256: sha256:3becaeb3c011c97acfe5823f4aaa547ce5b7244ff7b07705650a6a1fc1c07e24
import type { ButtonHTMLAttributes, ForwardRefExoticComponent, HTMLAttributes, ReactElement, ReactNode, RefAttributes } from 'react';
import type { ButtonActivationEvent, ButtonProps } from './button.js';
/** The identity of an item in the collection: a string, or a finite number. */
export type LightboxKey = string | number;
/** One item of the collection: its key, and the label that names it. */
export type LightboxItem = {
    key: LightboxKey;
    label?: string;
};
/** Where the selected item sits in the collection: its key, its index, and the item count. */
export type LightboxRenderContext = {
    key: LightboxKey;
    index: number;
    count: number;
};
/** The facts LightboxContent's render function receives: the context and the selected item. */
export type LightboxContentRenderContext = LightboxRenderContext & {
    item: LightboxItem;
};
/** Renders the content of the selected item. */
export type LightboxRenderContent = (item: LightboxItem, context: LightboxRenderContext) => ReactNode;
/**
 * The props Mux UI defines for Lightbox; the catalog's web.react API is derived from this
 * interface (Decision 0031). It is an interface, as LightboxProps was before the move.
 */
interface LightboxOwnProps {
    /** The collection the Lightbox views, each item with a key that is a string or a finite number, and an optional label. If any key is invalid or repeated, the whole collection is empty, and an empty collection never opens. */
    items: readonly LightboxItem[];
    /** Renders the selected item's content, from the item and a context with its key, index, and count. LightboxContent's own render function takes precedence. */
    renderContent?: LightboxRenderContent;
    /** The key of the selected item, when the caller controls the selection. A null selectedKey means nothing is selected. */
    selectedKey?: LightboxKey | null;
    /** The key of the item selected at first, when the Lightbox controls the selection. Without it, or when no item has the key, the first item. */
    defaultSelectedKey?: LightboxKey | null;
    /** Reports the selection changing, with the key and its item, or null for both when nothing is selected. */
    onSelectedChange?: (key: LightboxKey | null, item?: LightboxItem | null) => void;
    /** Whether the Lightbox is open, when the caller controls it. */
    open?: boolean;
    /** Whether the Lightbox starts open, when it controls itself. */
    defaultOpen?: boolean;
    /** Reports the Lightbox opening or closing. */
    onOpenChange?: (open: boolean) => void;
    /** Whether Previous and Next wrap around at the first and last item. */
    loop?: boolean;
    /** Whether swiping moves between items. */
    swipeNavigation?: boolean;
}
export interface LightboxProps extends LightboxOwnProps, HTMLAttributes<HTMLDivElement> {
}
export type LightboxControlActivation = {
    [K in keyof ButtonActivationEvent]: ButtonActivationEvent[K];
};
export type LightboxControlProps = ButtonHTMLAttributes<HTMLButtonElement> & {
    disabled?: boolean;
    onActivate?: (event: LightboxControlActivation) => void;
};
export type LightboxTriggerProps = Omit<ButtonProps, 'className' | 'style' | 'onActivate'> & Pick<ButtonHTMLAttributes<HTMLButtonElement>, 'className' | 'style'> & {
    itemKey: LightboxKey;
    onActivate?: (event: LightboxControlActivation) => void;
};
/** A controlled or uncontrolled modal media viewer with finite Mux item keys. */
export declare function Lightbox({ items, renderContent, selectedKey, defaultSelectedKey, onSelectedChange, open, defaultOpen, onOpenChange, loop, swipeNavigation, children, className, ...props }: LightboxProps): ReactElement;
export declare const LightboxTrigger: ForwardRefExoticComponent<LightboxTriggerProps & RefAttributes<HTMLButtonElement>>;
export declare function LightboxBackdrop({ children, dismissable, className, ...props }: HTMLAttributes<HTMLDivElement> & {
    dismissable?: boolean;
}): ReactElement | null;
export declare function LightboxPopup({ children, className, onKeyDown, onTouchStart, onTouchEnd, onTouchCancel, 'aria-label': ariaLabel, 'aria-labelledby': ariaLabelledBy, ...props }: HTMLAttributes<HTMLDivElement>): ReactElement | null;
export declare function LightboxContent({ renderContent, children, className, ...props }: HTMLAttributes<HTMLDivElement> & {
    renderContent?: (context: LightboxContentRenderContext) => ReactNode;
}): ReactElement | null;
export declare const LightboxCaption: ForwardRefExoticComponent<HTMLAttributes<HTMLParagraphElement> & RefAttributes<HTMLParagraphElement>>;
export declare function LightboxPrevious(props: LightboxControlProps): ReactElement;
export declare function LightboxNext(props: LightboxControlProps): ReactElement;
export declare function LightboxClose({ onActivate, className, children, ...props }: LightboxControlProps): ReactElement;
export {};

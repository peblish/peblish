// @generated-from: packages/react/src/tree.ts
// @generated-content-sha256: sha256:801895585023f7b0521b67cdb7c0d46f7ac4f99cd5eeca39f7ea19485dc85087
import type { ForwardRefExoticComponent, RefAttributes } from 'react';
import type { MuxUICollectionItem, MuxUISelection } from './collection-items.js';
import type { MuxUIAriaAccessibleName } from './fields.js';
/** A node of the tree: its nested items are `children`, or else `items`. */
export interface MuxUITreeItem extends MuxUICollectionItem {
    children?: MuxUITreeItem[];
    items?: MuxUITreeItem[];
}
/** The props Mux UI defines for Tree. Tree takes no `children`: its items come from `items`. */
export type TreeOwnProps = {
    /** The tree as data: strings, or items with an `id`, a `label`, a `textValue`, `disabled`, and nested `children` (or `items`). Give every item an id that is unique across the whole tree and stable when the data changes. An item without an id takes its key, value, or position among its siblings as its id, and a repeated id gets a numeric suffix in tree order. A disabled item disables all of its descendants. */
    items?: MuxUITreeItem[];
    /** The selected item ids when the caller controls the selection, or `'all'`. */
    selectedIds?: MuxUISelection;
    /** The ids selected at first when the tree controls its own selection, or `'all'`. */
    defaultSelectedIds?: MuxUISelection;
    /** The expanded item ids when the caller controls expansion, or `'all'`. */
    expandedIds?: MuxUISelection;
    /** The ids expanded at first when the tree controls its own expansion, or `'all'`. */
    defaultExpandedIds?: MuxUISelection;
    /** Disables every item and stops the selection, expansion, and action callbacks. */
    disabled?: boolean;
    /** How many items can be selected. */
    selectionMode?: 'none' | 'single' | 'multiple';
    /** What expands a parent item. With `row`, a click or tap on its label or row space expands or collapses it; with `chevron`, only its chevron control does. */
    expansionTrigger?: 'chevron' | 'row';
    /** Called with the selected item ids, or `'all'`, when the selection changes. It is not called while the tree is disabled. */
    onSelectionChange?: (ids: MuxUISelection) => void;
    /** Called with the expanded item ids, or `'all'`, when an item expands or collapses. It is not called while the tree is disabled. */
    onExpandedChange?: (ids: MuxUISelection) => void;
    /** Called with the item record when the user activates an item. With selection on, a click or Enter runs it while nothing is selected and Space starts a selection; once an item is selected, a click changes the selection instead. It is not called for a disabled item or while the tree is disabled. */
    onAction?: (item?: MuxUITreeItem) => void;
};
export type TreeProps = TreeOwnProps & {
    className?: string;
} & MuxUIAriaAccessibleName;
export declare const Tree: ForwardRefExoticComponent<TreeProps & RefAttributes<HTMLDivElement>>;

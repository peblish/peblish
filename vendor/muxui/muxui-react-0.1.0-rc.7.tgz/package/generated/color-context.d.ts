// @generated-from: packages/react/src/color-context.ts
// @generated-content-sha256: sha256:9ac5e5feb38dc79cf399fdadcda78167c74a2e6cf8c7a1a1be85b92f1808c6d7
import type { Context } from 'react';
/** A CSS color string. A color control's onChange returns one in the color space of its value, of an enclosing ColorPicker's color, or of its defaultValue: rgba(r, g, b, a) for hex and rgb, hsla(h, s%, l%, a) for hsl and hsb. ColorSlider with colorSpace uses that space, and ColorSwatchPicker returns the chosen item's color. */
export type MuxUIColorValue = string;
export type MuxUIColorSpace = 'rgb' | 'hsl' | 'hsb';
/** Channels must belong to colorSpace, or, when colorSpace is omitted, to the space of an enclosing ColorPicker's color, otherwise value or defaultValue. */
export type MuxUIColorChannel = 'red' | 'green' | 'blue' | 'hue' | 'saturation' | 'lightness' | 'brightness' | 'alpha';
interface ColorPickerState {
    disabled: boolean;
    readOnly: boolean;
    /** The color space the enclosing picker keeps its color in. Absent outside a picker. */
    space?: MuxUIColorSpace;
}
export declare const ColorPickerContext: Context<ColorPickerState>;
export {};

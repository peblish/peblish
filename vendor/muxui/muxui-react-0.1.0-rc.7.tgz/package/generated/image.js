// @generated-from: packages/react/src/supplemental/image.ts
// @generated-content-sha256: sha256:d53346e58d6de77c5abdc09f10b44898aa2913a3f034263d7aec29523bf6df2d
import React from 'react';
import { attachRef } from './motion-geometry.mjs';
const h = React.createElement;
// Keyed by the types, so a value added to one must be added here too.
const IMAGE_RADII = { none: true, sm: true, md: true, lg: true, full: true };
const IMAGE_FITS = { cover: true, contain: true, fill: true, none: true };
// Untyped callers can pass anything; Object.hasOwn alone would coerce ['md'] to a key.
function normalize(value, allowed, option) {
    if (typeof value !== 'string' || !Object.hasOwn(allowed, value))
        throw new TypeError(`Image ${option} must be one of: ${Object.keys(allowed).join(', ')}.`);
    return value;
}
function sourceKey(src, srcSet, fallbackSrc, fallbackSrcSet) {
    return [src ?? '', srcSet ?? '', fallbackSrc ?? '', fallbackSrcSet ?? ''].join('\u0000');
}
function hasSource(src, srcSet) {
    return [src, srcSet].some((value) => typeof value === 'string' && value.trim().length > 0);
}
// Native width/height map to `aspect-ratio: auto w / h`, so the source ratio
// replaces the declared box once it loads. A plain ratio keeps the declared box
// (and object-fit) while `block-size: auto` still scales it responsively. It is
// passed as a custom property so consumer classes can still set aspect-ratio.
function declaredAspectRatio(width, height) {
    const w = Number(width);
    const h = Number(height);
    return w > 0 && h > 0 && Number.isFinite(w) && Number.isFinite(h) ? `${w} / ${h}` : undefined;
}
function classNames(...values) {
    return values.filter(Boolean).join(' ');
}
/** A Mux-styled native image with bounded, one-shot source recovery. */
export const Image = React.forwardRef(function Image({ alt, src, srcSet, fallbackSrc, fallbackSrcSet, radius = 'none', fit = 'cover', className, style, onError, ...props }, ref) {
    if (typeof alt !== 'string')
        throw new TypeError('Image requires an alt string; use alt="" for decorative images.');
    const resolvedRadius = normalize(radius, IMAGE_RADII, 'radius');
    const resolvedFit = normalize(fit, IMAGE_FITS, 'fit');
    const key = sourceKey(src, srcSet, fallbackSrc, fallbackSrcSet);
    const [recovery, setRecovery] = React.useState({ key: null, mode: null });
    const recoveryMode = recovery.key === key ? recovery.mode : null;
    const imageRef = React.useRef(null);
    const setImageRef = React.useCallback((node) => {
        imageRef.current = node;
        const detach = attachRef(ref, node);
        return () => {
            detach();
            imageRef.current = null;
        };
    }, [ref]);
    const hasFallback = hasSource(fallbackSrc, fallbackSrcSet);
    const usingFallback = hasFallback && (recoveryMode === 'fallback' || recoveryMode === 'error');
    const failed = recoveryMode === 'error';
    const applyError = React.useCallback(() => {
        setRecovery((current) => {
            const mode = !usingFallback && hasFallback ? 'fallback' : 'error';
            return current.key === key && current.mode === mode ? current : { key, mode };
        });
    }, [hasFallback, key, usingFallback]);
    const handleError = (event) => {
        onError?.(event);
        applyError();
    };
    React.useEffect(() => {
        setRecovery((current) => current.key === key ? current : { key, mode: null });
    }, [key]);
    React.useEffect(() => {
        const image = imageRef.current;
        if (!image?.complete || image.naturalWidth > 0)
            return;
        applyError();
    }, [applyError, key, usingFallback]);
    const aspectRatio = declaredAspectRatio(props.width, props.height);
    return h('img', {
        ...props,
        ref: setImageRef,
        alt,
        style: aspectRatio ? { '--muxui-image-ratio': aspectRatio, ...style } : style,
        src: usingFallback ? fallbackSrc : src,
        srcSet: usingFallback ? fallbackSrcSet : srcSet,
        onError: handleError,
        className: classNames('muxui-image', resolvedRadius !== 'none' && `muxui-image--radius-${resolvedRadius}`, `muxui-image--fit-${resolvedFit}`, failed && 'muxui-image--error', className),
        'data-muxui-fallback': usingFallback ? '' : undefined,
        'data-muxui-error': failed ? '' : undefined,
    });
});
Image.displayName = 'Image';

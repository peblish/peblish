// @generated-from: packages/react/src/supplemental/header-nav.ts
// @generated-content-sha256: sha256:ea8e763557d1bbab5873b0a0d45dde273b1ddc16605000cd5a1843cf26d59c17
import type { AnchorHTMLAttributes, ComponentType, ForwardRefExoticComponent, HTMLAttributes, ReactNode, RefAttributes } from 'react';
import type { PartProps } from './part-utils.js';
export type HeaderNavVariant = 'inverse' | 'background';
/**
 * The props Mux UI defines for HeaderNav.Root, the compound's root; it passes the header element's native
 * attributes on. The catalog's web.react API is derived from this type (Decision 0031).
 */
type HeaderNavOwnProps = {
    /** The bar's surface: inverse, a strong fill set apart from the page, or background, the page's own surface with no edge and controls in the surrounding colour scheme. The mobile drawer takes the same surface. */
    variant?: HeaderNavVariant;
};
/** The props Mux UI defines for HeaderNav.Logo; its API is the logo entry in the catalog's partApis. */
type HeaderNavLogoOwnProps = {
    /** Wraps the logo's content in a link to this address. */
    href?: string;
};
/** The props Mux UI defines for HeaderNav.NavButton; its API is the nav-button entry in the catalog's partApis. */
type HeaderNavNavButtonOwnProps = {
    /** Marks the link as the current page: it is styled as such and carries aria-current. */
    current?: boolean;
};
export type HeaderNavRootProps = HTMLAttributes<HTMLElement> & HeaderNavOwnProps;
export type HeaderNavNavButtonProps = AnchorHTMLAttributes<HTMLAnchorElement> & HeaderNavNavButtonOwnProps;
type HeaderNavLogoProps = PartProps<HTMLDivElement> & HeaderNavLogoOwnProps;
export declare const HeaderNav: {
    Root: ForwardRefExoticComponent<HeaderNavRootProps & RefAttributes<HTMLElement>>;
    Logo: ForwardRefExoticComponent<HeaderNavLogoProps & RefAttributes<HTMLDivElement>>;
    NavButton: ForwardRefExoticComponent<HeaderNavNavButtonProps & RefAttributes<HTMLAnchorElement>>;
    Actions: ForwardRefExoticComponent<PartProps<HTMLDivElement> & RefAttributes<HTMLDivElement>>;
    Secondary: ForwardRefExoticComponent<PartProps<HTMLElement> & RefAttributes<HTMLElement>>;
    MobileTrigger: ComponentType<{
        children?: ReactNode;
    }>;
};
export {};
